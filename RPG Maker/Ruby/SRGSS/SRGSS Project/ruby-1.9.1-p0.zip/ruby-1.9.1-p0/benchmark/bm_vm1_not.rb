i = 0
obj = Object.new

while i<30000000 # while loop 1
  i+= 1
  !obj
end
