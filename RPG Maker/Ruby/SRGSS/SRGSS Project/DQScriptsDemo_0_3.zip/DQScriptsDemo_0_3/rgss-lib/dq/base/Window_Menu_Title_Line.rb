#==============================================================================
# �� Window_Menu_Title_Line
#------------------------------------------------------------------------------
# �^�C�g�����C��
# Copyright (C) 2005 fukuyama
#==============================================================================

if false # ������

module DQ

class Window_Menu
  alias draw_title_line_draw_title_item draw_title_item
  def draw_title_item(color,rect,title,title_align)
    draw_title_line_draw_title_item(color,rect,title,title_align)
    draw_title_line
  end
  #--------------------------------------------------------------------------
  # �^�C�g�����C���̕`��
  #--------------------------------------------------------------------------
  def draw_title_line
    if @sprite_title_line.nil?
      @sprite_title_line = Sprite.new
      bmp = Bitmap.new(self.width - 4,2)
      @sprite_title_line.bitmap = bmp
      @sprite_title_line.bitmap.fill_rect(bmp.rect,normal_color)
      rect = bmp.rect.dup
      rect.y = 1
      rect.height = 1
      @sprite_title_line.bitmap.fill_rect(rect,Color.new(0,0,0,128))
      @sprite_title_line.visible = false
    end
  end
  #--------------------------------------------------------------------------
  # �^�C�g�����C���̍X�V
  #--------------------------------------------------------------------------
  def update_title_line
    if not @sprite_title_line.nil?
      @sprite_title_line.x = self.x + 2
      @sprite_title_line.y = self.y + 16 + _menu_height + 2
      @sprite_title_line.z = self.z
      @sprite_title_line.visible = self.visible
    end
  end
  #--------------------------------------------------------------------------
  # �� �t���[���X�V
  #--------------------------------------------------------------------------
  def update
    super
    # �J�[�\���̋�`���X�V
    update_cursor_rect
    # �^�C�g�����C���̍X�V
    update_title_line
  end
  alias draw_title_line_dispose_visible= visible=
  def visible=(arg)
    self.draw_title_line_dispose_visible=(arg)
    if not @sprite_title_line.nil?
      update_title_line
    end
  end
  alias draw_title_line_dispose dispose
  def dispose
    if not @sprite_title_line.nil?
      @sprite_title_line.bitmap.dispose
      @sprite_title_line.dispose
    end
    draw_title_line_dispose
  end
end

end

end
