#==============================================================================
# �� Window_Message_Command
#------------------------------------------------------------------------------
# �c�p�p���b�Z�[�W�R�}���h�I���E�B���h�E
# Copyright (C) 2005 fukuyama
#==============================================================================

module DQ

class Window_Message_Command < Window_Menu
  #--------------------------------------------------------------------------
  # �� �I�u�W�F�N�g������
  #--------------------------------------------------------------------------
  def initialize
    $game_temp.choice_parameters.each do |name|
      add_menu(name,:selected)
    end
    @index = 0
    super()
    remove_input_handler(Input::C)
    remove_input_handler(Input::B)
  end
  def selected
  end
end

end

class Window_Message
  #--------------------------------------------------------------------------
  # �� �I�����E�B���h�E�̍쐬
  #--------------------------------------------------------------------------
  def create_window_message_command
    return DQ::Window_Message_Command.new
  end
end
