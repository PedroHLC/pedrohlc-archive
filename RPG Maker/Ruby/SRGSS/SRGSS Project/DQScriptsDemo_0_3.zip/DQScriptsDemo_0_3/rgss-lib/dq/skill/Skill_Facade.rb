#==============================================================================
# �� Skill_Facade
#------------------------------------------------------------------------------
# �X�L���p�`�o�h
#==============================================================================

module Skill_Facade
  @@last_result = nil

  module_function

  #--------------------------------------------------------------------------
  # �Ō�Ɏ��s�����`�o�h�̕ԋp�l
  #--------------------------------------------------------------------------
  def last_result
    return @@last_result
  end

  #--------------------------------------------------------------------------
  # �X�L�����g�p
  #--------------------------------------------------------------------------
  def use_skill(skill,owner_actor,target_actors)
    @@last_result = false
    target_actors.each do |actor|
      @@last_result |= actor.skill_effect(owner_actor, skill)
    end
    # �X�L�����g�p���ꂽ�ꍇ
    if @@last_result
      # �X�L���̎g�p�� SE �����t
      $game_system.se_play(skill.menu_se)
      # SP ������
      owner_actor.sp -= skill.sp_cost
    end
    return @@last_result
  end

  #--------------------------------------------------------------------------
  # �A�N�^�[�̎����Ă���X�L���̈ꗗ���擾
  #--------------------------------------------------------------------------
  def actor_skills(actor)
    @@last_result = []
    actor.skills.each do |id|
      skill = $data_skills[id]
      if not skill.nil?
        @@last_result.push(skill)
      end
    end
    return @@last_result
  end
  #--------------------------------------------------------------------------
  # �A�N�^�[�̎����Ă���ʏ�X�L���̈ꗗ���擾
  #--------------------------------------------------------------------------
  def actor_normal_skills(actor)
    @@last_result = []
    actor.skills.each do |id|
      skill = $data_skills[id]
      if (not skill.nil?) and [0,2].include?(skill.occasion)
        @@last_result.push(skill)
      end
    end
    return @@last_result
  end
  #--------------------------------------------------------------------------
  # �A�N�^�[�̎����Ă���퓬�X�L���̈ꗗ���擾
  #--------------------------------------------------------------------------
  def actor_battle_skills(actor)
    @@last_result = []
    actor.skills.each do |id|
      skill = $data_skills[id]
      if (not skill.nil?) and [0,1].include?(skill.occasion)
        @@last_result.push(skill)
      end
    end
    return @@last_result
  end

  #--------------------------------------------------------------------------
  # �A�N�^�[�̃N���X���o����\���̂���X�L���̈ꗗ���擾
  #--------------------------------------------------------------------------
  def actor_class_skills(actor)
    @@last_result = []
    $data_classes[actor.class_id].learnings.each do |learning|
      id = learning.skill_id
      skill = $data_skills[id]
      if not skill.nil?
        @@last_result.push(skill)
      end
    end
    return @@last_result
  end

  #--------------------------------------------------------------------------
  # �A�N�^�[�̃N���X���o����\���̂���ʏ�X�L���̈ꗗ���擾
  #--------------------------------------------------------------------------
  def actor_class_normal_skills(actor)
    @@last_result = []
    $data_classes[actor.class_id].learnings.each do |learning|
      id = learning.skill_id
      skill = $data_skills[id]
      if (not skill.nil?) and [0,2].include?(skill.occasion)
        @@last_result.push(skill)
      end
    end
    return @@last_result
  end
end
