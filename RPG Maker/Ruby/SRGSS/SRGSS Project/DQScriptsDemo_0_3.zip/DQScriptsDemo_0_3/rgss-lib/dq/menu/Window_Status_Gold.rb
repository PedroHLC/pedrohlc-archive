#==============================================================================
# �� Window_Status_Gold
#------------------------------------------------------------------------------
# �S�[���h�E�B���h�E(�S��)
# Copyright (C) 2005 fukuyama
#==============================================================================

module DQ

class Window_Status_Gold < Window_Menu
  #--------------------------------------------------------------------------
  # �� �I�u�W�F�N�g������
  #--------------------------------------------------------------------------
  def initialize
    @item_height = ITEM_HEIGHT
    @title = '������'
    @title_align = 1
    @index = -1
    add_menu($game_party.gold.to_s,nil)
    if Module.constants.include?('BANK_VARIABLE_ID')
      add_menu($game_variables[BANK_VARIABLE_ID].to_s,nil) # ��s
    end
    super
  end
  #--------------------------------------------------------------------------
  # ���ڂ̕`��
  #--------------------------------------------------------------------------
  def draw_menu_item(index,color,menu_rect,gold)
    self.contents.font.color = color
    self.contents.fill_rect(menu_rect, Color.new(0, 0, 0, 0))

    gold_text = gold + ' ' + $data_system.words.gold
    gold_rect = Rect.new( menu_rect.width * 0.5,
                          menu_rect.y,
                          menu_rect.width * 0.5,
                          menu_rect.height )

    self.contents.draw_text(gold_rect, gold_text, 2)

		case index
		when 0
			label_text = '���傶����F'
		when 1
			label_text = '���񂱂��F'
		end
    label_rect = Rect.new( menu_rect.x,
                           menu_rect.y,
                           menu_rect.width * 0.5,
                           menu_rect.height )
    self.contents.draw_text(label_rect, label_text, 2)

  end
  #---------------------------------------------------------------------------
  # �R���e���c���̍쐬
  def _contents_width
    return _menu_width
  end
  #---------------------------------------------------------------------------
  # ���j���[���̍쐬
  def _menu_width
    return ALL_STATUS_WIDTH
  end
end

end
