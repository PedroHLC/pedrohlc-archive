#==============================================================================
# �� Event_Script_Sell_Actor_Select
#------------------------------------------------------------------------------
# �V���b�v�p�C�x���g�X�N���v�g�i�A�N�^�[�j
# Copyright (C) 2005 fukuyama
#==============================================================================

module Event_Script
module Sell_Actor_Select
  @@window = nil

  @@item = nil
  @@actor = nil
  @@backpack = nil

  module_function
  def clear
    @@item = nil
    @@actor = nil
    @@backpack = nil
  end
  #----------------------------------------------------------------------------
  # �E�B���h�E���J��
  #----------------------------------------------------------------------------
  def open
    if @@window.nil?
      @@window = DQ::Window_Actor_Menu_Item_Sell.new
      clear
    end
  end

  #----------------------------------------------------------------------------
  # �E�B���h�E�����
  #----------------------------------------------------------------------------
  def close()
    @@window.dispose if not @@window.disposed?
    @@window = nil
  end

  #----------------------------------------------------------------------------
  # �E�B���h�E�̍X�V
  #----------------------------------------------------------------------------
  def update(variable_id)
    if @@window.nil?
      open()
    end
    result = @@window.disposed?
    if result
      @@item = @@window.item
      @@actor = @@window.actor
      @@backpack = @@window.backpack
      if @@actor.nil?
        $game_variables[variable_id] = -1
      else
        $game_variables[variable_id] = @@item.id
      end
      if not @@backpack.nil?
        $game_variables[variable_id] = @@item.id
      end
      close()
    else
      @@window.update
    end
    return result
  end

  def actor
    return @@actor
  end
  def backpack
    return @@backpack
  end
  def item?
    return @@item.is_a? Game_Item
  end
  def weapon?
    return @@item.is_a? Game_Weapon
  end
  def armor?
    return @@item.is_a? Game_Armor
  end
  def item
    return nil if not item?
    return @@item
  end
  def weapon
    return nil if not weapon?
    return @@item
  end
  def armor
    return nil if not armor?
    return @@item
  end
end
end
