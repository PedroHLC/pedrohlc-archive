#==============================================================================
# �� Window_Status_PlayTime
#------------------------------------------------------------------------------
# �v���C���ԃE�B���h�E
# Copyright (C) 2005 fukuyama
#==============================================================================

module DQ

class Window_Status_PlayTime < Window_Menu
  #--------------------------------------------------------------------------
  # �� �I�u�W�F�N�g������
  #--------------------------------------------------------------------------
  def initialize
    @item_height = ITEM_HEIGHT
    @title = '�ڂ����񂵂�����'
    @title_align = 1
    @index = -1
    add_menu('',nil)
    super
  end
  #--------------------------------------------------------------------------
  # �� �t���[���X�V
  #--------------------------------------------------------------------------
  def update
    super
    if Graphics.frame_count / Graphics.frame_rate != @total_sec
      refresh
    end
  end
  #--------------------------------------------------------------------------
  # ���ڂ̕`��
  #--------------------------------------------------------------------------
  def draw_menu_item(index,color,rect,dumy)
    @total_sec = Graphics.frame_count / Graphics.frame_rate
    hour = @total_sec / 60 / 60
    min = @total_sec / 60 % 60
    play_time_text = sprintf("%2d����%2d��", hour, min)

    self.contents.font.color = color
    self.contents.fill_rect(rect, Color.new(0, 0, 0, 0))
    self.contents.draw_text(rect, play_time_text, 2)
  end
  #---------------------------------------------------------------------------
  # �R���e���c���̍쐬
  def _contents_width
    return _menu_width
  end
  #---------------------------------------------------------------------------
  # ���j���[���̍쐬
  def _menu_width
    return ALL_STATUS_WIDTH
  end
end

end
