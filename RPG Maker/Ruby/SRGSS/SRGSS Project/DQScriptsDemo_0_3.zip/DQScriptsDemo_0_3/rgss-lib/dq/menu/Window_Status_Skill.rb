#==============================================================================
# �� Window_Status_Skill
#------------------------------------------------------------------------------
# �X�L���E�B���h�E
# Copyright (C) 2005 fukuyama
#==============================================================================

module DQ

class Window_Status_Skill < Window_Menu
  include Window_Tree_Module
  #--------------------------------------------------------------------------
  # ������
  #--------------------------------------------------------------------------
  def initialize(parent)
    @title = '�������'
    @title_align = 1
    @index = -1
    @column_max = 2
    if not parent.actor.nil?
      @skills = Skill_Facade.actor_class_skills parent.actor
      @skills.each do |skill|
        add_menu(skill, :next_window)
      end
    end
    super(parent)

		if not Skill_Facade.actor_class_normal_skills(parent.actor).empty?
      @window_normal_skill = Window_Status_Normal_Skill.new(self,parent.actor)
      add_child @window_normal_skill
    end

    # �ʒu�̐ݒ�
    self.screen_top(16)
    self.screen_right(WINDOW_SKILL_WIDTH + 32 + 16)
  end
  #--------------------------------------------------------------------------
  # ���̃E�B���h�E
  #--------------------------------------------------------------------------
  def next_window
    # �Ƃ肠����
    decision_se
    dispose
  end
  #--------------------------------------------------------------------------
  # ���ڂ̕`��
  #--------------------------------------------------------------------------
  def draw_menu_item(index,color,rect,skill)
    self.contents.font.color = color
    self.contents.fill_rect(rect, Color.new(0, 0, 0, 0))
    if parent.actor.skill_learn?(skill.id)
      self.contents.draw_text(rect, skill.name)
    end
  end
  #---------------------------------------------------------------------------
  # �R���e���c���̍쐬
  def _contents_width
    return _menu_width * 2 + 8
  end
  #---------------------------------------------------------------------------
  # ���j���[���̍쐬
  def _menu_width
    return WINDOW_SKILL_WIDTH
  end
end

end
