#==============================================================================
# �� Event_Script
#------------------------------------------------------------------------------
# �c�p�p�H�C�x���g�X�N���v�g
# Copyright (C) 2005 fukuyama
#==============================================================================

module Event_Script
  @@window_savedata_select = nil

  module_function
  #--------------------------------------------------------------------------
  # �Z�[�u�ӏ��̑I��
  #--------------------------------------------------------------------------
  def savedata_select(variable_id=nil)
    if @@window_savedata_select.nil?
      @@window_savedata_select = DQ::Window_SaveData_Select.new
      @@window_savedata_select.index = 0
    end
    @@window_savedata_select.update
    result = @@window_savedata_select.disposed?
    if result
      if not variable_id.nil?
        $game_variables[variable_id] = @@window_savedata_select.index
      else
        $game_temp.last_file_index = @@window_savedata_select.index
      end
      @@window_savedata_select = nil
    end
    return result
  end
  #--------------------------------------------------------------------------
  # �㏑������
  #--------------------------------------------------------------------------
  def savedata_overwrite?(variable_id=nil)
    index = $game_temp.last_file_index
    if not variable_id.nil?
      index = $game_variables[variable_id]
    end
    savedatas = DQ::SaveData_Facade.load_index
    return (not savedatas[index].nil?)
  end
  #--------------------------------------------------------------------------
  # �Z�[�u
  #--------------------------------------------------------------------------
  def save(*args)
    index,name,lv,comment = *args

    if not index.is_a?(Numeric)
      index = $game_temp.last_file_index
    end
    if name.nil?
      name = $game_actors[1].name
    end
    if not lv.is_a?(Numeric)
      lv = $game_actors[1].level
    end
    if comment.nil?
      map_infos = load_data("Data/MapInfos.rxdata")
      comment = map_infos[$game_map.map_id].name
    end
    tmp_interpreter = $game_system.map_interpreter
    $game_system.map_interpreter = Interpreter.new(0,true)
    $game_system.battle_interpreter = Interpreter.new(0,false)

    DQ::SaveData_Facade.save(index,name,lv,comment)

    $game_system.map_interpreter = tmp_interpreter
    return true
  end
end
