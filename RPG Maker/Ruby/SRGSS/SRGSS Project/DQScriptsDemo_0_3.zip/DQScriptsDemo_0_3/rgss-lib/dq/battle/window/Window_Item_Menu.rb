#==============================================================================
# �� Window_Item_Menu
#------------------------------------------------------------------------------
# �퓬�p�A�C�e�����j���[�E�B���h�E
# Copyright (C) 2005 fukuyama
#==============================================================================

module DQ
module Battle

class Window_Item_Menu < Window_Menu
  include Window_Tree_Module
  include Window_Target_Module

  #--------------------------------------------------------------------------
  # ������
  #--------------------------------------------------------------------------
  def initialize(parent)
    @actor = parent.get_window(Window_Actor_Command).actor
    @item = parent.get_window(Window_Item).item
    add_menu('����',:use_item)
    if @actor.is_a? Game_Actor
      if Item_Facade.actor_equip?(@item,@actor)
        add_menu('�͂���',:equip_item)
      else
        add_menu('������',:equip_item)
      end
    end
    @index = 0
    super(parent)
    # �ʒu�̐ݒ�
    self.top = parent.top
    self.right = parent.right
  end
  #--------------------------------------------------------------------------
  # �C�x���g�n���h��
  #--------------------------------------------------------------------------
  def input_b
    if Input.trigger?(Input::B)
      @index = -1
      cancel_se
      dispose
    end
  end
  def use_item
    window = get_window(Window_Actor_Command)
    window.item = @item
    window.item_use = true
    if Item_Facade.get_use_item(@item).nil?
      top_window.dispose
      return
    end
    next_window Item_Facade.get_use_item(@item)
  end
  def equip_item
    # �������Œ肳��Ă���ꍇ
    if Item_Facade.equip_fix?(@item,@actor)
      event = Script_Event.new
      event.message("#{@actor.name}�́@#{@item.name}���@�����ł��Ȃ��B")
      event.brank
      # �C�x���g���Z�b�g�A�b�v
      $game_system.battle_interpreter.setup(event.event_commands, 0)
      return
    end
    if not Item_Facade.equippable?(@item,@actor)
      event = Script_Event.new
      event.message("#{@actor.name}�́@#{@item.name}���@�����ł��Ȃ��B")
      event.brank
      # �C�x���g���Z�b�g�A�b�v
      $game_system.battle_interpreter.setup(event.event_commands, 0)
      return
    end
    window = get_window(Window_Actor_Command)
    window.item = @item
    window.item_equip = true
    top_window.dispose
  end
end

end
end
