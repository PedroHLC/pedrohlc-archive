#==============================================================================
# �� Window_Actor_Menu_Item_Trade
#------------------------------------------------------------------------------
# �킽���A�C�e���A�N�^�[���j���[
# Copyright (C) 2005 fukuyama
#==============================================================================

module DQ

class Window_Actor_Menu_Item_Trade < Window_Actor_Menu_Base
  include Menu_Log_Item_Module
  #----------------------------------------------------------------------------
  # ������
  #----------------------------------------------------------------------------
  def initialize(parent,title)
    super(parent,title)

    # �ӂ��냁�j���[�ǉ�
    add_menu('�ӂ���', :select_party_backpack)
    pack

    # �ʒu�̐ݒ�
    self.top  = top_window.top
    self.left = get_window(Window_Item_Menu).right

    # �A�C�e���E�B���h�E�쐬
    @window_item = Window_Item_Trade.new(self)

    # �A�C�e���w���v�E�B���h�E�쐬
    item_win = get_window(Window_Item)
    x = item_win.x
    y = item_win.y + item_win.height
    w = item_win.width + item_win.width / 4
    h = 32 * 2 + 32
    item = item_win.item
    @window_help = Window_Markup_Text.new(x,y,w,h)
    @window_help.back_opacity = WINDOW_BACK_OPACITY
    @window_help.set_text(item.name + "\n" + item.description)
    @window_help.visible = true

    # �q�E�B���h�E�ɒǉ�
    add_child @window_item
    add_child @window_help
  end

  def backpack
    if get_menu == '�ӂ���'
      return $game_party
    end
    return nil
  end

  #--------------------------------------------------------------------------
  # �X�V
  #--------------------------------------------------------------------------
  def update
    if @message_end
      get_window(Window_Item_Menu).dispose
      get_window(Window_Item).refresh
      return
    end
    super
  end

  def select_party_backpack
    from_actor = get_window(Window_Actor_Menu_Item).actor
    from_actor = get_window(Window_Actor_Menu_Item).backpack if from_actor.nil?
    from_item  = get_window(Window_Item).item
    to_actor = $game_party
    Item_Facade.trade_item(from_actor,from_item,to_actor)
    case from_actor
    when Game_Actor
      menu_log_hand_item_backpack(from_actor,from_item)
      @message_end = true
    when Game_Party
      menu_log_trade_item_backpack(from_item)
      @message_end = true
    end
  end

  def select_actor
    item = get_window(Window_Item).item
    if self.actor.backpack.addit? item
      # �ǉ��ł���ꍇ�͋󔒗��ɃJ�[�\�������킹��
      @window_item.index = self.actor.backpack.item_count
    else
      # �ǉ��ł��Ȃ��ꍇ�͑����i�̎��̃A�C�e����
      @window_item.index = Item_Facade.equip_items(self.actor).size
    end
    set_active_window(Window_Item_Trade)
  end

  def change_actor
    @window_item.refresh
  end
end

end
