#==============================================================================
# �� Sprite_Cursor
#------------------------------------------------------------------------------
# �c�p�p�̃J�[�\���X�v���C�g
# Copyright (C) 2005 fukuyama
#==============================================================================

module DQ

class Sprite_Cursor < ::Sprite_Cursor
  def initialize(viewport)
    @cursor_bitmap = Script_Bitmap.get('cursor')
    super(viewport)
  end
end

end
