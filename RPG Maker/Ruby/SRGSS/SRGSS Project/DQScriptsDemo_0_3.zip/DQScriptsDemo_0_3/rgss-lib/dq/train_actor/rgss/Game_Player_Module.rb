#==============================================================================
# �� Game_Player_Module
#------------------------------------------------------------------------------
# �}�b�v��ŃA�N�^�[�����ړ�������
#==============================================================================

module Train_Actor

module Game_Player_Module
  attr_reader :move_speed
  attr_reader :step_anime

  def update_party_actors
    if $game_party.actors.empty?
      return
    end
    $game_party.update_party_actors
    if not $game_party.actors[0].dead?
      return
    end
    $game_party.actors.each do |actor|
      if actor.dead?
        next
      end
      @character_name = actor.character_name
      @character_hue = actor.character_hue
      break
    end
  end
  def update
    update_party_actors
    super
  end
  def moveto( x, y )
    $game_party.moveto_party_actors( x, y )
    super( x, y )
  end
  def move_down(turn_enabled = true)
    if passable?(@x, @y, Input::DOWN)
      $game_party.move_down_party_actors(turn_enabled)
    end
    super(turn_enabled)
  end
  def move_left(turn_enabled = true)
    if passable?(@x, @y, Input::LEFT)
      $game_party.move_left_party_actors(turn_enabled)
    end
    super(turn_enabled)
  end
  def move_right(turn_enabled = true)
    if passable?(@x, @y, Input::RIGHT)
      $game_party.move_right_party_actors(turn_enabled)
    end
    super(turn_enabled)
  end
  def move_up(turn_enabled = true)
    if passable?(@x, @y, Input::UP)
      $game_party.move_up_party_actors(turn_enabled)
    end
    super(turn_enabled)
  end
  def move_lower_left
    # �������A������ �̂ǂ��炩�̃R�[�X���ʍs�\�ȏꍇ
    if (passable?(@x, @y, Input::DOWN) and passable?(@x, @y + 1, Input::LEFT)) or
       (passable?(@x, @y, Input::LEFT) and passable?(@x - 1, @y, Input::DOWN))
      $game_party.move_lower_left_party_actors
    end
    super
  end
  def move_lower_right
    # �����E�A�E���� �̂ǂ��炩�̃R�[�X���ʍs�\�ȏꍇ
    if (passable?(@x, @y, Input::DOWN) and passable?(@x, @y + 1, Input::RIGHT)) or
       (passable?(@x, @y, Input::RIGHT) and passable?(@x + 1, @y, Input::DOWN))
      $game_party.move_lower_right_party_actors
    end
    super
  end
  def move_upper_left
    # �と���A������ �̂ǂ��炩�̃R�[�X���ʍs�\�ȏꍇ
    if (passable?(@x, @y, Input::UP) and passable?(@x, @y - 1, Input::LEFT)) or
       (passable?(@x, @y, Input::LEFT) and passable?(@x - 1, @y, Input::UP))
      $game_party.move_upper_left_party_actors
    end
    super
  end
  def move_upper_right
    # �と�E�A�E���� �̂ǂ��炩�̃R�[�X���ʍs�\�ȏꍇ
    if (passable?(@x, @y, Input::UP) and passable?(@x, @y - 1, Input::RIGHT)) or
       (passable?(@x, @y, Input::RIGHT) and passable?(@x + 1, @y, Input::UP))
      $game_party.move_upper_right_party_actors
    end
    super
  end
  def jump(x_plus, y_plus)
    # �V�������W���v�Z
    new_x = @x + x_plus
    new_y = @y + y_plus
    # ���Z�l�� (0,0) �̏ꍇ���A�W�����v�悪�ʍs�\�ȏꍇ
    if (x_plus == 0 and y_plus == 0) or passable?(new_x, new_y, 0)
      $game_party.jump_party_actors(x_plus, y_plus)
    end
    super(x_plus, y_plus)
  end
end

end

class Game_Player
  include Train_Actor::Game_Player_Module
end
