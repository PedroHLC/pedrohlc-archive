#==============================================================================
# �� Markup_Message_Close
#------------------------------------------------------------------------------
# �����E�B���h�E�N���[�Y
# ���ӁFSprite_Message�Ή���Window_Message�p�ł��B
#==============================================================================

module Markup_Message_Close
  module_function
  def query
    return /^\\close/
  end
  def transfer(bmp, x, y, text, match)
    $scene.message_window.terminate_message
    text[query] = ''
    return x,y,text
  end
end

String_Operation_Module.add_markup(Markup_Message_Close)
