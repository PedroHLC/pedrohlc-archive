#==============================================================================
# �� Window_Actor_Menu_Item
#------------------------------------------------------------------------------
# �A�C�e���A�N�^�[���j���[
# Copyright (C) 2005 fukuyama
#==============================================================================

module DQ

class Window_Actor_Menu_Item < Window_Actor_Menu_Base
  #----------------------------------------------------------------------------
  # ������
  #----------------------------------------------------------------------------
  def initialize(parent,title)
    super(parent,title)

    # ���j���[�ǉ�
    add_menu('�ӂ���', :select_party_backpack)
    add_menu('�ǂ�������', :arrangement_item)
    add_menu('�ӂ��됮��', :arrangement_backpack)
    pack

    # �ʒu�̐ݒ�
    rect = parent.menu_rect(parent.index)
    self.top = parent.top + rect.y
    self.left = parent.left

    # �A�C�e���E�B���h�E�쐬
    @window_item = Window_Item.new(self)

    # �q�E�B���h�E�ɒǉ�
    add_child @window_item
  end

  def backpack
    if get_menu == '�ӂ���'
      return $game_party
    end
    return nil
  end

  def change_actor
    if get_menu == '�ǂ�������'
      delete_child @window_item
      @window_item.visible = false
    elsif get_menu == '�ӂ��됮��'
      delete_child @window_item
      @window_item.visible = false
    else
      add_child @window_item
      @window_item.refresh
      @window_item.visible = true
    end
  end

  def select_party_backpack
    select_actor
  end

  def select_actor
    if self.actor.nil?
      if self.backpack.backpack.item_count == 0
        return
      end
      @window_item.index = 0
    else
      if self.actor.backpack.item_count == 0
        return
      end
      @window_item.index = Item_Facade.equip_items(self.actor).size
      if self.actor.backpack.item_count <= @window_item.index
        @window_item.index = self.actor.backpack.item_count - 1
      end
    end
    set_active_window(Window_Item)
  end

  def arrangement_item
    window = Window_Actor_Menu_Item_Arrange.new(self)
    add_child window
    set_active_window(window.class)
  end

  def arrangement_backpack
  end
end

end
