#==============================================================================
# �� Window_Target_Actor
#------------------------------------------------------------------------------
# �^�[�Q�b�g�A�N�^�[�E�B���h�E
# Copyright (C) 2005 fukuyama
#==============================================================================

module DQ
module Battle

class Window_Target_Actor < Window_Actor_Menu_Base
  #----------------------------------------------------------------------------
  # �A�N�^�[���I�����ꂽ�ꍇ
  #----------------------------------------------------------------------------
  def select_actor
    window = get_window(Window_Actor_Command)
    window.targets = [self.actor]
    top_window.dispose
  end
end

end
end
