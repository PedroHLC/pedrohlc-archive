#==============================================================================
# �� Window_Skill
#------------------------------------------------------------------------------
# �X�L���E�B���h�E
# Copyright (C) 2005 fukuyama
#==============================================================================

module DQ

class Window_Skill < Window_Menu
  include Window_Tree_Module
  include Menu_Log_Skill_Module
  #--------------------------------------------------------------------------
  # ������
  #--------------------------------------------------------------------------
  def initialize(parent)
    super(parent)
    # �ʒu�̐ݒ�
    self.top  = top_window.top
    self.left = parent.right
  end
  #--------------------------------------------------------------------------
  # �X�V
  #--------------------------------------------------------------------------
  def refresh
    self.clear
    @actor = self.parent.actor
    if not @actor.nil?
      skills = Skill_Facade.actor_normal_skills @actor
      skills.each do |skill|
        add_menu(skill, :select_skill)
      end
    end
    super
  end
  #--------------------------------------------------------------------------
  # �X�L���̎擾
  #--------------------------------------------------------------------------
  def skill
    return get_menu
  end
  #--------------------------------------------------------------------------
  # �X�L���I��
  #--------------------------------------------------------------------------
  def select_skill
    actor = get_window(Window_Actor_Menu_Skill).actor
    skill = self.skill
    # �g�p�ł��Ȃ��ꍇ
    if skill == nil or not actor.skill_can_use?(skill.id)
      # SP ������Ȃ��ꍇ�͎g�p�s��
      if skill.sp_cost > actor.sp
        menu_log_use_skill_sp_cost_error(skill,actor)
        return
      end
      # �퓬�s�\�̏ꍇ�͎g�p�s��
      if actor.dead?
        menu_log_use_skill_actor_state_error(skill,actor)
        return
      end
      # ���ُ�Ԃ̏ꍇ�A�����X�L���ȊO�͎g�p�s��
      if skill.atk_f == 0 and actor.restriction == 1
        menu_log_use_skill_actor_state_error(skill,actor)
        return
      end
      return
    end
    # ���� SE �����t
    $game_system.se_play($data_system.decision_se)
    # ���ʔ͈͂������P�̂̏ꍇ
    if skill.scope == 3 or skill.scope == 5
      window = Window_Actor_Menu_Skill_Use.new(self)
      add_child window
      set_active_window(window.class)
      return
    end
    targets = []
    # ���ʔ͈͂������S�̂̏ꍇ
    if skill.scope == 4
      targets = $game_party.actors
    end
    # ���ʔ͈͂������S��(hp0)�̏ꍇ
    if skill.scope == 6
      $game_party.actors.each do |actor|
        targets.push actor if actor.hp0?
      end
    end
    # �X�L�����g�p
    used = Skill_Facade.use_skill(skill,actor,targets)
    # �X�L�����g�����ꍇ
    if used
      menu_log_use_skill(skill,actor,targets)
      @message_end = true
    end
  end
  #--------------------------------------------------------------------------
  # �L�����Z��
  #--------------------------------------------------------------------------
  def input_b
    cancel_se
    self.index = -1
    set_active_window(Window_Actor_Menu_Skill)
  end
  #--------------------------------------------------------------------------
  # ���ڂ̕`��
  #--------------------------------------------------------------------------
  def draw_menu_item(index,color,rect,skill)
    self.contents.font.color = color
    self.contents.fill_rect(rect, Color.new(0, 0, 0, 0))
    self.contents.draw_text(rect, skill.name)
  end
  #---------------------------------------------------------------------------
  # �R���e���c���̍쐬
  def _contents_width
    return _menu_width * 1
  end
  #---------------------------------------------------------------------------
  # �R���e���c�����̍쐬
  def _contents_height
    return _menu_height * 12
  end
  #---------------------------------------------------------------------------
  # ���j���[�����̍쐬
  def _menu_height
    return super
  end
  #---------------------------------------------------------------------------
  # ���j���[���̍쐬
  def _menu_width
    return WINDOW_SKILL_WIDTH
  end
end

end
