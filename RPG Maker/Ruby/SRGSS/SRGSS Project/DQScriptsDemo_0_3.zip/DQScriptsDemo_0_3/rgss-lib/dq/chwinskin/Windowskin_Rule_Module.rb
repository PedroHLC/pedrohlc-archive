#==============================================================================
# �� Windowskin_Rule_Module
#------------------------------------------------------------------------------
# �E�B���h�E�X�L���ύX���W���[��
#==============================================================================

module Windowskin_Rule_Module
  @@windowskin_rules = []
  @@windowskins = []
  #--------------------------------------------------------------------------
  # ���[���N���X�ǉ�
  #--------------------------------------------------------------------------
  def add_windowskin_rule(klass)
    return if @@windowskin_rules.include?(klass)
    @@windowskin_rules.unshift klass
    @@windowskins.unshift klass.windowskin_name
  end
  module_function :add_windowskin_rule

  #--------------------------------------------------------------------------
  # ���[���X�V
  #--------------------------------------------------------------------------
  def update(*arg)
    super(*arg)
    if not @@windowskins.include?($game_system.windowskin_name)
      # ���[���Ŏg�p���Ȃ��X�L���ɕύX����Ă����烋�[���͓K�p���Ȃ��B
      return
    end
    for rule in @@windowskin_rules
      if rule.change?
        if $game_system.windowskin_name != rule.windowskin_name
          $game_system.windowskin_name = rule.windowskin_name
        end
        return
      end
    end
  end
  def normal_color
    if not @@windowskins.include?($game_system.windowskin_name)
      # ���[���Ŏg�p���Ȃ��X�L���ɕύX����Ă����烋�[���͓K�p���Ȃ��B
      return
    end
    for rule in @@windowskin_rules
      if rule.change?
#        if $game_system.windowskin_name != rule.windowskin_name
#          $game_system.windowskin_name = rule.windowskin_name
#        end
        if @normal_color != rule.normal_color
          @normal_color = rule.normal_color
        end
        return @normal_color
      end
    end
    return @normal_color
  end
end

class Window_Base
  include Windowskin_Rule_Module
  alias windowskin_rule_module_normal_color normal_color
  def normal_color
    color = super
    if color.nil?
      return windowskin_rule_module_normal_color
    end
    return color
  end
end
