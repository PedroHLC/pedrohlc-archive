#==============================================================================
# �� Window_Actor_Menu_Base
#------------------------------------------------------------------------------
# �c�p�p�̃A�N�^�[�I���E�B���h�E�x�[�X
# Copyright (C) 2005 fukuyama
#==============================================================================

module DQ

class Window_Actor_Menu_Base < Window_Menu
  include Window_Tree_Module
  #----------------------------------------------------------------------------
  # ������
  #----------------------------------------------------------------------------
  def initialize(parent, title = nil)
    @title = title
    $game_party.actors.each do |actor|
      add_menu(actor.name, :select_actor)
    end
    @index = 0
    @_prev_index = -1
    super(parent)

#    add_input_handler(Input::UP,:change_actor)
#    add_input_handler(Input::DOWN,:change_actor)
  end
  def update
    super
    # �Ƃ肠�����̃��|�[�g�΍�
    if (not Input.press?(Input::UP)) and (not Input.press?(Input::DOWN))
      if @index != @change_actor_index and @index >= 0
        change_actor
        @change_actor_index = @index
      end
    end
  end
  #----------------------------------------------------------------------------
  # �A�N�^�[���I�����ꂽ�ꍇ
  #----------------------------------------------------------------------------
  def select_actor
  end
  #----------------------------------------------------------------------------
  # �A�N�^�[���ύX���ꂽ�ꍇ
  #----------------------------------------------------------------------------
  def change_actor
  end
  #----------------------------------------------------------------------------
  # �A�N�^�[�̎擾
  #----------------------------------------------------------------------------
  def actor
    return nil if @index < 0
    return $game_party.actors[@index]
  end
  #---------------------------------------------------------------------------
  # �R���e���c���̍쐬
  def _contents_width
    return ACTOR_MENU_WIDTH
  end
end

end
