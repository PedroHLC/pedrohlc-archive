#==============================================================================
# �� Window_Actor_Menu_Who
#------------------------------------------------------------------------------
# ����ɁH�E�B���h�E
# Copyright (C) 2005 fukuyama
#==============================================================================

module DQ

class Window_Actor_Menu_Who < Window_Actor_Menu_Base
  #----------------------------------------------------------------------------
  # ������
  #----------------------------------------------------------------------------
  def initialize(parent)
    super(parent,'����ɁH')

    # �ʒu�̐ݒ�
    window = get_window(Window_Item)
    window.adjust_window_top(self)
    window.tile_layout_right(self)
  end

  def select_actor
		unsupport
  end
end

end
