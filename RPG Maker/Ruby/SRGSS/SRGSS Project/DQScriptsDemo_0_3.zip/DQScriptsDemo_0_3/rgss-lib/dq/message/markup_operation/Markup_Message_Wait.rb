#==============================================================================
# �� Markup_Message_Wait
#------------------------------------------------------------------------------
# ���̂P�����܂ł̊Ԋu
# ���ӁFSprite_Message�Ή���Window_Message�p�ł��B
#==============================================================================

module Markup_Message_Wait
  module_function
  def query
    return /^\\wait\[([0-9]+)\]/
  end
  def transfer(instance, bmp, x, y, text, match)
    instance.message_wait = match[1].to_i
    text[query] = ''
    return x,y,text
  end
end

String_Operation_Module.add_markup(Markup_Message_Wait)
