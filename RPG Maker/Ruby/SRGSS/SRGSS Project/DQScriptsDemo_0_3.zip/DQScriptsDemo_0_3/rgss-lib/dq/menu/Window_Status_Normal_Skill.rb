#==============================================================================
# �� Window_Status_Normal_Skilll
#------------------------------------------------------------------------------
# �X�L���E�B���h�E
# Copyright (C) 2005 fukuyama
#==============================================================================

module DQ

class Window_Status_Normal_Skill < Window_Menu
  include Window_Tree_Module
  #--------------------------------------------------------------------------
  # ������
  #--------------------------------------------------------------------------
  def initialize(parent,actor)
    @title = '�����傤'
    @title_align = 1
    @index = -1
    @actor = actor
    if not @actor.nil?
      @skills = Skill_Facade.actor_class_normal_skills @actor
      @skills.each do |skill|
        add_menu(skill, nil)
      end
    end
    super(parent)
    # �ʒu�̐ݒ�
    self.screen_top(16)
    self.screen_right(16)

    remove_input_handler(Input::C)
  end
  #--------------------------------------------------------------------------
  # ���ڂ̕`��
  #--------------------------------------------------------------------------
  def draw_menu_item(index,color,rect,skill)
    self.contents.font.color = color
    self.contents.fill_rect(rect, Color.new(0, 0, 0, 0))
    if @actor.skill_learn?(skill.id)
      self.contents.draw_text(rect, skill.name)
    end
  end
  #---------------------------------------------------------------------------
  # �R���e���c���̍쐬
  def _contents_width
    return _menu_width * 1
  end
  #---------------------------------------------------------------------------
  # ���j���[���̍쐬
  def _menu_width
    return WINDOW_SKILL_WIDTH
  end
end

end
