#==============================================================================
# �� Window_SaveData_Delete
#------------------------------------------------------------------------------
# �Z�[�u�f�[�^�폜�E�B���h�E
# Copyright (C) 2005 fukuyama
#==============================================================================

module DQ

class Window_SaveData_Delete < Window_SaveData
  #--------------------------------------------------------------------------
  # �I��
  #--------------------------------------------------------------------------
  def select_savedata
    if get_menu.nil?
      buzzer_se
      return
    end
    event = Script_Event.new
    event.message("#{@index + 1}�Ԃ̖`���̏����폜���܂����H\\n")

    event.branch_start(['�͂�','������'],2)
    event.branch_item(0)
    event.message("#{@index + 1}�Ԃ̖`���̏����폜���܂����B")
    event.method_call(method(:command_delete_data))

    event.branch_end
    $game_system.map_interpreter.setup event.event_commands, 0
  end
  #--------------------------------------------------------------------------
  # �폜���\�b�h
  #--------------------------------------------------------------------------
  def command_delete_data
    SaveData_Facade.delete(@index)
    dispose
  end
end

end
