#==============================================================================
# �� Window_Actor_Menu_Skill
#------------------------------------------------------------------------------
# �X�L���A�N�^�[���j���[
# Copyright (C) 2005 fukuyama
#==============================================================================

module DQ

class Window_Actor_Menu_Skill < Window_Actor_Menu_Base
  #----------------------------------------------------------------------------
  # ������
  #----------------------------------------------------------------------------
  def initialize(parent,title)
    super(parent,title)

    # �ʒu�̐ݒ�
    rect = parent.menu_rect(parent.index)
    self.x = parent.x + rect.x
    self.y = parent.y + rect.y

    # �X�L���E�B���h�E�쐬
    @window_skill = Window_Skill.new(self)

    # �q�E�B���h�E�ɒǉ�
    add_child @window_skill
  end

  def select_actor
    skills = Skill_Facade.actor_normal_skills self.actor
    if skills.size == 0
      return
    end
    @window_skill.index = 0
    set_active_window(Window_Skill)
  end

  def change_actor
    @window_skill.refresh
  end
end

end
