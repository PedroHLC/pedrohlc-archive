#==============================================================================
# �� Event_Script_Buy_Actor_Select
#------------------------------------------------------------------------------
# �V���b�v�p�C�x���g�X�N���v�g�i�A�N�^�[�j
# Copyright (C) 2005 fukuyama
#==============================================================================

module Event_Script
module Buy_Actor_Select
  @@window = nil

  @@actor = nil
  @@backpack = nil

  module_function
  #----------------------------------------------------------------------------
  # �E�B���h�E���J��
  #----------------------------------------------------------------------------
  def open
    if @@window.nil?
      @@window = DQ::Window_Actor_Menu_Item_Buy.new
      @@actor = nil
      @@backpack = nil
    end
  end

  #----------------------------------------------------------------------------
  # �E�B���h�E�����
  #----------------------------------------------------------------------------
  def close()
    @@window.dispose if not @@window.disposed?
    @@window = nil
  end

  #----------------------------------------------------------------------------
  # �E�B���h�E�̍X�V
  #----------------------------------------------------------------------------
  def update(variable_id)
    if @@window.nil?
      open()
    end
    result = @@window.disposed?
    if result
      @@actor = @@window.actor
      @@backpack = @@window.backpack
      if @@actor.nil?
        $game_variables[variable_id] = -1
      else
        $game_variables[variable_id] = @@actor.id
      end
      if not @@backpack.nil?
        $game_variables[variable_id] = 0
      end
      close()
    else
      @@window.update
    end
    return result
  end

  def actor
    return @@actor
  end
  def backpack
    return @@backpack
  end
end
end
