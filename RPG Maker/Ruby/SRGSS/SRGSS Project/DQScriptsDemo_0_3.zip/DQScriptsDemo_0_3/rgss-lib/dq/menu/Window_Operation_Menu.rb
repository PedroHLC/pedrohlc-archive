#==============================================================================
# �� Window_Operation_Menu
#------------------------------------------------------------------------------
# �������񃁃j���[
# Copyright (C) 2005 fukuyama
#==============================================================================

module DQ

class Window_Operation_Menu < Window_Menu
  include Window_Tree_Module
  #--------------------------------------------------------------------------
  # ������
  #--------------------------------------------------------------------------
  def initialize(parent,title)
    @title = title
    add_menu('�Ȃ�т���',:party_order)
    add_menu('�����Ă�',:config)
    add_menu('������',:unsupport)
    @index = 0
    super(parent)
    # �ʒu�̐ݒ�
    rect = parent.menu_rect(parent.index)
    self.top = parent.top + rect.y
    self.left = parent.left + rect.x
  end

  def party_order
    window = Window_Party_Order.new(self)
    add_child window
    set_active_window(window.class)
  end

  def config
    window = Window_Config.new(self)
    add_child window
    set_active_window(window.class)
  end
end

end
