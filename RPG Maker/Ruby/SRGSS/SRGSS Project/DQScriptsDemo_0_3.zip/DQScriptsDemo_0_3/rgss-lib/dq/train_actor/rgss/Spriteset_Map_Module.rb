#==============================================================================
# �� Spriteset_Map_Module
#------------------------------------------------------------------------------
# �}�b�v��ŃA�N�^�[�����ړ�������
#==============================================================================

module Train_Actor

module Spriteset_Map_Module
  def setup_actor_character_sprites?
    return @setup_actor_character_sprites_flag != nil
  end
  def setup_actor_character_sprites(characters)
    if !setup_actor_character_sprites?
      for character in characters.reverse
        @character_sprites.unshift(
          Sprite_Character.new(@viewport1, character)
        )
      end
      @setup_actor_character_sprites_flag = true
    end
  end
end

end

class Spriteset_Map
  include Train_Actor::Spriteset_Map_Module
end
