#==============================================================================
# �� Window_Command
#------------------------------------------------------------------------------
# �c�p�p�R�}���h�I���E�B���h�E
# Copyright (C) 2005 fukuyama
#==============================================================================

module DQ
class Window_Command < Window_Menu
  # width �́A�g�p����Ȃ�
  def initialize(width,commands)
    commands.each do |name|
      add_menu(name,:selected)
    end
    @index = 0
    super()
    remove_input_handler(Input::C)
    remove_input_handler(Input::B)
  end
  def selected
  end
end
end

# �ȈՑI��\���̃X�N���v�g���C��
module Event_Script
  module_function
  def open_simple_menu(width, commands)
    if @@window_command.nil?
      @@window_command = DQ::Window_Command.new(width,commands)
      @@window_command.screen_center
    end
    return @@window_command
  end
end
