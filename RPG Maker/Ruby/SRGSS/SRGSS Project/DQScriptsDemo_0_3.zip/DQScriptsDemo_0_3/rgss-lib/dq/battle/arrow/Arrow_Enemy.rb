#==============================================================================
# �� Arrow_Enemy
#------------------------------------------------------------------------------
# �c�p�p�G�l�~�[�A���[
# Copyright (C) 2005 fukuyama
#==============================================================================

module DQ
module Battle

class Arrow_Enemy < Arrow_Base
  attr_accessor :enemy
  def initialize(viewport,enemy)
    @enemy = enemy
    super(viewport)
  end
  def update
    super
    # �X�v���C�g�̍��W��ݒ�
    if self.enemy != nil
      self.x = self.enemy.screen_x
      self.y = self.enemy.screen_y
    end
  end
  def update_help
  end
end

end
end
