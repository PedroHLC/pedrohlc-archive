#==============================================================================
# �� Battle_Phase_Base
#------------------------------------------------------------------------------
# �퓬�t�F�[�Y�̊�{�N���X
# Copyright (C) 2005 fukuyama
#==============================================================================

module DQ
module Battle

module Battle_Phase_Base_Module

  def update
  end

  def setup_battle_event
    $scene.setup_battle_event
  end

  #--------------------------------------------------------------------------
  # �� ���s����
  #--------------------------------------------------------------------------
  def judge
    return $scene.judge
  end

  #--------------------------------------------------------------------------
  # �� �o�g���I��
  #     result : ���� (0:���� 1:�s�k 2:����)
  #--------------------------------------------------------------------------
  def battle_end(result)
    $scene.battle_end(result)
  end

  def refresh_status_window
    $scene.status_window.refresh
    $scene.status_window.update
  end

  def action_event_start(action_event)
    action_event.brank
    $scene.interpreter.setup action_event.event_commands, 0
  end

end

end
end
