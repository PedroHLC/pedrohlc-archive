#==============================================================================
# �� Window_SaveData_Select
#------------------------------------------------------------------------------
# �Z�[�u�f�[�^�I���E�B���h�E
# Copyright (C) 2005 fukuyama
#==============================================================================

module DQ

class Window_SaveData_Select < Window_SaveData
  def input_b
    if Input.trigger?(Input::B)
      @index = -1
    end
    super
  end
  def interpreter
    update
    return disposed?
  end
  def running?
    return (not disposed?)
  end
end

end
