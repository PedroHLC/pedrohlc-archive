#==============================================================================
# �� Scene_Map_Module
#------------------------------------------------------------------------------
# �}�b�v��ŃA�N�^�[�����ړ�������
#==============================================================================

module Train_Actor

module Scene_Map_Module
  def setup_actor_character_sprites(characters)
    @spriteset.setup_actor_character_sprites(characters)
  end
end

end

class Scene_Map
  include Train_Actor::Scene_Map_Module
end
