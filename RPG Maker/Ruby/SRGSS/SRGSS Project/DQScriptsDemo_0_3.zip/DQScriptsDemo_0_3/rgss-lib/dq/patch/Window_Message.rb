#==============================================================================
# �� Window_Message
#------------------------------------------------------------------------------
# ���͕\���Ɏg�����b�Z�[�W�E�B���h�E�ł��B
# Copyright (C) 2005 fukuyama
#==============================================================================

module DQ

class Window_Message < ::Window_Message
  #--------------------------------------------------------------------------
  # ������
  #--------------------------------------------------------------------------
  def initialize
    super()
  end
  #--------------------------------------------------------------------------
  # �� �E�B���h�E�̈ʒu�ƕs�����x�̐ݒ�
  #--------------------------------------------------------------------------
  def reset_window
    super
    self.back_opacity = WINDOW_BACK_OPACITY
  end
end

end

module Set_Window_Message_SE
  def initialize(*arg)
    super(*arg)
    @command_window_popup_se = DQ::COMMAND_WINDOW_POPUP_SE
    @input_number_window_se = DQ::INPUT_NUMBER_WINDOW_POPUP_SE
  end
end

class Window_Message
  include Set_Window_Message_SE
end
