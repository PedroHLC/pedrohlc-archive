#==============================================================================
# �� Window_SaveData_Continue
#------------------------------------------------------------------------------
# �Z�[�u�f�[�^�I���E�B���h�E
# Copyright (C) 2005 fukuyama
#==============================================================================

module DQ

class Window_SaveData_Continue < Window_SaveData
  #--------------------------------------------------------------------------
  # �I��
  #--------------------------------------------------------------------------
  def select_savedata
    if get_menu.nil?
      buzzer_se
      return
    end
    SaveData_Facade.load(@index)
    $scene = Scene_Map.new
    dispose
  end
end

end
