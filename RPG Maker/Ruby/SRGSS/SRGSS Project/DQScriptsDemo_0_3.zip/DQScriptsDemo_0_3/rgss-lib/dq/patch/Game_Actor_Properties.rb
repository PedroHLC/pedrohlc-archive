#==============================================================================
# �� Game_Actor_Properties
#------------------------------------------------------------------------------
# �c�p�p�A�N�^�[���
# Copyright (C) 2005 fukuyama
#==============================================================================

module Game_Actor_Properties
  def setup_all_actor(key,vals)
    $data_actors.each_index do |i|
      if (not $game_actors[i].nil?) and
         (not vals[i].nil?)
        $game_actors[i].properties[key] = vals[i]
      end
    end
  end
  module_function :setup_all_actor

  module Game_Actor_Module
    PROPERTY_JOB = 'job'
    PROPERTY_SEX = 'sex'
    def default_properties
      properties = super
      properties[PROPERTY_JOB] = $data_classes[@class_id].name
      properties[PROPERTY_SEX] = '�H�H�H'
      return properties
    end
  end
end # module Game_Actor_Properties

class Game_Actor
  include Properties_Interface_Module
  include Game_Actor_Properties::Game_Actor_Module
end

