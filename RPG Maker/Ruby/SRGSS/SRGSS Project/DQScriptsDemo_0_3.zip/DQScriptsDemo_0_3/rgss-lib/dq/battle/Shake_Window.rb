#==============================================================================
# �� Shake_Window
#------------------------------------------------------------------------------
# �퓬���ɃE�B���h�E���V�F�C�N����N���X
# Copyright (C) 2005 fukuyama
#==============================================================================

module DQ
module Battle

  class Shake_Window < Shake_Util
    def start_shake(*arg)
      @status_window_x = $scene.status_window.x
      @status_window_y = $scene.status_window.y
      @message_window_x = $scene.message_window.x
      @message_window_y = $scene.message_window.y
      super(*arg)
    end
    def update_interpreter
      result = super() do |mode,n|
        if mode
          $scene.status_window.x += n
          $scene.message_window.x += n
        else
          $scene.status_window.y += n
          $scene.message_window.y += n
        end
      end
      if result
        $scene.status_window.x = @status_window_x
        $scene.status_window.y = @status_window_y
        $scene.message_window.x = @message_window_x
        $scene.message_window.y = @message_window_y
      end
      return result
    end
  end

end
end
