#==============================================================================
# �� Window_Item_Trade
#------------------------------------------------------------------------------
# �킽���A�C�e���E�B���h�E
# Copyright (C) 2005 fukuyama
#==============================================================================

module DQ

class Window_Item_Trade < Window_Item_Base
  include Menu_Log_Item_Module

  #--------------------------------------------------------------------------
  # ������
  #--------------------------------------------------------------------------
  def initialize(parent)
    @row_max = 12
    super(parent)
    # �ʒu�̐ݒ�
    self.top  = top_window.top
    self.left = parent.right
  end
  #--------------------------------------------------------------------------
  # �A�N�^�[�A�C�e���̍X�V
  #--------------------------------------------------------------------------
  def refresh_actor_items
    super
    return if self.parent.actor.nil?
    item  = get_window(Window_Item).item
    if self.parent.actor.backpack.addit?(item)
      add_menu(nil, :select_item)
    end
  end
  #--------------------------------------------------------------------------
  # �ĕ`��
  #--------------------------------------------------------------------------
  def refresh
    self.clear
    refresh_actor_items
    super
  end
  #--------------------------------------------------------------------------
  # �X�V
  #--------------------------------------------------------------------------
  def update
    if @message_end
      get_window(Window_Item_Menu).dispose
      get_window(Window_Item).refresh
      return
    end
    super
  end
  #--------------------------------------------------------------------------
  # �A�C�e���̑I��
  #--------------------------------------------------------------------------
  def select_item
    from_actor = get_window(Window_Actor_Menu_Item).actor
    from_actor = get_window(Window_Actor_Menu_Item).backpack if from_actor.nil?
    from_item  = get_window(Window_Item).item
    to_actor = @actor
    to_item  = item
    # �������Œ肳��Ă���ꍇ
    if Item_Facade.actor_equip?(to_item,to_actor)
      if Item_Facade.equip_fix?(to_item,to_actor)
        menu_log_trade_item_fix(to_item,to_actor)
        return
      end
    end
    Item_Facade.trade_item(from_actor,from_item,to_actor,to_item)
    case from_actor
    when Game_Actor
      if to_item.nil?
        menu_log_hand_item_actor(from_actor,from_item,to_actor)
      else
        menu_log_trade_item_actor(from_actor,from_item,to_actor,to_item)
      end
      @message_end = true
    when Game_Party
      if to_item.nil?
        menu_log_hand_item_party(from_item,to_actor)
      else
        menu_log_trade_item_party(from_item,to_actor,to_item)
      end
      @message_end = true
    end
  end
  #--------------------------------------------------------------------------
  # �L�����Z��
  #--------------------------------------------------------------------------
  def input_b
    cancel_se
    self.index = -1
    set_active_window(Window_Actor_Menu_Item_Trade)
  end
end

end
