#==============================================================================
# �� Battle_AI_Manager
#------------------------------------------------------------------------------
# �퓬�`�h�Ǘ����W���[��
# Copyright (C) 2005 fukuyama
#==============================================================================

module Battle_AI_Manager
  @@operations = []
  @@names = []
	module_function
	def operation_names
		return @@names
	end
	def operations
		return @@operations
	end
	def operation(name)
		return @@operations[@@names.index name]
	end
	def clear_operations
		@@operations.clear
		@@names.clear
	end
	def add_operation(operation)
		return if @@operations.include? operation.name
		@@operations.push operation
		@@names.push operation.name
	end
end
