#==============================================================================
# �� AutoAttack
#------------------------------------------------------------------------------
# �����U���`�h
# Copyright (C) 2005 fukuyama
#==============================================================================

module Battle_AI

class AutoAttack < Battle_AI_Base
	def make_action
		setup_normal_attack(targets[0])
	end
end

end
