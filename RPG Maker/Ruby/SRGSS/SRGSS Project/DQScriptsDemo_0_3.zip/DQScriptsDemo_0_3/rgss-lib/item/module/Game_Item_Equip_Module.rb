#------------------------------------------------------------------------------
# �����A�C�e�����
# Copyright (C) 2005 fukuyama
#------------------------------------------------------------------------------

module Game_Item_Equip_Module
  def initialize(*arg)
    @pdef = 0
    @mdef = 0
    super(*arg)
  end

  def setup(item)
    super(item)
    @pdef = item.pdef
    @mdef = item.mdef
  end

  attr_accessor :pdef
  attr_accessor :mdef
end
