#------------------------------------------------------------------------------
# �A�j���[�V�����Ǘ����
# Copyright (C) 2005 fukuyama
#------------------------------------------------------------------------------

module Game_Item_Animation_Module
  def initialize(*arg)
    @animation1_id = 0
    @animation2_id = 0
    super(*arg)
  end

  def setup(item)
    super(item)
    @animation1_id = item.animation1_id
    @animation2_id = item.animation2_id
  end

  attr_accessor :animation1_id
  attr_accessor :animation2_id
end
