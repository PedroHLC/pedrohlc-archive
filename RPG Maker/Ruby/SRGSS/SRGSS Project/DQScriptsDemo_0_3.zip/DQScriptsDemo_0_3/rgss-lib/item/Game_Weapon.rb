#==============================================================================
# �� Game_Weapon
#------------------------------------------------------------------------------
# ����A�C�e���N���X
# Copyright (C) 2005 fukuyama
#==============================================================================

class Game_Weapon < Game_Item_Base
  include Game_Item_Animation_Module
  include Game_Item_Ability_Plus_Module
  include Game_Item_Equip_Module

  def initialize(id = nil)
    @atk = 0
    @element_set = []
    @plus_state_set = []
    @minus_state_set = []
    super()
    setup($data_weapons[id]) if not id.nil?
  end

  def setup(item)
    super(item)
    @atk             = item.atk
    @element_set     = item.element_set
    @plus_state_set  = item.plus_state_set
    @minus_state_set = item.minus_state_set
  end

  attr_accessor :atk
  attr_accessor :element_set
  attr_accessor :plus_state_set
  attr_accessor :minus_state_set

end
