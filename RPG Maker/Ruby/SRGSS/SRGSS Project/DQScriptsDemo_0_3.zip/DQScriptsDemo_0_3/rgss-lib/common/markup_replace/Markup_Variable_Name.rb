#==============================================================================
# �� Markup_Variable_Name
#------------------------------------------------------------------------------
# �}�[�N�A�b�v�ϐ���
# Copyright (C) 2005 fukuyama
#==============================================================================
#
# \VN[�ϐ�ID] �ϐ��̖��O�ɒu��������
#
#==============================================================================

module Markup_Variable_Name
  module_function
  def query
    return /\\VN\[([0-9]+)\]/
  end
  def transfer(obj, text, match)
    str = $data_system.variables[match[1].to_i]
    if str.nil?
      text[query] = ''
    else
      text[query] = str
    end
  end
end

String_Replace_Module.add_markup(Markup_Variable_Name)
