#==============================================================================
# �� Markup_Font_Size
#------------------------------------------------------------------------------
# �}�[�N�A�b�v�t�H���g�T�C�Y
# Copyright (C) 2005 fukuyama
#==============================================================================
#
# \FS[���l]  �t�H���g�T�C�Y�ύX
#
#==============================================================================

module Markup_Font_Size
  module_function
  def query
    return /^\\FS\[([0-9]*)\]/
  end
  def transfer(bmp, x, y, text, match)
    bmp.font.size = match[1].to_i
    text[query] = ''
    return x,y,text
  end
end

String_Operation_Module.add_markup(Markup_Font_Size)
