#==============================================================================
# �� Markup_Items
#------------------------------------------------------------------------------
# �}�[�N�A�b�v�A�C�e��
# Copyright (C) 2005 fukuyama
#==============================================================================
#
# \item[id]  �w��h�c�̃A�C�e����\������
# \weapon[id]  �w��h�c�̕����\������
# \armor[id]  �w��h�c�̖h���\������
# ���ӁF��ʒ[�ŕ\�������Ɛh���c
#
#==============================================================================

module Markup_Item
  module_function
  def query
    return /^\\item\[([0-9]+)\]/
  end
  def transfer(bmp, x, y, text, match)
    id = match[1].to_i
    item = $data_items[id]
    icon = RPG::Cache.icon(item.icon_name)
    size = bmp.font.size
    bmp.stretch_blt(Rect.new(x, y, size, size), icon, icon.rect)
    text[query] = item.name
    return x + size,y,text
  end
end

module Markup_Weapon
  module_function
  def query
    return /^\\weapon\[([0-9]+)\]/
  end
  def transfer(bmp, x, y, text, match)
    id = match[1].to_i
    item = $data_weapons[id]
    icon = RPG::Cache.icon(item.icon_name)
    size = bmp.font.size
    bmp.stretch_blt(Rect.new(x, y, size, size), icon, icon.rect)
    text[query] = item.name
    return x + size,y,text
  end
end

module Markup_Armor
  module_function
  def query
    return /^\\armor\[([0-9]+)\]/
  end
  def transfer(bmp, x, y, text, match)
    id = match[1].to_i
    item = $data_armors[id]
    icon = RPG::Cache.icon(item.icon_name)
    size = bmp.font.size
    bmp.stretch_blt(Rect.new(x, y, size, size), icon, icon.rect)
    text[query] = item.name
    return x + size,y,text
  end
end

String_Operation_Module.add_markup(Markup_Item)
String_Operation_Module.add_markup(Markup_Weapon)
String_Operation_Module.add_markup(Markup_Armor)
