#==============================================================================
# �� String_Operation_Module
#------------------------------------------------------------------------------
# �����񐧌�
# Copyright (C) 2005 fukuyama
#==============================================================================
#
# Bitmap��Window��Sprite��include�ł���i�\��j
#
#==============================================================================

module String_Operation_Module

  @@markup_operation_list = [] # ����p�}�[�N�A�b�v�N���X���X�g

  #--------------------------------------------------------------------------
  # �� �}�[�N�A�b�v�N���X�ǉ�
  #--------------------------------------------------------------------------
  def add_markup(klass)
    return if @@markup_operation_list.include?(klass)
    @@markup_operation_list.push klass
  end
  module_function :add_markup

  #--------------------------------------------------------------------------
  # �� �}�[�N�A�b�v����
  #--------------------------------------------------------------------------
  def markup_operation(x,y,text)
    case self
    when Bitmap
      bmp = self
    when Window
      bmp = self.contents
    when Sprite
      bmp = self.bitmap
    else
      return x,y,text
    end
    loop do
      replace = false
      @@markup_operation_list.each do |klass|
        if text =~ klass.query
          case klass.method(:transfer).arity
          when 5
            x,y,text = klass.transfer(bmp, x, y, text, $~)
          when 6
            x,y,text = klass.transfer(self, bmp, x, y, text, $~)
          end
          replace = true
        end
      end
      break if not replace
    end
    return x,y,text
  end
  module_function :markup_operation
end
