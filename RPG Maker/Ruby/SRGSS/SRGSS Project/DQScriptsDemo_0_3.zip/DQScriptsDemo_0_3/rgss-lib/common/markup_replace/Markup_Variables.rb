#==============================================================================
# �� Markup_Variables
#------------------------------------------------------------------------------
# �}�[�N�A�b�v�ϐ�
# Copyright (C) 2005 fukuyama
#==============================================================================
#
# \V[�ϐ�ID] �ϐ��̒l�ɒu��������
#
#==============================================================================

module Markup_Variables
  module_function
  def query
    return /\\V\[([0-9]+)\]/
  end
  def transfer(obj, text, match)
    text[query] = $game_variables[match[1].to_i].to_s
  end
end

String_Replace_Module.add_markup(Markup_Variables)
