#==============================================================================
# �� Markup_Font_Color
#------------------------------------------------------------------------------
# �}�[�N�A�b�v�t�H���g�J���[
# Copyright (C) 2005 fukuyama
#==============================================================================
#
# \C[0�`7]     �w�肳�ꂽ�ԍ��̃J���[�ɕύX����iWindow_Base�Q�Ɓj
# \C[s]        �V�X�e���J���[�ɕύX����iWindow_Base�Q�Ɓj
# \C[n]        �m�[�}���J���[�ɕύX����iWindow_Base�Q�Ɓj
# \C[r,g,b,o]  RGB�J���[�Ɠ����x���w�肵�ăt�H���g�J���[��ύX����
#
#==============================================================================

module Markup_Font_Color
  @@text_color = nil
  module_function
  def setup_text_color(window)
    if @@text_color.nil?
      @@text_color = []
      for i in 0..7
        @@text_color[i] = window.text_color(i)
      end
    end
  end
  def query
    return /^\\C\[([0-7])\]/
  end
  def transfer(bmp, x, y, text, match)
    bmp.font.color = @@text_color[match[1].to_i]
    text[query] = ''
    return x,y,text
  end
end

module Markup_Font_Color_System
  @@system_color = nil
  module_function
  def setup_text_color(window)
    if @@system_color.nil?
      @@system_color = window.system_color
    end
  end
  def query
    return /^\\C\[s\]/
  end
  def transfer(bmp, x, y, text, match)
    bmp.font.color = @@system_color
    text[query] = ''
    return x,y,text
  end
end

module Markup_Font_Color_Normal
  @@normal_color = nil
  module_function
  def setup_text_color(window)
    if @@normal_color.nil?
      @@normal_color = window.normal_color
    end
  end
  def query
    return /^\\C\[n\]/
  end
  def transfer(bmp, x, y, text, match)
    bmp.font.color = @@normal_color
    text[query] = ''
    return x,y,text
  end
end

module Markup_Font_Color_Detail
  module_function
  def query
    return /^\\C\[([0-9]+),([0-9]+),([0-9]+),([0-9]+)\]/
  end
  def transfer(bmp, x, y, text, match)
    r = match[1].to_i
    g = match[2].to_i
    b = match[3].to_i
    o = match[4].to_i
    bmp.font.color = Color.new(r,g,b,o)
    text[query] = ''
    return x,y,text
  end
end

String_Operation_Module.add_markup(Markup_Font_Color)
String_Operation_Module.add_markup(Markup_Font_Color_System)
String_Operation_Module.add_markup(Markup_Font_Color_Normal)
String_Operation_Module.add_markup(Markup_Font_Color_Detail)

# �i�Ƃ肠���������j
# ���ʊ֐������W���[��������ĂȂ��̂ł��̕��@�����v�����Ȃ��c
class Window_Base
  @@markup_initialize = false
  alias initialize_Markup_Font_Color initialize
  def initialize(*arg)
    initialize_Markup_Font_Color(*arg)
    unless @@markup_initialize
      Markup_Font_Color.setup_text_color(self)
      Markup_Font_Color_System.setup_text_color(self)
      Markup_Font_Color_Normal.setup_text_color(self)
      @@markup_initialize = true
    end
  end
end
