
module Win_Inet
  module_function
  def get_http_request(url)
    internetOpen = Win32API.new("wininet.dll","InternetOpen","plppl","l")
    internetOpenUrl = Win32API.new("wininet.dll","InternetOpenUrl","lppllp","l")
    internetReadFile = Win32API.new("wininet.dll","InternetReadFile","lplp","i")
    internetCloseHandle = Win32API.new("wininet.dll","InternetCloseHandle","l","l")

    buffer_size = 1024

    return_buffer = ''

    session = internetOpen.call('RGSS Agent',1,nil,nil,0)
    file = internetOpenUrl.call(session,url,nil,0,0,0)
    loop do
      buf = ' ' * buffer_size
      n = 0
      out = [n].pack('i!')
      result = internetReadFile.call(file,buf,buffer_size,out)
      n = out.unpack('i!')[0]
      if result and n == 0
        break
      end
      return_buffer += buf[0,n]
    end
    internetCloseHandle.call(file)
    internetCloseHandle.call(session)

    return return_buffer
  end
end
