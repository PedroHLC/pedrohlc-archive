#==============================================================================
# �� Game_Player_Input8
#------------------------------------------------------------------------------
# �փN�X�ړ��@�W�������͑Ή�
#==============================================================================

class Game_Player
  #--------------------------------------------------------------------------
  # �ړ����͑���̍X�V����
  #--------------------------------------------------------------------------
  def update_input_move
    if @dir_mode.nil?
      @dir_mode = 2
    end
    # �����{�^����������Ă���΁A���̕����փv���C���[���ړ�
    d = Input.dir8
    case d
    when 4
      d = @dir_mode == 2 ? 1 : 7
    when 6
      d = @dir_mode == 2 ? 3 : 9
    end
    case d
    when 1
      if @x % 2 == 0
        move_left
      else
        move_lower_left
      end
      @dir_mode = 2
    when 2
      move_down
      @dir_mode = 2
    when 3
      if @x % 2 == 0
        move_right
      else
        move_lower_right
      end
      @dir_mode = 2
    when 4
      move_left
    when 6
      move_right
    when 7
      if @x % 2 == 1
        move_left
      else
        move_upper_left
      end
      @dir_mode = 8
    when 8
      move_up
      @dir_mode = 8
    when 9
      if @x % 2 == 1
        move_right
      else
        move_upper_right
      end
      @dir_mode = 8
    end
  end
end
