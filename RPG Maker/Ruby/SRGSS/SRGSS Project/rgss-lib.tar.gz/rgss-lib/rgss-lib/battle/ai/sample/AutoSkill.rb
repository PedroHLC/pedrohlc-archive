#==============================================================================
# �� AutoSkill
#------------------------------------------------------------------------------
# �����X�L���`�h
# Copyright (C) 2005 fukuyama
#==============================================================================

module Battle_AI
  
  class AutoSkill < Battle_AI_Base
    def make_action
      setup_normal_attack(targets[0])
      if not battler.skills.empty?
        skills = []
        battler.skills.each do |skill_id|
          next if not battler.skill_can_use?(skill_id)
          skills.push $data_skills[skill_id]
        end
        if not skills.empty?
          setup_skill(skills[rand(skills.size)],targets[0])
        end
      end
    end
  end
  
end

