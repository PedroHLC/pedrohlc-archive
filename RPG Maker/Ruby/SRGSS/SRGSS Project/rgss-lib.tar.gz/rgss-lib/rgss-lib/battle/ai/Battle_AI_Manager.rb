#==============================================================================
# �� Battle_AI_Manager
#------------------------------------------------------------------------------
# �퓬�`�h�Ǘ����W���[��
# Copyright (C) 2005 fukuyama
#==============================================================================

module Battle_AI_Manager
  @@operations = []
  @@names = []
  module_function
  def names
    return @@names
  end
  def operation(name)
    ai = @@operations[@@names.index(name)]
    return Marshal.load(Marshal.dump(ai))
  end
  def clear_operations
    @@operations.clear
    @@names.clear
  end
  def add_operation(ai)
    return if @@names.include? ai.name
    @@names.push ai.name
    @@operations.push ai
  end
end
