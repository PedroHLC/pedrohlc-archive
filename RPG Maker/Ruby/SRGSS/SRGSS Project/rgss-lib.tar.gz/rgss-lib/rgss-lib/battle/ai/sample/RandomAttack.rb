#==============================================================================
# �� RandomAttack
#------------------------------------------------------------------------------
# �����_���U���`�h
# Copyright (C) 2005 fukuyama
#==============================================================================

module Battle_AI

class RandomAttack < Battle_AI_Base
	def make_action
		setup_normal_attack(targets[rand(targets.size)])
	end
end

end
