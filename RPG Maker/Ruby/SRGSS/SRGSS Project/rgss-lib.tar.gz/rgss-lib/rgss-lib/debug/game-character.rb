# �f�o�b�N�pGame_Character
# Author:: fukuyama
# Date:: 2006/02/09
# Copyright:: Copyright (C) 2006 fukuyama

if $DEBUG
  
  module Debug
    DEBUG_MOVE_SPEED_KEY = [Input::A] unless defined? DEBUG_MOVE_SPEED_KEY
  end
  
  class Game_Character
    # �t���[���X�V (�ړ�)
    alias debug_update_move update_move
    def update_move
      if Debug::DEBUG_MOVE_SPEED_KEY.any? {|k|Input.press?(k)}
        original_move_speed = @move_speed
        @move_speed = 6
        debug_update_move
        @move_speed = original_move_speed
      else
        debug_update_move
      end
    end
  end
  
end
