# �^�[�Q�b�g�X�e�[�^�X�E�B���h�E��\�����郂�W���[��
# Author:: fukuyama
# Date:: 2008/02/19
# Copyright:: Copyright (c) 2008 rgss-lib

module DQ
  
  module Window_Target_Status_Module
    
    # ������
    def initialize_target_status(x,y,w)
      h = Markup_New_Line.line_height * 2 + 32
      @window_target_status = Window_Markup_Text.new(x,y,w,h)
      @window_target_status.back_opacity = self.back_opacity
      
      # �q�E�B���h�E�ɒǉ�
      add_child @window_target_status
      @window_target_status.visible = true
      
      @prev_target_index = -1
    end
    
    # �ĕ`��
    def refresh_target_status
      target_actor = self.actor
      n = target_actor.hp
      m = target_actor.maxhp
      color = '\C[n]'
      if n == 0
        color = '\C[ko]'
      elsif n < m / 4
        color = '\C[cs]'
      end
      n = sprintf("%4d",n)
      m = sprintf("%4d",m)
      text = ''
      text << "\\C[n]\\left[#{$data_system.words.hp}]#{$data_system.words.hp}\\n"
      text << "#{color}\\center_left[#{n} ]#{n}"
      text << "\\C[n]\\center_right[/ #{m}]/ #{m}"
      @window_target_status.set_text(text)
    end
    
    def update
      if @index != @prev_target_index and @index >= 0
        refresh_target_status
        @prev_target_index = @index
      end
      super
    end
    
  end
  
end
