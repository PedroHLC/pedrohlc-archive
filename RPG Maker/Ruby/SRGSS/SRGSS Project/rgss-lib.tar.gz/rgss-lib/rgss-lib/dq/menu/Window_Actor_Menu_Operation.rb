#==============================================================================
# �� Window_Actor_Menu_Operation
#------------------------------------------------------------------------------
# ���܂̂�������E�B���h�E
# Copyright (C) 2005 fukuyama
#==============================================================================

module DQ
  
  class Window_Actor_Menu_Operation < Window_Actor_Menu_Base
    #----------------------------------------------------------------------------
    # ������
    #----------------------------------------------------------------------------
    def initialize(parent)
      @actors = []
      @title_align = 1
      super(parent,'���܂́@��������')
      self.clear
      # ���j���[
      $game_party.actors.each do |actor|
        if not actor.ai_fix?
          add_menu(actor.name, :select_actor)
          @actors.push actor
        end
      end
      # ���j���[�ǉ�
      add_menu('���񂢂�', :select_actor)
      pack
      
      # �ʒu�̐ݒ�
      self.top = top_window.top
      self.left = parent.right
    end
    
    def actor
      return nil if @index < 0
      return @actors[@index]
    end
    
    def select_actor
      window = Window_Battle_AI_Menu.new(self)
      set_active_window(window.class)
    end
    
    #--------------------------------------------------------------------------
    # ���ڂ̕`��
    #--------------------------------------------------------------------------
    def draw_menu_item(index,color,rect,item)
      super(index,color,rect,item)
      if @actors.size <= index
        return
      end
      actor = @actors[index]
      operaion_name = DEFAULT_OPERATION_NAME
      if not actor.ai.nil?
        operaion_name = actor.ai.name
      end
      r = rect.dup
      r.x = 120
      r.width -= 120
      self.contents.draw_text(r,operaion_name)
    end
    #---------------------------------------------------------------------------
    # �R���e���c���̍쐬
    def _contents_width
      return 32 * 10
    end
  end
  
end
