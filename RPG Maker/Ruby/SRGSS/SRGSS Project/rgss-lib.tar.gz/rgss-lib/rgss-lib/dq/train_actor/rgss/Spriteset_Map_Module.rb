# Train_Actor::Spriteset_Map_Module
# Spriteset_Map�p������s���W���[��
# Author:: fukuyama
# Date:: 2007/12/31
# Copyright:: Copyright (C) 2005-2007 rgss-lib

module Train_Actor

  module Spriteset_Map_Module
    def setup_actor_character_sprites?
      return @setup_actor_character_sprites_flag != nil
    end
    def setup_actor_character_sprites(characters)
      if not setup_actor_character_sprites?
        for character in characters.reverse
          @character_sprites.unshift(Sprite_Character.new(@viewport1, character))
        end
        @setup_actor_character_sprites_flag = true
      end
    end
  end

end

class Spriteset_Map
  include Train_Actor::Spriteset_Map_Module
end
