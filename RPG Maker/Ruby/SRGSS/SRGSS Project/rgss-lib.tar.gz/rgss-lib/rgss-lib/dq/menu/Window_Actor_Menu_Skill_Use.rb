#==============================================================================
# �� Window_Actor_Menu_Skill_Use
#------------------------------------------------------------------------------
# �X�L���A�N�^�[���j���[
# Copyright (C) 2005 fukuyama
#==============================================================================

module DQ
  
  class Window_Actor_Menu_Skill_Use < Window_Actor_Menu_Base
    include Menu_Log_Skill_Module
    include Window_Target_Status_Module
    
    #----------------------------------------------------------------------------
    # ������
    #----------------------------------------------------------------------------
    def initialize(parent)
      super(parent,'����ɁH')
      
      # �ʒu�̐ݒ�
      skill_win = get_window(Window_Skill)
      self.top  = skill_win.top
      self.left = skill_win.right
      
      # �ΏۃX�e�[�^�X�E�B���h�E������
      initialize_target_status(self.x,self.bottom,640 - 16 - self.x)
    end
    
    #--------------------------------------------------------------------------
    # �X�V
    #--------------------------------------------------------------------------
    def update
      if @message_end
        dispose
        return
      end
      super
    end
    
    #--------------------------------------------------------------------------
    # �A�N�^�[�I��
    #--------------------------------------------------------------------------
    def select_actor
      target_actor = self.actor
      owner_actor = get_window(Window_Actor_Menu_Skill).actor
      skill = get_window(Window_Skill).skill
      used = Skill_Facade.use_skill(skill,owner_actor,[target_actor])
      # �X�L�����g�����ꍇ
      if used
        refresh_target_status()
        menu_log_use_skill(skill,owner_actor,[target_actor])
        @message_end = true
      end
      return
    end
  end
  
end
