#==============================================================================
# �� Properties
#------------------------------------------------------------------------------
# �c�p�퓬�p�A�N�V�������O�g��
# Copyright (C) 2005 fukuyama
#==============================================================================

unless ::RPG::State.include? Properties_Interface_Module
  module ::RPG
    class State
      include Properties_Interface_Module
    end
  end
end
Properties_Interface_Module.compile_properties 'ActionLogStatus.csv','Data/ActionLogStatus.rxdata'

unless ::RPG::Skill.include? Properties_Interface_Module
  module ::RPG
    class Skill
      include Properties_Interface_Module
    end
  end
end
Properties_Interface_Module.compile_properties 'ActionLogSkills.csv','Data/ActionLogSkills.rxdata'

unless ::RPG::Item.include? Properties_Interface_Module
  module ::RPG
    class Item
      include Properties_Interface_Module
    end
  end
end
Properties_Interface_Module.compile_properties 'ActionLogItems.csv','Data/ActionLogItems.rxdata'
