#==============================================================================
# �� Window_Target_Actor
#------------------------------------------------------------------------------
# �^�[�Q�b�g�A�N�^�[�E�B���h�E
# Copyright (C) 2005 fukuyama
#==============================================================================

module DQ
  module Battle
    
    class Window_Target_Actor < Window_Actor_Menu_Base
      include Window_Target_Status_Module
      # ������
      def initialize(parent)
        super(parent)
        window_actor_command = get_window(Window_Actor_Command)
        self.top  = window_actor_command.top
        self.left = window_actor_command.right
        # ��ʊO�ɂ͂ݏo��ꍇ
        if self.bottom >= 480
          self.bottom = window_actor_command.bottom
        end
        # �ΏۃX�e�[�^�X�E�B���h�E������
        initialize_target_status(self.right,self.top,160)
      end
      
      # �A�N�^�[���I�����ꂽ�ꍇ
      def select_actor
        window = get_window(Window_Actor_Command)
        window.targets = [self.actor]
        top_window.dispose
      end
      def input_left
        cursor_se
        parent.target_enemy(true)
        dispose
      end
      def input_right
        cursor_se
        parent.target_enemy
        dispose
      end
    end
    
  end
end
