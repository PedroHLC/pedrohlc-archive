#==============================================================================
# �� Window_Actor_Menu_Equip
#------------------------------------------------------------------------------
# �����уA�N�^�[���j���[
# Copyright (C) 2005 fukuyama
#==============================================================================

module DQ
  
  class Window_Actor_Menu_Equip < Window_Actor_Menu_Base
    
    # ������
    def initialize(parent)
      super(parent,'������')
      
      # �ʒu�̐ݒ�
      self.top = Markup_New_Line.line_height * 2 + 32 + 16
      self.left = top_window.left
      
      # �A�N�^�[����
      @window_status_equip = Window_Status_Equip.new(self.actor)
      @window_status_equip.top  = self.top
      @window_status_equip.left = self.right
      @window_status_equip.back_opacity = self.back_opacity
      add_child @window_status_equip
      
      # �A�C�e���w���v�E�B���h�E�쐬
      x = top_window.top
      y = top_window.left
      w = self.width + @window_status_equip.width
      h = Markup_New_Line.line_height * 2 + 32
      @window_help = Window_Markup_Text.new(x,y,w,h)
      @window_help.back_opacity = self.back_opacity
      
      # �q�E�B���h�E�ɒǉ�
      add_child @window_help
      @window_help.visible = false
      
      @wizards = []
      @wizards.push Wizard_Equip.new(self,'����',Game_Weapon)
      @wizards.push Wizard_Equip.new(self,'����',Game_Armor,Game_Armor::SHIELD_KIND)
      @wizards.push Wizard_Equip.new(self,'���Ԃ�',Game_Armor,Game_Armor::HELM_KIND)
      @wizards.push Wizard_Equip.new(self,'��낢',Game_Armor,Game_Armor::ARMOR_KIND)
      @wizards.push Wizard_Equip.new(self,'�����i',Game_Armor,Game_Armor::ACCESSORIES_KIND)
      @wizards.each do |w|
        w.window_help = @window_help
      end
    end
    
    def change_actor
      @window_status_equip.actor = self.actor
    end
    
    def select_actor
      @wizard_index = 0
      wizards_active
    end
    
    def next_page
      @wizard_index += 1
      wizards_active
      @window_status_equip.refresh
    end
    
    def prev_page
      @wizard_index -= 1
      wizards_active
      @window_status_equip.refresh
    end
    
    def wizards_active
      @wizards.each do |w|
        w.visible = false
        w.active = false
      end
      if @wizard_index < 0 || @wizards.size <= @wizard_index
        self.active = true
        @window_help.visible = (not self.active)
        return
      end
      self.active = false
      @window_help.visible = (not self.active)
      wizard = @wizards[@wizard_index]
      wizard.actor = self.actor
      wizard.visible = true
      wizard.active = true
      wizard.index = 0
    end
    
  end
  
end
