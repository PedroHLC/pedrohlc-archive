# Game_Battler �o�g���[AI�C��
# Author:: fukuyama
# Date:: 2005
# Copyright:: Copyright (C) 2005,2007 rgss-lib

# �Ƃ肠����AI�̑I���ł��Ȃ��A�N�^�[�ݒ�
$data_ai_fix_actor_id = {
  1 => nil
}

class Game_Battler
  # ����AI�����X�g
  attr_accessor :ai_disable_names
  
  def ai_disable_names
    if @ai_disable_names.nil?
      @ai_disable_names = []
    end
    return @ai_disable_names
  end
  
  def ai=(ai)
    ai_name = ''
    if ai.nil?
      ai_name = ::DQ::DEFAULT_OPERATION_NAME
    else
      ai_name = ai.name
    end
    if self.ai_disable_names.include?(ai_name)
      return nil
    end
    @ai = ai
  end
  
  def ai_fix?
    if self.is_a? Game_Actor
      return $data_ai_fix_actor_id.include?(self.id)
    end
    return false
  end
  
  def ai
    if ai_fix?
      ai_id = $data_ai_fix_actor_id[self.id]
      if ai_id.nil?
        return nil
      end
      name = Battle_AI_Manager.names[ai_id]
      if @ai.nil? or @ai.name != name
        @ai = Battle_AI_Manager.operation(name)
      end
    end
    return @ai
  end
  
end
