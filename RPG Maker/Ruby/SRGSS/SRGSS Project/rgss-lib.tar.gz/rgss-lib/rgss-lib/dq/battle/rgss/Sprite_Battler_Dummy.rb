#==============================================================================
# �� Sprite_Battler_Dummy
#------------------------------------------------------------------------------
# �X�v���C�g�o�g���[�_�~�[
# Copyright (C) 2005 fukuyama
#==============================================================================

class Sprite_Battler_Dummy < RPG::Sprite
  attr_accessor :animation_id
  attr_accessor :animation_hit
  attr_accessor :white_flash
  attr_accessor :blink

  #--------------------------------------------------------------------------
  # ������
  #--------------------------------------------------------------------------
  def initialize(viewport)
    super(viewport)
    @animation_id = 0
    @animation_hit = 0
    @white_flash = false
    @blink = false
  end
  #--------------------------------------------------------------------------
  # �X�V
  #--------------------------------------------------------------------------
  def update
    super
    # ����
#    if @blink
#      blink_on
#    else
#      blink_off
#    end
    # ���t���b�V��
#    if @white_flash
#      whiten
#      @white_flash = false
#    end
    # �A�j���[�V����
    if @animation_id != 0
      animation($data_animations[@animation_id], @animation_hit)
      @animation_id = 0
    end
  end
end
