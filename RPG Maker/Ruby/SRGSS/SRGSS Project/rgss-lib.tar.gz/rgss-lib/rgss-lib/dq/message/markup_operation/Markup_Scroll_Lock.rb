#==============================================================================
# �� Markup_Scroll_Lock
#------------------------------------------------------------------------------
# \scroll_lock  �X�N���[�����b�N
# ���ӁFSprite_Message�Ή���Window_Message�p�ł��B
#==============================================================================

module Markup_Scroll_Lock
  module_function
  def query
    return /^\\scroll_lock/
  end
  def transfer(instance,bmp, x, y, text, match)
    text[query] = ''
    instance.ay = 0
    return x,y,text
  end
end

String_Operation_Module.add_markup(Markup_Scroll_Lock)
