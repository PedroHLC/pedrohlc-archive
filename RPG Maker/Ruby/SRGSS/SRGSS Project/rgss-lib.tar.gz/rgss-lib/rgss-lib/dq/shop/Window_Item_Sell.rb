#==============================================================================
# �� Window_Item_Sell
#------------------------------------------------------------------------------
# �A�C�e�����p�E�B���h�E
# Copyright (C) 2005 fukuyama
#==============================================================================

module DQ

class Window_Item_Sell < Window_Item_Base
  #--------------------------------------------------------------------------
  # ������
  #--------------------------------------------------------------------------
  def initialize(parent,help=true)
    @column_max = 1
    @row_max = 12
    super(parent)
    # �ʒu�̐ݒ�
    self.top  = top_window.top
    self.left = parent.right
  end
  #--------------------------------------------------------------------------
  # �ĕ`��
  #--------------------------------------------------------------------------
  def refresh
    self.clear
    refresh_actor_items
    super
  end
  #--------------------------------------------------------------------------
  # �A�C�e���̑I��
  #--------------------------------------------------------------------------
  def select_item
    if Item_Facade.actor_equip?(item,@actor)
      buzzer_se
      return
    end
    if item.sell_price == 0
      buzzer_se
      return
    end
    decision_se
    top_window.dispose
  end
  #--------------------------------------------------------------------------
  # �L�����Z��
  #--------------------------------------------------------------------------
  def input_b
    cancel_se
    self.index = -1
    set_active_window(parent.class)
  end

  #--------------------------------------------------------------------------
  # ���ڂ̕`��
  #--------------------------------------------------------------------------
  def draw_menu_item(index,color,rect,item)
    self.contents.font.color = color
    name = ''
    name = item.name if not item.nil?

    self.contents.fill_rect(rect, Color.new(0, 0, 0, 0))

    case @actor
    when Game_Actor
      # �������Ă���A�C�e�����H
      if Item_Facade.actor_equip?(item,@actor)
        name = 'E ' + name
      end
    when Game_Party
      if item.is_a?(Game_Item)
        count = @actor.backpack.item_count_id(item.id,Game_Item)
        count_rect = self.contents.text_size(count.to_s)
        count_rect.x = rect.x + WINDOW_ITEM_WIDTH - count_rect.width
        count_rect.y = rect.y
        self.contents.draw_text(count_rect,count.to_s,2)
      end
    end

    self.contents.draw_text(rect, name)

    # �l�i�̕`��
    price = item.sell_price
    price_rect = self.contents.text_size(price.to_s)
    price_rect.x = rect.x + rect.width - price_rect.width
    price_rect.y = rect.y
    self.contents.draw_text(price_rect,price.to_s,2)
  end
  #---------------------------------------------------------------------------
  # �R���e���c���̍쐬
  def _contents_width
    return _menu_width * @column_max
  end
  #---------------------------------------------------------------------------
  # ���j���[���̍쐬
  def _menu_width
    return WINDOW_ITEM_SELL_WIDTH
  end
end

end

