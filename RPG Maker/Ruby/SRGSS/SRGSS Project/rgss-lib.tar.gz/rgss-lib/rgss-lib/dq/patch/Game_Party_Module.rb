# Train_Actor::Game_Party_Module
# Game_Party�p������s���W���[���p�b�`
# Author:: fukuyama
# Date:: 2008/09/11
# Copyright:: Copyright (C) 2008 rgss-lib

if defined? Script_Config and defined? Switches

  module Train_Actor

    module Game_Party_Module
      def moveto_party_actors( x, y )
        setup_actor_character_sprites
        if Script_Config.switch_id('������s�ꏊ�ړ�',false)
          Switches['������s�ꏊ�ړ�'] = false
          ax = x - $game_player.x
          ay = y - $game_player.y
          for character in @characters
            tx = character.x + ax
            ty = character.y + ay
            character.moveto( tx, ty )
          end
        else
          for character in @characters
            character.moveto( x, y )
          end
          @move_list = []
          move_list_setup
        end
      end
    end

  end

end
