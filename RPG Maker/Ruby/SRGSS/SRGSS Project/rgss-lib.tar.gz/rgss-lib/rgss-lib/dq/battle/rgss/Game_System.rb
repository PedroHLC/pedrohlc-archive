#==============================================================================
# �� Game_System
#------------------------------------------------------------------------------
# �퓬�p�̃��[�U�[�R���t�B�O�ݒ�c
#==============================================================================

class Game_System
  #--------------------------------------------------------------------------
  # �� ���J�C���X�^���X�ϐ�
  #--------------------------------------------------------------------------
  attr_accessor :user_default_battle_auto_message_interval
  def user_default_battle_auto_message_interval
    if @user_default_battle_auto_message_interval.nil?
      @user_default_battle_auto_message_interval = DQ::Battle::USER_DEFAULT_BATTLE_AUTO_MESSAGE_INTERVAL
    end
    return @user_default_battle_auto_message_interval
  end
end
