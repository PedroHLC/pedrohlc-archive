#==============================================================================
# �� Window_SaveData_Create
#------------------------------------------------------------------------------
# �Z�[�u�f�[�^�쐬�E�B���h�E
# Copyright (C) 2005 fukuyama
#==============================================================================

module DQ
  
  class Window_SaveData_Create < Window_SaveData
    #--------------------------------------------------------------------------
    # ������
    #--------------------------------------------------------------------------
    def initialize(parent,name)
      @name = name
      super(parent)
    end
    #--------------------------------------------------------------------------
    # �I��
    #--------------------------------------------------------------------------
    def select_savedata
      if not get_menu.nil?
        buzzer_se
        return
      end
      ::Scene_Title.new.command_new_game
      $game_actors[DEFAULT_PLAYER_ACTOR_ID].name = @name
      lv = $game_actors[DEFAULT_PLAYER_ACTOR_ID].level
      SaveData_Facade.save(@index,@name,lv,DEFAULT_CREATE_SAVEDATA_COMMENT)
      super
    end
  end
  
end
