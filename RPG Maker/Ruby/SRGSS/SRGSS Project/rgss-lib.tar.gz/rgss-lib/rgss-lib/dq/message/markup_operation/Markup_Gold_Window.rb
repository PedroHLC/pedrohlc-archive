#==============================================================================
# �� Markup_Gold_Window
#------------------------------------------------------------------------------
# \G  �S�[���h�E�B���h�E�\��
# ���ӁFSprite_Message�Ή���Window_Message�p�ł��B
#==============================================================================

module Markup_Gold_Window
  module_function
  def query
    return /^\\G/
  end
  def transfer(bmp, x, y, text, match)
    if $scene.is_a?(Scene_Map) or $scene.is_a?(Scene_Battle)
      $scene.message_window.create_gold_window
    end
    text[query] = ''
    return x,y,text
  end
end

String_Operation_Module.add_markup(Markup_Gold_Window)
