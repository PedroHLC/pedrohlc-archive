#==============================================================================
# �� Window_Backpack_Arrange
#------------------------------------------------------------------------------
# �ӂ��됮�����j���[�E�B���h�E
# Copyright (C) 2005 fukuyama
#==============================================================================

module DQ

class Window_Backpack_Arrange < Window_Menu
  include Menu_Log_Item_Module
  include Window_Tree_Module
  #--------------------------------------------------------------------------
  # ������
  #--------------------------------------------------------------------------
  def initialize(parent)
    add_menu('����ׂ����',:command_type_sort)
    add_menu('���������������',:command_name_sort)
    @index = 0
    super(parent)
    # �ʒu�̐ݒ�
    item_win = get_window(Window_Actor_Menu_Item)
    self.top  = item_win.top
    self.left = item_win.right
  end
  #--------------------------------------------------------------------------
  # �X�V
  #--------------------------------------------------------------------------
  def update
    if @message_end
      self.dispose
      return
    end
    super
  end
  def command_type_sort
    menu_log_arrange_backpack('���',Item_Facade.method(:arrange_backpack_type))
    @message_end = true
  end
  def command_name_sort
    menu_log_arrange_backpack('����������',Item_Facade.method(:arrange_backpack_name))
    @message_end = true
  end
end

end
