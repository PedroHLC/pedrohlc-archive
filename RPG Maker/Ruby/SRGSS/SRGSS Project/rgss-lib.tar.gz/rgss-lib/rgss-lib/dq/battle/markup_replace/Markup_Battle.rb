#==============================================================================
# �� Markup_Battler
#------------------------------------------------------------------------------
# �퓬���p�}�[�N�A�b�v
# Copyright (C) 2005 fukuyama
#==============================================================================

module DQ
module Battle

module Markup_Battle
  module_function
  def target
    return nil if $scene.phase.nil?
    return nil if not $scene.phase.class.method_defined?('target')
    return $scene.phase.target
  end

  def active_battler
    return nil if $scene.phase.nil?
    return nil if not $scene.phase.class.method_defined?('active_battler')
    return $scene.phase.active_battler
  end

  def skill
    return nil if $scene.phase.nil?
    return nil if not $scene.phase.class.method_defined?('skill')
    return $scene.phase.skill
  end

  def item
    return nil if $scene.phase.nil?
    return nil if not $scene.phase.class.method_defined?('item')
    return $scene.phase.item
  end
end

end
end
