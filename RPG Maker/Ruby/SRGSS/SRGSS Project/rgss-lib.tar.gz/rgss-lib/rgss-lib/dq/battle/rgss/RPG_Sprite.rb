#==============================================================================
# �� RPG_Sprite
#------------------------------------------------------------------------------
# RPG::Sprite�̉���
# Copyright (C) 2005 fukuyama
#==============================================================================

module RPG
  class Sprite
    def effect?
      @_whiten_duration > 0 or
      @_appear_duration > 0 or
      @_escape_duration > 0 or
      @_collapse_duration > 24 or
      @_damage_duration > 0 or
      @_animation_duration > 4
    end
  end
end
