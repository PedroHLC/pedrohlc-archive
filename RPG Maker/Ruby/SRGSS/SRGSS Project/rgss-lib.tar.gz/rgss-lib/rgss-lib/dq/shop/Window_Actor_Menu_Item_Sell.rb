#==============================================================================
# �� Window_Actor_Menu_Item_Sell
#------------------------------------------------------------------------------
# �A�C�e���A�N�^�[���j���[
# Copyright (C) 2005 fukuyama
#==============================================================================

module DQ
  
  class Window_Actor_Menu_Item_Sell < Window_Actor_Menu_Base
    #----------------------------------------------------------------------------
    # �A�C�e���擾
    #----------------------------------------------------------------------------
    def item
      return @window_item.item
    end
    
    #----------------------------------------------------------------------------
    # ������
    #----------------------------------------------------------------------------
    def initialize(parent=nil)
      super(parent,'����́H')
      
      # ���j���[�ǉ�
      add_menu('�ӂ���', :select_actor)
      pack
      
      # �S�[���h�E�B���h�E
      @window_gold = Window_Gold.new
      @window_gold.x = 640 - @window_gold.width - 16
      @window_gold.y = 16
      @window_gold.back_opacity = self.back_opacity
      add_child @window_gold
      @window_gold.active = false
      
      # �ʒu�̐ݒ�
      self.top = @window_gold.bottom
      self.left = @window_gold.left
      
      # �A�C�e���E�B���h�E�쐬
      @window_item = Window_Item_Sell.new(self,false)
      @window_item.right = self.left
      @window_item.top = @window_gold.top
      set_active_window(self.class)
    end
    
    # ����
    def input_c
      if self.item_container.nil? or self.item_container.item_count == 0
        buzzer_se
        return
      end
      super
    end
    
    # �L�����Z��
    def input_b
      if event_handling_trigger?
        @index = -1
      end
      super
    end
    
    def backpack
      if self.get_menu == '�ӂ���'
        return $game_party
      end
      return nil
    end
    
    def item_container
      if self.actor.nil?
        return self.backpack.backpack
      else
        return self.actor.backpack
      end
      return nil
    end
    
    def change_actor
      @window_item.refresh
      @window_item.visible = true
      @window_item.index = -1
    end
    
    def select_actor
      @window_item.index = 0
      set_active_window(@window_item.class)
    end
  end
  
end
