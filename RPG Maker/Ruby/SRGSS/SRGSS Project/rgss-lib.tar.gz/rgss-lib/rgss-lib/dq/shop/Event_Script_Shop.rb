#==============================================================================
# �� Event_Script_Shop
#------------------------------------------------------------------------------
# �V���b�v�p�C�x���g�X�N���v�g�i�A�C�e���j
# Copyright (C) 2005 fukuyama
#==============================================================================

module Event_Script
module Shop

  # ���C���E�B���h�E
  @@window = nil

  # �w������A�C�e��
  @@item = nil

  module_function

  #----------------------------------------------------------------------------
  # ����
  #----------------------------------------------------------------------------
  def buy
    n = 1
    actor = Event_Script::Buy_Actor_Select.actor
    if actor.nil?
      actor = $game_party
    end
    if item?
      Item_Facade.gain_item(@@item.id,n,actor)
    elsif weapon?
      Item_Facade.gain_weapon(@@item.id,n,actor)
    elsif armor?
      Item_Facade.gain_armor(@@item.id,n,actor)
    end
    $game_party.lose_gold( self.buy_price() )
  end
  # �l�i
  def buy_price
    return (@@item.price.to_f * (@@price_rate.to_f / 100.0)).to_i
  end

  #----------------------------------------------------------------------------
  # ����
  #----------------------------------------------------------------------------
  def sell
    item = Event_Script::Sell_Actor_Select.item
    item = Event_Script::Sell_Actor_Select.weapon if item.nil?
    item = Event_Script::Sell_Actor_Select.armor if item.nil?
    actor = Event_Script::Sell_Actor_Select.actor
    if actor.nil?
      actor = $game_party
    end
    Item_Facade.throw_item(item,actor)
    $game_party.gain_gold(item.sell_price)
  end

  #----------------------------------------------------------------------------
  # �̔����i����
  #----------------------------------------------------------------------------
  def price_rate=(rate)
    if not @@window.nil?
      @@window.price_rate = rate
      @@price_rate = rate
    end
  end

  #----------------------------------------------------------------------------
  # �E�B���h�E���J��
  #----------------------------------------------------------------------------
  def open(shop_goods)
    if @@window.nil?
      @@window = DQ::Window_Shop.new(shop_goods)
      @@price_rate = 100
      @@window.visible = true
    end
    @@item = nil
  end

  #----------------------------------------------------------------------------
  # �E�B���h�E�����
  #----------------------------------------------------------------------------
  def close()
    if not @@window.disposed?
      @@window.dispose
    end
    @@window = nil
  end

  #----------------------------------------------------------------------------
  # �E�B���h�E�̍X�V
  #----------------------------------------------------------------------------
  def update(variable_id,price_variable_id = 0)
    result = @@window.disposed?
    if result
      variable_id = Variables.normarize_id(variable_id)
      price_variable_id = Variables.normarize_id(price_variable_id)
      if @@window.item.nil?
        $game_variables[variable_id] = -1
        if price_variable_id > 0
          $game_variables[price_variable_id] = 0
        end
        @@item = nil
      else
        @@item = @@window.item
        $game_variables[variable_id] = @@item.id
        if price_variable_id > 0
          $game_variables[price_variable_id] = self.buy_price()
        end
      end
      $scene.message_window.z = 9998
      close()
    else
      $scene.message_window.z = @@window.z - 10
      @@window.update
    end
    return result
  end

  def item?
    return @@item.is_a?(RPG::Item)
  end
  def weapon?
    return @@item.is_a?(RPG::Weapon)
  end
  def armor?
    return @@item.is_a?(RPG::Armor)
  end
  def item
    return nil if not item?
    return @@item
  end
  def weapon
    return nil if not weapon?
    return @@item
  end
  def armor
    return nil if not armor?
    return @@item
  end

end
end
