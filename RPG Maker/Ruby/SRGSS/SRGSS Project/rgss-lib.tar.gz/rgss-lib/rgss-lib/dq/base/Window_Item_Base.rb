#==============================================================================
# �� Window_Item_Base
#------------------------------------------------------------------------------
# �c�p�p�A�C�e���E�B���h�E�x�[�X
# Copyright (C) 2005 fukuyama
#==============================================================================

module DQ
  
  class Window_Item_Base < Window_Menu
    include Window_Tree_Module
    
    def refresh_menus
      # ���j���[�̕`��
      page = 0
      if @index >= 0
        page,index = @index.divmod page_item_max
      end
      for index in (page * page_item_max) ... ((page + 1) * page_item_max)
        draw_menu(index, normal_color)
      end
      @_refresh_menus = Hash.new(false)
      @_prev_page = page
      @_refresh_menus[page] = true
    end
    def update
      super
      if @index >= 0
        page,index = @index.divmod page_item_max
        if @_prev_page != page and (not @_refresh_menus[page])
          # �A�C�e���̕����̕`��
          for index in (page * page_item_max) ... ((page + 1) * page_item_max)
            draw_menu(index, normal_color)
          end
          @_prev_page = page
          @_refresh_menus[page] = true
        end
      end
    end
    #--------------------------------------------------------------------------
    # �A�C�e���̎擾
    #--------------------------------------------------------------------------
    def item
      return get_menu
    end
    #--------------------------------------------------------------------------
    # ���ڂ̕`��
    #--------------------------------------------------------------------------
    def draw_menu_item(index,color,rect,item)
      self.contents.font.color = color
      name = ''
      name = item.name if not item.nil?
      
      self.contents.fill_rect(rect, Color.new(0, 0, 0, 0))
      
      case @actor
      when Game_Actor
        # �������Ă���A�C�e�����H
        if Item_Facade.actor_equip?(item,@actor)
          name = 'E ' + name
        end
      when Game_Party
        if item.is_a?(Game_Item)
          count = @actor.backpack.item_count_id(item.id,Game_Item)
          count_rect = self.contents.text_size(count.to_s)
          count_rect.x = rect.x + rect.width - count_rect.width
          count_rect.y = rect.y
          self.contents.draw_text(count_rect,count.to_s,2)
        end
      end
      
      self.contents.draw_text(rect, name)
    end
    #--------------------------------------------------------------------------
    # �A�N�^�[�A�C�e���̍X�V
    #--------------------------------------------------------------------------
    def refresh_actor_items
      @actor = self.parent.actor
      @actor = self.parent.backpack if @actor.nil?
      return if @actor.nil?
      
      case @actor
      when Game_Actor
        # �A�N�^�[
        equip_items = Item_Facade.equip_items(@actor)
        equip_items.each do |item|
          add_menu(item, :select_item)
        end
        @actor.backpack.each_item do |item|
          add_menu(item, :select_item) if not equip_items.include?(item)
        end
      when Game_Party
        # �ӂ���̏ꍇ��Game_Item���X�^�b�N�\��
        @actor.backpack.each_stack_item do |item|
          add_menu(item, :select_item)
        end
      end
      
      n = menu_size()
      if n == 0
        self.index = -1
        set_active_window(parent.class)
      elsif n <= @index
        @index = n - 1
      end
    end
    #---------------------------------------------------------------------------
    # �R���e���c���̍쐬
    def _contents_width
      return _menu_width * @column_max
    end
    #---------------------------------------------------------------------------
    # ���j���[���̍쐬
    def _menu_width
      return WINDOW_ITEM_WIDTH
    end
  end
  
end
