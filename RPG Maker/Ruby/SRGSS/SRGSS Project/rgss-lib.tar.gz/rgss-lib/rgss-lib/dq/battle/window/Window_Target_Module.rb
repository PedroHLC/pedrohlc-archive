#==============================================================================
# �� Window_Target_Module
#------------------------------------------------------------------------------
# �^�[�Q�b�g�E�B���h�E���W���[��
# Copyright (C) 2005 fukuyama
#==============================================================================

module DQ
  module Battle
    
    module Window_Target_Module
      def target_actor(last_select = false)
        window = Window_Target_Actor.new(self)
        if last_select
          window.index = window.menu_size - 1
        end
        set_active_window(window.class)
      end
      def target_enemy(last_select = false)
        window = Window_Target_Enemy.new(self)
        if last_select
          window.index = window.menu_size - 1
        end
        set_active_window(window.class)
      end
      def next_window(object)
        if object.scope == 1            # �G�P�̂̏ꍇ
          target_enemy
        elsif object.scope == 2         # �G�S�̂̏ꍇ
          window = get_window(Window_Actor_Command)
          window.targets = $game_troop.enemies
          top_window.dispose
        elsif [3,5].include? object.scope      # �����P�̂̏ꍇ
          target_actor
        elsif [4,6].include? object.scope      # �����S�̂̏ꍇ
          window = get_window(Window_Actor_Command)
          window.targets = $game_party.actors
          top_window.dispose
        elsif 7 == object.scope                    # �g�p�҂̏ꍇ
          window = get_window(Window_Actor_Command)
          window.targets = [window.actor]
          top_window.dispose
        end
      end
    end
    
  end
end
