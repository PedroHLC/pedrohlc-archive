# �V�X�e���f�[�^���[�h���W���[��
# Author:: fukuyama
# Date:: 2008/04/10
# Copyright:: Copyright (c) 2008 rgss-lib

module DQ
  
  if $keybd_event.nil?
    $keybd_event = Win32API.new 'user32.dll', 'keybd_event', ['i', 'i', 'l', 'l'], 'v'
  end
  
  if $screen_mode.nil?
    $screen_mode = 1
  end
  
  cf = Window_Config.create('��ʃ��[�h',[0,1],['FullScreen','Window'])
  cf.get = proc { $screen_mode }
  cf.set = proc do |val|
    if $screen_mode != val
      $keybd_event.call 0xA4, 0, 0, 0
      $keybd_event.call 13, 0, 0, 0
      $keybd_event.call 13, 0, 2, 0
      $keybd_event.call 0xA4, 0, 2, 0
      $screen_mode = val
    end
  end
  
end
