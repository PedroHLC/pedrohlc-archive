#==============================================================================
# �� Game_SaveData
#------------------------------------------------------------------------------
# �Z�[�u�f�[�^�i�`���̏��j
# Copyright (C) 2005 fukuyama
#==============================================================================

module DQ

class Game_SaveData
  def initialize
    @name = ''
    @lv = ''
    @comment = ''
    @playtime = 0
  end

  attr_accessor :name
  attr_accessor :lv
  attr_accessor :comment
  attr_accessor :playtime
end

end

