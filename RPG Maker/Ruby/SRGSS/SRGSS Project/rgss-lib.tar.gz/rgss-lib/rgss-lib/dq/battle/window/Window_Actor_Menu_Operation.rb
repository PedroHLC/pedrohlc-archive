#==============================================================================
# �� Window_Actor_Menu_Operation
#------------------------------------------------------------------------------
# ���܂̂�������E�B���h�E
# Copyright (C) 2005 fukuyama
#==============================================================================

module DQ
  module Battle
    
    class Window_Actor_Menu_Operation < ::DQ::Window_Actor_Menu_Operation
      #--------------------------------------------------------------------------
      # �� �I�u�W�F�N�g������
      #--------------------------------------------------------------------------
      def initialize(parent)
        super(parent)
        
        # �ʒu�̐ݒ�
        self.top = $scene.status_window.bottom
        self.left = $scene.status_window.left
      end
      def select_actor
        window = Window_Battle_AI_Menu.new(self)
        set_active_window(window.class)
      end
    end
    
  end
end
