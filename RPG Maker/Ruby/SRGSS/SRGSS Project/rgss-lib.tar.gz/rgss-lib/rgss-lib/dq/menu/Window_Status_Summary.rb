#==============================================================================
# �� Window_Status_Summary
#------------------------------------------------------------------------------
# �A�N�^�[�ȈՃX�e�[�^�X
# Copyright (C) 2005 fukuyama
#==============================================================================

module DQ
  
  class Window_Status_Summary < Window_Base
    #--------------------------------------------------------------------------
    # �� �I�u�W�F�N�g������
    #--------------------------------------------------------------------------
    def initialize(actor)
      @item_height = ITEM_HEIGHT
      @name_space = 0
      # @name_space = (@item_height * 11 + 32) - (@item_height * 9 + 32 * 2)
      if @name_space < 0
        @name_space = 0
      end
      super(0,0, 32 * 6 + 32, @item_height * 4 + 32 + @name_space)
      self.contents = Bitmap.new(self.width - 32, self.height - 32)
      @actor = actor
      refresh
    end
    #--------------------------------------------------------------------------
    # �� �A�N�^�[�̐ݒ�
    #--------------------------------------------------------------------------
    def actor=(actor)
      if @actor != actor
        @actor = actor
        refresh
      end
    end
    #--------------------------------------------------------------------------
    # �� ���t���b�V��
    #--------------------------------------------------------------------------
    def refresh
      self.contents.clear
      return if @actor.nil?
      actor = @actor
      
       (x,y) = 0,0
      width = self.contents.width
      
      status_system_color = self.system_color
      status_normal_color = self.normal_color
      
      contents.font.color = status_normal_color
      contents.draw_text(x,y,width,@item_height,actor.name,1)
      y += @item_height
      job_name = actor.properties[Game_Actor::PROPERTY_JOB]
      contents.draw_text(x,y,width,@item_height,job_name,1)
      y += @item_height
      y += @name_space / 2
      
      contents.font.color = status_system_color
      rect = contents.text_size('�����ׂF')
      contents.draw_text(x,y,width,@item_height,'�����ׂF',0)
      contents.font.color = status_normal_color
      sex_str = actor.properties[Game_Actor::PROPERTY_SEX]
      contents.draw_text(x + rect.width,y,width - rect.width,@item_height,sex_str,1)
      y += @item_height
      contents.font.color = status_system_color
      contents.draw_text(x,y,rect.width,@item_height,'���x���F',2)
      contents.font.color = status_normal_color
      contents.draw_text(x + rect.width,y,width - rect.width,@item_height,actor.level.to_s,1)

    end
  end
  
end
