# �A�C�e���ڍו\��
# Author:: fukuyama
# Date:: 2008/11/03
# Copyright:: Copyright (c) 2008 rgss-lib

module DQ

  class Window_Item_Menu

    def expansion_menu
      insert_menu(-3,'���傤����',:item_detail)
    end


    def item_detail
      window = Window_Item_Detail.new(self)
      add_child window
      set_active_window(window.class)
    end

  end

  class Window_Item_Detail < Window_Base
    include Window_Tree_Module
    include Event_Handling_Module

    def initialize(parent)
      @item_height = ITEM_HEIGHT
      top = parent.top_window()
      super(parent, top.x, top.y, 32 * 7 + 32, @item_height * 11 + 32)
      self.contents = Bitmap.new(self.width - 32, self.height - 32)
      self.back_opacity = WINDOW_BACK_OPACITY
      @item_window = get_window(Window_Item)
      @item = @item_window.item
      refresh
    end

    def input_up
      @item_window.input_up
    end
    def input_down
      @item_window.input_down
    end

    def input_c
      if event_handling_trigger?
        decision_se
      end
    end

    def input_b
      if event_handling_trigger?
        cancel_se
        if not disposed?
          parent.dispose
        end
      end
    end

    def update
      super
      update_all_handler
    end

    def refresh
      self.contents.clear
    end

  end

end
