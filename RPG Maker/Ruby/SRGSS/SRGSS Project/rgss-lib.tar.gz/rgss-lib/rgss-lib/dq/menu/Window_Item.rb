#==============================================================================
# �� Window_Item
#------------------------------------------------------------------------------
# �A�C�e���E�B���h�E
# Copyright (C) 2005 fukuyama
#==============================================================================

module DQ
  
  class Window_Item < Window_Item_Base
    #--------------------------------------------------------------------------
    # ������
    #--------------------------------------------------------------------------
    def initialize(parent,help=true)
      @column_max = 1
      @row_max = 12
      super(parent)
      # �ʒu�̐ݒ�
      self.top  = top_window.top
      self.left = parent.right
      
      if help
        # �A�C�e���w���v�E�B���h�E�쐬
        x = self.x + self.width
        y = 64 + 16
        w = 640 - x - 16
        h = Markup_New_Line.line_height * 8 + 32
        @window_help = Window_Markup_Text.new(x,y,w,h)
        @window_help.back_opacity = self.back_opacity
        
        # �q�E�B���h�E�ɒǉ�
        add_child @window_help
        @window_help.visible = false
        add_input_handler(Input::UP,:change_item)
        add_input_handler(Input::DOWN,:change_item)
      end
    end
    #--------------------------------------------------------------------------
    # �ĕ`��
    #--------------------------------------------------------------------------
    def refresh
      self.clear
      refresh_actor_items
      refresh_help
      super
    end
    #--------------------------------------------------------------------------
    # �A�C�e�������E�B���h�E�ĕ`��
    #--------------------------------------------------------------------------
    def active_event
      if (not @window_help.nil?) and (not @window_help.disposed?)
        if self.active
          @window_help.visible = true
          refresh_help
        end
      end
    end
    def make_item_status_description
      return '' if @actor.nil?
      return '' if not @actor.is_a?(Game_Actor)
      return '' if item.is_a?(Game_Item)
      text = '\bottom'
      if Item_Facade.equippable?(item,@actor)
        case item
        when Game_Weapon
          a = 0
          b = item.atk
          if not @actor.weapon.nil?
            a = @actor.weapon.atk
          end
        when Game_Armor
          a = 0
          b = item.pdef
          if not @actor.equip_armors[item.kind].nil?
            a = @actor.equip_armors[item.kind].pdef
          end
        end
        text << "\\left[#{a}]."
        text << "\\center_left[��]��"
        text << "\\center_right[ #{b}] #{b}"
      else
        text << "\\left[�����тł��Ȃ�]."
      end
      return text
    end
    #--------------------------------------------------------------------------
    # �w���v�X�V
    #--------------------------------------------------------------------------
    def refresh_help
      if (not @window_help.nil?) and (not @window_help.disposed?)
        if not self.item.nil?
          text = self.item.description.dup
          text << make_item_status_description
          @window_help.set_text text
        else
          @window_help.set_text ""
        end
      end
    end
    #--------------------------------------------------------------------------
    # �A�C�e���ύX
    #--------------------------------------------------------------------------
    def change_item
      if @index >= 0
        refresh_help
      end
    end
    #--------------------------------------------------------------------------
    # �A�C�e���̑I��
    #--------------------------------------------------------------------------
    def select_item
      window = Window_Item_Menu.new(self)
      set_active_window(window.class)
    end
    #--------------------------------------------------------------------------
    # �L�����Z��
    #--------------------------------------------------------------------------
    def input_b
      cancel_se
      self.index = -1
      @window_help.visible = false
      set_active_window(Window_Actor_Menu_Item)
    end
  end
  
end
