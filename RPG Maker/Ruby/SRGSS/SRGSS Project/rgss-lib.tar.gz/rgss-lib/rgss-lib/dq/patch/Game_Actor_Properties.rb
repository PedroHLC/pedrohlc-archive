#==============================================================================
# �� Game_Actor_Properties
#------------------------------------------------------------------------------
# �c�p�p�A�N�^�[���
# Copyright (C) 2005 fukuyama
#==============================================================================

module Game_Actor_Properties
  def setup_all_actor(key,vals)
    $data_actors.each_index do |i|
      if (not $game_actors[i].nil?) and
       (not vals[i].nil?)
        $game_actors[i].properties[key] = vals[i]
      end
    end
  end
  module_function :setup_all_actor
  
  module Game_Actor_Module
    PROPERTY_JOB = 'job'
    PROPERTY_SEX = 'sex'
    def default_properties
      properties = super
      properties[PROPERTY_JOB] = $data_classes[@class_id].name
      properties[PROPERTY_SEX] = '�H�H�H'
      properties.update($data_actors[@actor_id].properties)
      return properties
    end
  end
end # module Game_Actor_Properties

# �A�N�^�[�p�g���v���p�e�B�Ή�
class Game_Actor
  include Properties_Interface_Module
  include Game_Actor_Properties::Game_Actor_Module
end

# �A�N�^�[�p�g���v���p�e�B�f�[�^�쐬
unless ::RPG::Actor.include? Properties_Interface_Module
  module ::RPG
    class Actor
      include Properties_Interface_Module
    end
  end
end
Properties_Interface_Module.compile_properties 'ActorsProperties.csv','Data/ActorsProperties.rxdata'
