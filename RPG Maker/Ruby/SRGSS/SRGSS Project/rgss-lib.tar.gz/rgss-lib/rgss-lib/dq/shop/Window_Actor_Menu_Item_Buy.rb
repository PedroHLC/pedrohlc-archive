#==============================================================================
# �� Window_Actor_Menu_Item_Buy
#------------------------------------------------------------------------------
# �A�C�e���A�N�^�[���j���[
# Copyright (C) 2005 fukuyama
#==============================================================================

module DQ
  
  class Window_Actor_Menu_Item_Buy < Window_Actor_Menu_Base
    #----------------------------------------------------------------------------
    # ������
    #----------------------------------------------------------------------------
    def initialize(parent=nil)
      super(parent,'���ꂪ')
      
      # ���j���[�ǉ�
      add_menu('�ӂ���', :select_actor)
      pack
      
      # �S�[���h�E�B���h�E
      @window_gold = Window_Gold.new
      @window_gold.x = 640 - @window_gold.width - 16
      @window_gold.y = 16
      @window_gold.back_opacity = self.back_opacity
      add_child @window_gold
      @window_gold.active = false
      
      # �ʒu�̐ݒ�
      self.top = @window_gold.bottom
      self.left = @window_gold.left
      
      # �A�C�e���E�B���h�E�쐬
      @window_item = Window_Item.new(self,false)
      @window_item.right = self.left
      @window_item.top = @window_gold.top
      @window_item.active = false
    end
    
    # ����
    def input_c
      if not actor.nil?
        # ���Ԃ�nil�ł����v�����ǁc
        if not actor.backpack.addit?(nil)
          buzzer_se
          return
        end
      end
      super
    end
    
    # �L�����Z��
    def input_b
      if event_handling_trigger?
        @index = -1
      end
      super
    end
    
    def backpack
      if get_menu == '�ӂ���'
        return $game_party
      end
      return nil
    end
    
    def change_actor
      @window_item.refresh
      @window_item.visible = true
    end
    
    def select_actor
      dispose
    end
  end
  
end
