#==============================================================================
# �� Window_Actor_Menu_Item_Arrange
#------------------------------------------------------------------------------
# ����́H�E�B���h�E
# Copyright (C) 2005 fukuyama
#==============================================================================

module DQ

class Window_Actor_Menu_Item_Arrange < Window_Actor_Menu_Base
  include Menu_Log_Item_Module

  #----------------------------------------------------------------------------
  # ������
  #----------------------------------------------------------------------------
  def initialize(parent)
    super(parent,'����́H')

    # ���j���[�ǉ�
    add_menu('���񂢂�', :select_all)
    pack

    # �ʒu�̐ݒ�
    item_win = get_window(Window_Actor_Menu_Item)
    self.top  = item_win.top
    self.left = item_win.right
  end

  #--------------------------------------------------------------------------
  # �X�V
  #--------------------------------------------------------------------------
  def update
    if @message_end
      self.dispose
      return
    end
    super
  end

  #--------------------------------------------------------------------------
  # �A�N�^�[�I��
  #--------------------------------------------------------------------------
  def select_actor
    menu_log_arrange_item([actor])
    @message_end = true
  end
  #--------------------------------------------------------------------------
  # �S���I��
  #--------------------------------------------------------------------------
  def select_all
    menu_log_arrange_item($game_party.actors)
    @message_end = true
  end
end

end
