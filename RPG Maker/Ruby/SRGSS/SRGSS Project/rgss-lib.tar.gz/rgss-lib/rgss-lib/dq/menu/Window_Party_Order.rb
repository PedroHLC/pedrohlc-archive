#==============================================================================
# �� Window_Party_Order
#------------------------------------------------------------------------------
# ���ёւ��p�E�B���h�E
# Copyright (C) 2005 fukuyama
#==============================================================================

module DQ
  
  class Window_Party_Order < Window_Actor_Menu_Base
    #--------------------------------------------------------------------------
    # �� �I�u�W�F�N�g������
    #--------------------------------------------------------------------------
    def initialize(parent)
      super(parent)
      
      # �ʒu�̐ݒ�
      self.top = top_window.top
      self.left = parent.right - parent.width * 0.5
      
      @window_party_order_after = Window_Party_Order_After.new(self)
      add_child @window_party_order_after
    end
    def input_c
      if @index < 0
        decision_se
        for actor in @window_party_order_after.actors
          $game_party.actors.shift
          $game_party.actors.push actor
        end
        $game_player.refresh
        top_window.dispose
      else
        super
      end
    end
    def input_b
      name = @window_party_order_after.get_last_menu
      if not name.nil?
        cancel_se
        @window_party_order_after.remove_menu
        @window_party_order_after.refresh
        
        order_actors = @window_party_order_after.actors
        
        clear
        for actor in $game_party.actors
          flag = true
          for order_actor in order_actors
            if order_actor == actor
              flag = false
            end
          end
          add_menu(actor.name,:select_actor) if flag
        end
        refresh
        if @index < 0
          @index = 0
        end
      else
        super
      end
    end
    def select_actor
      @window_party_order_after.add_menu(get_menu,nil)
      @window_party_order_after.refresh
      
      remove_menu @index
      refresh
      
      if get_menu.nil?
        @index -= 1
      end
    end
  end
  
  class Window_Party_Order_After < Window_Menu
    #--------------------------------------------------------------------------
    # �� �I�u�W�F�N�g������
    #--------------------------------------------------------------------------
    def initialize(parent)
      @parent = parent
      
      super()
      
      # �ʒu�̐ݒ�
      self.top = parent.top
      self.left = parent.right
    end
    #--------------------------------------------------------------------------
    # �A�N�^�[�̎擾
    #--------------------------------------------------------------------------
    def actors
      rv = []
      for menu in @menus
        name = menu.name
        for actor in $game_party.actors
          if actor.name == name
            rv.push actor
            break
          end
        end
      end
      return rv
    end
    #--------------------------------------------------------------------------
    # ���ڂ̕`��
    #--------------------------------------------------------------------------
    def draw_menu_item(index,color,rect,name)
      super(index,color,rect,"#{index + 1} #{name}")
    end
    #---------------------------------------------------------------------------
    # �R���e���c���̍쐬
    def _contents_width
      return @parent._contents_width + 32
    end
    #---------------------------------------------------------------------------
    # �R���e���c�����̍쐬
    def _contents_height
      return @parent._contents_height
    end
    #---------------------------------------------------------------------------
    # ���j���[�����̍쐬
    def _menu_height
      return @parent._menu_height
    end
    #---------------------------------------------------------------------------
    # ���j���[���̍쐬
    def _menu_width
      return @parent._menu_width + 32
    end
  end
  
end
