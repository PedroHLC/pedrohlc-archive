#==============================================================================
# �� Event_Script
#------------------------------------------------------------------------------
# �c�p�p�H�C�x���g�X�N���v�g
# Copyright (C) 2005,2007 fukuyama
#==============================================================================

module Event_Script
  @@window_savedata_select = nil
  @@window_savedata_select_index = -1
  
  module_function
  #--------------------------------------------------------------------------
  # �Z�[�u�ӏ��̑I��
  #--------------------------------------------------------------------------
  def savedata_select(variable_id=nil)
    if @@window_savedata_select.nil?
      @@window_savedata_select = DQ::Window_SaveData_Select.new
      @@window_savedata_select.index = $game_temp.last_file_index
    end
    if @@window_savedata_select.disposed?
      if not variable_id.nil?
        $game_variables[variable_id] = @@window_savedata_select.index
      else
        @@window_savedata_select_index = @@window_savedata_select.index
      end
      @@window_savedata_select = nil
      return true
    end
    @@window_savedata_select.update
    return false
  end
  #--------------------------------------------------------------------------
  # �㏑������
  #--------------------------------------------------------------------------
  def savedata_overwrite?(variable_id=nil)
    index = @@window_savedata_select_index
    if not variable_id.nil?
      index = $game_variables[variable_id]
    end
    savedatas = DQ::SaveData_Facade.load_index
    return (not savedatas[index].nil?)
  end
  #--------------------------------------------------------------------------
  # �Z�[�u
  #--------------------------------------------------------------------------
  def save(*args)
    index,name,lv,comment = *args
    if not index.is_a?(Numeric)
      index = @@window_savedata_select_index
    end
    if index < 0
      return true
    end
    if name.nil?
      name = $game_actors[DQ::DEFAULT_PLAYER_ACTOR_ID].name
    end
    if not lv.is_a?(Numeric)
      lv = $game_actors[DQ::DEFAULT_PLAYER_ACTOR_ID].level
    end
    if comment.nil?
      data_map_infos = Data_Loader.data_map_infos
      comment = data_map_infos[$game_map.map_id].name
    end
    $game_system.map_interpreter.index += 1
    DQ::SaveData_Facade.save(index,name,lv,comment)
    $game_system.map_interpreter.index -= 1
    return true
  end
end

class Interpreter
  attr_accessor :index # XXX
end

