#==============================================================================
# �� Window_Actor_Menu_Item_Use
#------------------------------------------------------------------------------
# ����ɁH�E�B���h�E
# Copyright (C) 2005 fukuyama
#==============================================================================

module DQ
  
  class Window_Actor_Menu_Item_Use < Window_Actor_Menu_Base
    include Menu_Log_Item_Module
    include Window_Target_Status_Module
    
    #----------------------------------------------------------------------------
    # ������
    #----------------------------------------------------------------------------
    def initialize(parent)
      super(parent,'����ɁH')
      
      # �ʒu�̐ݒ�
      item_win = get_window(Window_Item)
      self.top  = item_win.top
      self.left = item_win.right
      
      # �ΏۃX�e�[�^�X�E�B���h�E������
      initialize_target_status(self.x,self.bottom,640 - 16 - self.x)
    end
    
    #--------------------------------------------------------------------------
    # �X�V
    #--------------------------------------------------------------------------
    def update
      if @message_end
        get_window(Window_Item_Menu).dispose
        get_window(Window_Item).refresh
        return
      end
      super
    end
    
    #--------------------------------------------------------------------------
    # �A�N�^�[�I��
    #--------------------------------------------------------------------------
    def select_actor
      target_actor = self.actor
      owner_actor = get_window(Window_Actor_Menu_Item).actor
      owner_actor = get_window(Window_Actor_Menu_Item).backpack if owner_actor.nil?
      item = get_window(Window_Item).item
      if not Item_Facade.item_can_use?(item,owner_actor,target_actor)
        menu_log_use_item_miss(item,owner_actor,target_actor)
        @message_end = true
        return
      end
      used = Item_Facade.use_item(item,owner_actor,[target_actor])
      # �A�C�e�����g�����ꍇ
      if used
        refresh_target_status()
        menu_log_use_item(item,owner_actor,[target_actor])
        @message_end = true
        return
      end
    end
  end
  
end
