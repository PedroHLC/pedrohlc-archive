#==============================================================================
# �� Window_Status_All
#------------------------------------------------------------------------------
# �X�e�[�^�X�S��
# Copyright (C) 2005 fukuyama
#==============================================================================

module DQ
  
  class Window_Status_All < Window_Menu
    include Window_Tree_Module
    #--------------------------------------------------------------------------
    # �� �I�u�W�F�N�g������
    #--------------------------------------------------------------------------
    def initialize(parent)
      @item_height = ITEM_HEIGHT
      @item_width = 110
      @actor_index = 0
      super(parent)
      # �ʒu�̐ݒ�
      screen_center
    end
    #--------------------------------------------------------------------------
    # �� ���t���b�V��
    #--------------------------------------------------------------------------
    def draw_text(x,y,text,align)
      self.contents.draw_text(x, y, @item_width, @item_height, text, align)
      return x, y + @item_height
    end
    def refresh_actor(x,y,actor)
      w = @item_width
      h = @item_height
      c = self.contents
      status_system_color = self.system_color
      status_normal_color = self.normal_color
      
      c.font.color = status_normal_color
      
      # ���O
       (x,y) = draw_text(x,y, actor.name, 0)
      # �g�o
      c.font.color = status_system_color
       (x,y) = draw_text(x,y, $data_system.words.hp, 0)
      c.font.color = status_normal_color
       (x,y) = draw_text(x,y, actor.hp.to_s, 2)
      c.fill_rect(x,y - 1,@item_width,2,status_normal_color)
       (x,y) = draw_text(x,y, actor.maxhp.to_s, 2)
      # �l�o
      c.font.color = status_system_color
       (x,y) = draw_text(x,y, $data_system.words.sp, 0)
      c.font.color = status_normal_color
       (x,y) = draw_text(x,y, actor.sp.to_s, 2)
      c.fill_rect(x,y - 1,@item_width,2,status_normal_color)
       (x,y) = draw_text(x,y, actor.maxsp.to_s, 2)
      # �U����
      c.font.color = status_system_color
       (x,y) = draw_text(x,y, $data_system.words.atk,0)
      c.font.color = status_normal_color
       (x,y) = draw_text(x,y, actor.base_atk.to_s,2)
      # �����h��
      c.font.color = status_system_color
       (x,y) = draw_text(x,y, $data_system.words.pdef,0)
      c.font.color = status_normal_color
       (x,y) = draw_text(x,y, actor.base_pdef.to_s,2)
      # ���@�h��
      c.font.color = status_system_color
       (x,y) = draw_text(x,y, $data_system.words.mdef,0)
      c.font.color = status_normal_color
       (x,y) = draw_text(x,y, actor.base_mdef.to_s,2)
      # �k�u
      c.font.color = status_system_color
      c.draw_text(x, y, w, h, "Lv:", 0)
      c.font.color = status_normal_color
      c.draw_text(x, y, w, h, actor.level.to_s, 2)
    end
    def refresh
      self.contents.clear
       (x,y) = 0,0
      for actor in $game_party.actors[@actor_index,4]
        refresh_actor(x,y,actor)
        x += _menu_width
      end
    end
    #--------------------------------------------------------------------------
    # �E�B���h�E����
    #--------------------------------------------------------------------------
    def input_c
      if $game_party.actors.size > (@actor_index + 4)
        @actor_index += 4
        decision_se
        refresh
        return
      end
      decision_se
      dispose
    end
    
    #---------------------------------------------------------------------------
    # �R���e���c���̍쐬
    def _contents_width
      return _menu_width * 4
    end
    #---------------------------------------------------------------------------
    # �R���e���c�����̍쐬
    def _contents_height
      return @item_height * 14
    end
    #---------------------------------------------------------------------------
    # ���j���[���̍쐬
    def _menu_width
      return (@item_width+18)
    end
  end
  
end
