#==============================================================================
# �� Window_Status
#------------------------------------------------------------------------------
# �퓬�p�X�e�[�^�X�E�B���h�E
# Copyright (C) 2005 fukuyama
#==============================================================================

module DQ
  module Battle
    
    class Window_Status < ::DQ::Window_Main_Menu_Status
      #--------------------------------------------------------------------------
      # �� �I�u�W�F�N�g������
      #--------------------------------------------------------------------------
      def initialize
        super
        @_party_actors_size = $game_party.actors.size
        refresh_battle_status_position
      end
      
      def refresh_battle_status_position
        self.screen_top(16)
        self.left = $scene.message_window.x
        if self.left > 640 - self.right
          self.left = (640 - self.width) / 2
        end
      end
      
      def refresh
        super
        if @_party_actors_size != $game_party.actors.size
          @_party_actors_size = $game_party.actors.size
          refresh_battle_status_position
        end
      end
    end
    
  end
end
