#==============================================================================
# �� Markup_Wait
#------------------------------------------------------------------------------
# �E�F�C�g�}�[�N�A�b�v
# Copyright (C) 2006 fukuyama
#==============================================================================
#
# \w[n] �E�F�C�g
#
#==============================================================================

module Markup_Wait
  module_function
  def query
    return /^(.?)\\w\[([0-9]+)\]/
  end
  def transfer(instance, bmp, x, y, text, match)
    instance.message_wait = match[2].to_i * 2
    if match[1].empty?
      x -= bmp.text_size(' ').width
      text[query] = ' '
    else
      text[query] = match[1].to_s
    end
    return x,y,text
  end
end

String_Operation_Module.add_markup(Markup_Wait)
