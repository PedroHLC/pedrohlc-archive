# Train_Actor::Scene_Map_Module
# Scene_Map�p������s���W���[��
# Author:: fukuyama
# Date:: 2007/12/31
# Copyright:: Copyright (C) 2005-2007 rgss-lib

module Train_Actor

  module Scene_Map_Module
    def setup_actor_character_sprites(characters)
      @spriteset.setup_actor_character_sprites(characters)
    end
  end

end

class Scene_Map
  include Train_Actor::Scene_Map_Module
end
