#==============================================================================
# �� Markup_Auto_Message_Interval
#------------------------------------------------------------------------------
# �������b�Z�[�W����
# ���ӁFSprite_Message�Ή���Window_Message�p�ł��B
#==============================================================================

module Markup_Auto_Message_Interval
  module_function
  def query
    return /^\\auto\[([0-9]+)\]/
  end
  def transfer(bmp, x, y, text, match)
    $scene.message_window.auto_message_interval = match[1].to_i
    text[query] = ''
    return x,y,text
  end
end

String_Operation_Module.add_markup(Markup_Auto_Message_Interval)

module Markup_Auto_Message_Interval_Off
  module_function
  def query
    return /^\\auto_off/
  end
  def transfer(bmp, x, y, text, match)
    $scene.message_window.auto_message_interval = nil
    text[query] = ''
    return x,y,text
  end
end

String_Operation_Module.add_markup(Markup_Auto_Message_Interval_Off)
