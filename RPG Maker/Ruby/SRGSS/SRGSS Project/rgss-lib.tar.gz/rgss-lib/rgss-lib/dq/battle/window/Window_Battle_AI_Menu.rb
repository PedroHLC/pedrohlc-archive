#==============================================================================
# �� Window_Battle_AI_Menu
#------------------------------------------------------------------------------
# �퓬�`�h�I���E�B���h�E
# Copyright (C) 2005 fukuyama
#==============================================================================

module DQ
  module Battle
    
    class Window_Battle_AI_Menu < ::DQ::Window_Battle_AI_Menu
      #--------------------------------------------------------------------------
      # �� �I�u�W�F�N�g������
      #--------------------------------------------------------------------------
      def initialize(parent)
        super(parent)
        
        # �ʒu�̐ݒ�
        self.top = $scene.status_window.bottom
        self.left = parent.right
      end
    end
    
  end
end
