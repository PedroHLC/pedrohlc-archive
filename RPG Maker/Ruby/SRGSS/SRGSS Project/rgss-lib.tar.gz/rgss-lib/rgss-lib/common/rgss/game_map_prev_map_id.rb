# �}�b�v�N���X�g��
# Author:: fukuyama
# Date:: 2008/09/04
# Copyright:: Copyright (C) 2008 rgs-lib

class Game_Temp
  attr_accessor :prev_map_id
end

class Game_Map

  alias prev_map_id_original_setup setup
  def setup(map_id)
    $game_temp.prev_map_id = @map_id
    prev_map_id_original_setup(map_id)
  end

end
