#==============================================================================
# �� Adjust_Window_Module
#------------------------------------------------------------------------------
# �E�B���h�E�ʒu���߃��W���[��
# Copyright (C) 2005 fukuyama
#==============================================================================

module Adjust_Window_Module
  def top
    return self.y
  end
  def bottom
    return self.y + self.height
  end
  def left
    return self.x
  end
  def right
    return self.x + self.width
  end
  def top=(n)
    self.y = n
    return self.y
  end
  def bottom=(n)
    self.y = n - self.height
    return self.y
  end
  def left=(n)
    self.x = n
    return self.x
  end
  def right=(n)
    self.x = n - self.width
    return self.x
  end

  # ��ʂ̒����ɕ\��
  def screen_center
    self.x = 640 / 2 - self.width / 2
    self.y = 480 / 2 - self.height / 2
  end
  # ��ʂ̏�ɕ\��
  def screen_top(margin = 0)
    self.y = 0 + margin
  end
  # ��ʂ̉��ɕ\��
  def screen_bottom(margin = 0)
    self.y = 480 - self.height - margin
  end
  # ��ʂ̍��ɕ\��
  def screen_left(margin = 0)
    self.x = 0 + margin
  end
  # ��ʂ̉E�ɕ\��
  def screen_right(margin = 0)
    self.x = 640 - self.width - margin
  end
end

# Window_Base �� Adjust_Window_Module �̃C���N���[�h
class Window_Base
  include Adjust_Window_Module
end
