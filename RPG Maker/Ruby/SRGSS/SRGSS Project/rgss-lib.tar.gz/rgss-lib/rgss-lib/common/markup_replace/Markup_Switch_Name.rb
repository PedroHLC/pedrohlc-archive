#==============================================================================
# �� Markup_Switch_Name
#------------------------------------------------------------------------------
# �}�[�N�A�b�v�X�C�b�`��
# Copyright (C) 2005 fukuyama
#==============================================================================
#
# \SN[�X�C�b�`ID] �X�C�b�`���ɒu��������
#
#==============================================================================

module Markup_Switch_Name
  module_function
  def query
    return /\\SN\[([0-9]+)\]/
  end
  def transfer(obj, text, match)
    str = $data_system.switches[match[1].to_i]
    if str.nil?
      text[query] = ''
    else
      text[query] = str
    end
  end
end

String_Replace_Module.add_markup(Markup_Switch_Name)
