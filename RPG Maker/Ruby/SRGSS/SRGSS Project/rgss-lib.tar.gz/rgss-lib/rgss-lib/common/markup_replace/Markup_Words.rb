#==============================================================================
# �� Markup_Words
#------------------------------------------------------------------------------
# �V�X�e���p��u������
# Copyright (C) 2005 fukuyama
#==============================================================================
#
# \words[�p��L�[]
#
#==============================================================================

module Markup_Words
  module_function
  def query
    return /\\words\[([a-z]+)\]/
  end
  def transfer(obj, text, match)
    name = match[1].to_s
    text[query] = $data_system.words.method(name).call.to_s
  end
end

String_Replace_Module.add_markup(Markup_Words)
