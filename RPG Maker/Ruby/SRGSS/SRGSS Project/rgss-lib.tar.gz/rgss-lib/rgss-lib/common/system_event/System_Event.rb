
module System_Event

  @@events = {}

  module_function

  def add_title_main(e)
    unless @@events.include? 'title_main'
      @@events['title_main'] = []
    end
    @@events['title_main'].push e
  end

  def exec_title_main
    if @@events.include? 'title_main'
      @@events['title_main'].each do |e|
        e.system_event('title_main')
      end
    end
  end
end
