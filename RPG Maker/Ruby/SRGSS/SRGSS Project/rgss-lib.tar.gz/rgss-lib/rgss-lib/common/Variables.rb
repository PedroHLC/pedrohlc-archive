#==============================================================================
# �� Variables
#------------------------------------------------------------------------------
# �ϐ�
# Copyright (C) 2005 fukuyama
#==============================================================================

module Variables
  module_function

  # key �̕ϐ����擾
  def []( key )
    data_system = Data_Loader.data_system
    n = data_system.variables.index key
    if n.nil?
      return nil
    end
    return $game_variables[n]
  end

  # key �̕ϐ���val�ɂ���
  def []=( key, val )
    data_system = Data_Loader.data_system
    n = data_system.variables.index key
    if n.nil?
      return nil
    end
    return $game_variables[n] = val
  end

  # key �ϐ����݊m�F
  def include?(key)
    data_system = Data_Loader.data_system
    return data_system.variables.include?(key)
  end
  def exist?(key)
    return include?(key)
  end

  # key �ϐ��C���f�b�N�X�擾
  def index(key)
    data_system = Data_Loader.data_system
    return data_system.variables.index(key)
  end

  # ID��NAME�̃X�C�b�`�𐳋K��
  def normarize_id(id_or_name)
    case id_or_name
    when Integer
      return id_or_name
    when String
      return index(id_or_name)
    end
    return id_or_name
  end
end
