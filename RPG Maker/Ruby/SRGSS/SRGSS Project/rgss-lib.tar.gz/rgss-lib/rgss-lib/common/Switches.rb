#==============================================================================
# �� Switches
#------------------------------------------------------------------------------
# �X�C�b�`
# Copyright (C) 2005 fukuyama
#==============================================================================

module Switches
  module_function

  # key �̃X�C�b�`���擾
  def []( key )
    data_system = Data_Loader.data_system
    n = data_system.switches.index key
    if n.nil?
      return nil
    end
    return $game_switches[n]
  end

  # key �̃X�C�b�`��val�ɂ���
  def []=( key, val )
    data_system = Data_Loader.data_system
    n = data_system.switches.index key
    if n.nil?
      return nil
    end
    return $game_switches[n] = val
  end

  # key �X�C�b�`���݊m�F
  # key �ϐ����݊m�F
  def include?(key)
    data_system = Data_Loader.data_system
    return data_system.switches.include?(key)
  end
  def exist?(key)
    return include?(key)
  end

  # key �X�C�b�`�C���f�b�N�X�擾
  def index(key)
    data_system = Data_Loader.data_system
    return data_system.switches.index(key)
  end

  # ID��NAME�̃X�C�b�`�𐳋K��
  def normarize_id(id_or_name)
    case id_or_name
    when Integer
      return id_or_name
    when String
      return index(id_or_name)
    end
    return id_or_name
  end
end
