#==============================================================================
# �� Window_Markup_Text
#------------------------------------------------------------------------------
# �}�[�N�A�b�v�E�B�h�E
# Copyright (C) 2005 fukuyama
#==============================================================================

class Window_Markup_Text < Window_Base
  include String_Replace_Module
  include String_Operation_Module
  include Markup_Text_Module
  
  def initialize(x, y, width, height)
    super(x, y, width, height)
    @text = "" if @text.nil?
    refresh
  end
  def set_text(text)
    # �e�L�X�g���O��ƈ���Ă���ꍇ
    if text != @text
      # �e�L�X�g���ĕ`��
      @text = text
      refresh
    end
  end
  def refresh
    if self.contents.nil?
      self.contents = Bitmap.new(self.width - 32, self.height - 32)
    else
      self.contents.clear
    end
    self.contents.font.color = normal_color
    draw_markup_text(@text)
  end
end
