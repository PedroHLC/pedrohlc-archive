#==============================================================================
# �� Bitmap#draw_text
#------------------------------------------------------------------------------
# �\�����镶�����S�ĉe���ɂ���B
# Copyright (C) 2005 fukuyama
#==============================================================================

# ���`��BRGSS�g�ݍ��݃N���X�́A�\�t�g���Z�b�g����錾����Ȃ��݂���

if (not Bitmap.method_defined?('original_draw_text')) and Module.constants.include?('DRAW_TEXT_TYPE')
  unless Module.constants.include?('DRAW_TEXT_BG_COLOR')
    DRAW_TEXT_BG_COLOR = Color.new(0,0,0,128)
  end
  case DRAW_TEXT_TYPE
    
  when 1
    class Bitmap
      alias original_draw_text draw_text
      def draw_text(*arg)
        
        original_color = self.font.color.dup
        self.font.color = DRAW_TEXT_BG_COLOR
        
        if arg[0].is_a?(Rect)
          arg[0].x += 2
          arg[0].y += 2
          self.original_draw_text(*arg)
          arg[0].x -= 2
          arg[0].y -= 2
        else
          arg[0] += 2
          arg[1] += 2
          self.original_draw_text(*arg)
          arg[0] -= 2
          arg[1] -= 2
        end
        
        self.font.color = original_color
        self.original_draw_text(*arg)
        
      end
    end
    
  when 2
    class Bitmap
      alias original_draw_text draw_text
      def draw_text(*arg)
        
        original_color = self.font.color.dup
        self.font.color = DRAW_TEXT_BG_COLOR
        
        if arg[0].is_a?(Rect)
          arg[0].x += 1
          arg[0].y += 1
          self.original_draw_text(*arg)
          arg[0].x -= 2
          self.original_draw_text(*arg)
          arg[0].y -= 2
          self.original_draw_text(*arg)
          arg[0].x += 2
          self.original_draw_text(*arg)
          arg[0].x -= 1
          arg[0].y += 1
        else
          arg[0] += 1
          arg[1] += 1
          self.original_draw_text(*arg)
          arg[0] -= 2
          self.original_draw_text(*arg)
          arg[1] -= 2
          self.original_draw_text(*arg)
          arg[0] += 2
          self.original_draw_text(*arg)
          arg[0] -= 1
          arg[1] += 1
        end
        
        self.font.color = original_color
        self.original_draw_text(*arg)
        
      end
    end
    
  end # case
  
end
