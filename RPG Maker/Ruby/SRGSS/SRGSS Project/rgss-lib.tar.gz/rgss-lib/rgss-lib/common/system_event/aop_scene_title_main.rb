
class Scene_Title

  alias sys_evt_main main

  def main
    System_Event.exec_title_main
    sys_evt_main
  end

end
