#==============================================================================
# �� Window_Tree_Module
#------------------------------------------------------------------------------
# �K�w�I�ȃE�B���h�E���Ǘ�����
# Copyright (C) 2005 fukuyama
#==============================================================================

module Window_Tree_Module
  attr_reader :parent
  #---------------------------------------------------------------------------
  # ������
  #---------------------------------------------------------------------------
  def initialize(parent, *arg)
    @parent = parent
    @child_windows = []
    super(*arg)
    if not parent.nil?
      parent.add_child self
    end
  end
  #---------------------------------------------------------------------------
  # �g�b�v�E�B���h�E�̎擾
  #---------------------------------------------------------------------------
  def top_window
    if top_window?
      return self
    end
    return self.parent.top_window
  end
  def top_window?
    return self.parent.nil?
  end
  #---------------------------------------------------------------------------
  # �c���[���ɂ���w�肳�ꂽ�E�B���h�E�݂̂��A�N�e�B�u�ɂ���
  #---------------------------------------------------------------------------
  def set_active_window(klass)
    top_window._set_active_window(klass)
  end
  def _set_active_window(klass)
    self.active = self.is_a?(klass)
    @child_windows.each do |window|
      if not window.disposed?
        if window.is_a? Window_Tree_Module
          window._set_active_window(klass)
        else
          window.active = window.is_a?(klass)
        end
      end
    end
  end
  #---------------------------------------------------------------------------
  # �c���[���ɂ���w�肳�ꂽ�E�B���h�E���擾����
  #---------------------------------------------------------------------------
  def get_window(klass)
    return top_window._get_window(klass)
  end
  def _get_window(klass)
    return self if self.is_a?(klass)
    @child_windows.each do |window|
      if not window.disposed?
        if window.is_a? Window_Tree_Module
          return window._get_window(klass)
        else
          return window if window.is_a?(klass)
        end
      end
    end
    return nil
  end
  #---------------------------------------------------------------------------
  # �A�N�e�B�u�E�B���h�E�̎擾
  #---------------------------------------------------------------------------
  def get_active_window
    return top_window._get_active_window
  end
  def _get_active_window
    return self if self.active
    result = nil
    @child_windows.each do |window|
      if not window.disposed?
        if window.is_a? Window_Tree_Module
          result = window._get_active_window
          if not result.nil?
            break
          end
        else
          if window.active
            result = window
            break
          end
        end
      end
    end
    return result
  end
  #---------------------------------------------------------------------------
  # �S�Ă̂y�C���f�b�N�X���X�V����
  #---------------------------------------------------------------------------
  def refresh_z_index
    if (not parent.nil?) and self.z <= parent.z
      self.z = parent.z + 20
    end
    child_z_index = 1
    @child_windows.each do |window|
      if not window.disposed?
        if window.is_a? Window_Tree_Module
          window.refresh_z_index
        else
          window.z = self.z + 20
        end
        window.z += child_z_index
        child_z_index += 2
      end
    end
  end
  #---------------------------------------------------------------------------
  # �q�E�B���h�E�̒ǉ�
  #---------------------------------------------------------------------------
  def add_child(window)
    return window if @child_windows.include?(window)
    @child_windows.push window
    refresh_z_index
    return window
  end
  #---------------------------------------------------------------------------
  # �q�E�B���h�E�̏���
  #---------------------------------------------------------------------------
  def delete_child(window)
    @child_windows.delete window
    refresh_z_index
    return window
  end
  #---------------------------------------------------------------------------
  # �X�V
  #---------------------------------------------------------------------------
  def update
    update_child_windows
    return if disposed?
    super
  end
  #---------------------------------------------------------------------------
  # �j��
  #---------------------------------------------------------------------------
  def dispose
    @child_windows.each do |window|
      if not window.disposed?
        window.dispose
      end
    end
    @child_windows.clear
    super
  end
  #---------------------------------------------------------------------------
  # �q�E�B���h�E�ɃA�N�e�B�u�ȕ������邩�H
  #---------------------------------------------------------------------------
  def child_window_active?
    result = false
    @child_windows.each do |window|
      if not window.disposed?
        if window.is_a? Window_Tree_Module
          result = (window.active or window.child_window_active?)
        else
          result = window.active
        end
        if result
          break
        end
      end
    end
    return result
  end
  #---------------------------------------------------------------------------
  # �q�E�B���h�E�̍X�V
  #---------------------------------------------------------------------------
  def update_child_windows
    @child_windows.dup.each do |window|
      if not window.disposed?
        window.update
      end
      # update���dispose����Ă�ꍇ
      if window.disposed?
        @child_windows.delete window
        if not disposed?
          if get_active_window.nil?
            self.active = (not child_window_active?)
          end
        end
      end
    end
  end
end
