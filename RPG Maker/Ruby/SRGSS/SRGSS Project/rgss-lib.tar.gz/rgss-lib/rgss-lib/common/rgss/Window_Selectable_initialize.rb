#==============================================================================
# �� Window_Selectable#initialize
#------------------------------------------------------------------------------
# ���������@�̏C���iWindow_Menu�Ή��j
# Copyright (C) 2005 fukuyama
#==============================================================================
if false

class Window_Selectable
  def initialize(x, y, width, height)
    super(x, y, width, height)
    @item_max = 1 if @item_max.nil?
    @column_max = 1 if @column_max.nil?
    @index = -1 if @index.nil?
  end
end

end
