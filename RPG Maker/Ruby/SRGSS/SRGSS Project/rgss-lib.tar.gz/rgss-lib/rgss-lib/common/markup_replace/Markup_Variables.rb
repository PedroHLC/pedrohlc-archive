#==============================================================================
# �� Markup_Variables
#------------------------------------------------------------------------------
# �}�[�N�A�b�v�ϐ�
# Copyright (C) 2005 fukuyama
#==============================================================================
#
# \V[�ϐ�ID] �ϐ��̒l�ɒu��������
#
#==============================================================================

module Markup_Variables
  module_function
  def query
    return /\\V\[(.+?)\]/
  end
  def transfer(obj, text, match)
    if match[1] =~ /^[0-9]+$/
      i = match[1].to_i
    else
      i = Variables.normarize_id(match[1])
    end
    text[query] = $game_variables[i].to_s
  end
end

String_Replace_Module.add_markup(Markup_Variables)
