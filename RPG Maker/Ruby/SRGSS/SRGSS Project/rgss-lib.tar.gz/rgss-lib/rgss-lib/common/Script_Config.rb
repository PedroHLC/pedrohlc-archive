# �X�N���v�g�R���t�B�O���擾���[�e�B���e�B
# Author:: fukuyama
# Date:: 2008/05/11
# Copyright:: Copyright (c) 2007-2008 rgss-lib

module Script_Config
  module_function
  def variable_id(name,default)
    val = Variables[name]
    if val.nil?
      return default
    end
    return val
  end
  def switch_id(name,default)
    val = Switches[name]
    if val.nil?
      return default
    end
    return val
  end
  def common_event_id(name,default)
    data_common_events = Data_Loader.data_common_events
    for c in data_common_events
      if (not c.nil?) and c.name == name
        return c.id
      end
    end
    return default
  end
end
