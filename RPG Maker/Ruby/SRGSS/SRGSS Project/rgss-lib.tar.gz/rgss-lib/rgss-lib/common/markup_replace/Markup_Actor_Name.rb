#==============================================================================
# �� Markup_Actor_Name
#------------------------------------------------------------------------------
# �}�[�N�A�b�v�A�N�^�[��
# Copyright (C) 2005 fukuyama
#==============================================================================
#
# \N[�A�N�^�[ID] �A�N�^�[�̖��O�ɒu��������
#
#==============================================================================

module Markup_Actor_Name
  module_function
  def query
    return /\\N\[([0-9]+)\]/
  end
  def transfer(obj, text, match)
    text[query] = $game_actors[match[1].to_i].name
  end
end

String_Replace_Module.add_markup(Markup_Actor_Name)
