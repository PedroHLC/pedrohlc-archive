require 'zlib'
require 'Win32API'
# RaTTiE �l�쐬 EasyConv module ���g��
require 'EasyConv.rb'

rgssfilename = 'OriginalScripts.rxdata'

scripts = nil
File.open(rgssfilename, "rb") do |f|
  scripts = Marshal.load(f)
end

main_script = scripts.pop

begin
  src_dir = gets.chop
  target = gets.chop
  files = []
  while line = gets
    filename = line.chop
    section = File.basename(filename)
    source = ''
    # �t�@�C��
    if FileTest.file?(filename)
      open(filename).each do |line|
        line.sub!(/[ \t\n]*$/,"\r\n")
        source += line
      end
    elsif FileTest.directory?(filename)
      if FileTest.exist?(filename + '/package.txt')
        open(filename + '/package.txt').each do |line|
          line.sub!(/[ \t\n]*$/,"\r\n")
          source += line
        end
      end
    end
    source = EasyConv.s2u(source)
    scripts.push [section.id,section,Zlib::Deflate.deflate(source)]
  end
  scripts.push main_script
  File.open(target, "wb") do |f|
    Marshal.dump(scripts, f)
  end
end

