#------------------------------------------------------------------------------
# �\�͒l�A�b�v���
# Copyright (C) 2005 fukuyama
#------------------------------------------------------------------------------

module Game_Item_Ability_Plus_Module
  def initialize(*arg)
    @str_plus = 0
    @dex_plus = 0
    @agi_plus = 0
    @int_plus = 0
    super(*arg)
  end

  def setup(item)
    super(item)
    @str_plus = item.str_plus
    @dex_plus = item.dex_plus
    @agi_plus = item.agi_plus
    @int_plus = item.int_plus
  end

  attr_accessor :str_plus
  attr_accessor :dex_plus
  attr_accessor :agi_plus
  attr_accessor :int_plus
end
