# �����R���e�i
# Author:: fukuyama
# Date:: 2008/01/31
# Copyright:: Copyright (c) 2005-2008 rgss-lib

class Item_Infinity_Container < Item_Container_Base
  def initialize()
    super()
  end
end
