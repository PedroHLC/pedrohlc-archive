package jp.sf.rgsslib.rpgvxdt.ui;

import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Composite;

public class SWTUtil {

	public static Button createButton(Composite composite, int style,
			String label) {
		Button button = new Button(composite, style);
		button.setText(label);
		return button;
	}

}
