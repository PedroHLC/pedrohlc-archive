package jp.sf.rgsslib.rpgvxdt.launch;

import static jp.sf.rgsslib.rpgvxdt.RpgvxdtPlugin.getImageDescriptor;
import static jp.sf.rgsslib.rpgvxdt.RpgvxdtPlugin.getResourceString;
import static jp.sf.rgsslib.rpgvxdt.launch.ConfigurationConstants.ATTR_PROJECT_GAME_USED;
import static jp.sf.rgsslib.rpgvxdt.launch.ConfigurationConstants.ATTR_PROJECT_NAME;
import static jp.sf.rgsslib.rpgvxdt.launch.ConfigurationConstants.ATTR_RGSS_FILE_LIST;
import static jp.sf.rgsslib.rpgvxdt.launch.ConfigurationConstants.ATTR_SCRIPT_BASE_USED;
import static jp.sf.rgsslib.rpgvxdt.launch.ConfigurationConstants.ATTR_WORKING_DIR;
import static jp.sf.rgsslib.rpgvxdt.launch.ConfigurationConstants.ATTR_WORKING_DIR_TYPE;
import static jp.sf.rgsslib.rpgvxdt.launch.ConfigurationConstants.DEFAULT_ATTR_PROJECT_GAME_USED;
import static jp.sf.rgsslib.rpgvxdt.launch.ConfigurationConstants.DEFAULT_ATTR_PROJECT_NAME;
import static jp.sf.rgsslib.rpgvxdt.launch.ConfigurationConstants.DEFAULT_ATTR_RGSS_FILE_LIST;
import static jp.sf.rgsslib.rpgvxdt.launch.ConfigurationConstants.DEFAULT_ATTR_SCRIPT_BASE_USED;
import static jp.sf.rgsslib.rpgvxdt.launch.ConfigurationConstants.DEFAULT_ATTR_WORKING_DIR_TYPE;
import static jp.sf.rgsslib.rpgvxdt.launch.ConfigurationConstants.DEFAULT_WORKING_DIR;

import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.io.LineNumberReader;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import jp.sf.rgsslib.rpgvxdt.RpgvxdtPlugin;
import jp.sf.rgsslib.rpgvxdt.preferences.PreferenceUtil;
import jp.sf.rgsslib.rpgvxdt.ui.SWTUtil;

import org.eclipse.core.resources.IFile;
import org.eclipse.core.resources.IProject;
import org.eclipse.core.resources.IResource;
import org.eclipse.core.resources.IWorkspace;
import org.eclipse.core.resources.IWorkspaceRoot;
import org.eclipse.core.resources.ResourcesPlugin;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.debug.core.ILaunchConfiguration;
import org.eclipse.debug.core.ILaunchConfigurationWorkingCopy;
import org.eclipse.debug.ui.AbstractLaunchConfigurationTab;
import org.eclipse.debug.ui.ILaunchConfigurationTab;
import org.eclipse.jface.window.Window;
import org.eclipse.swt.SWT;
import org.eclipse.swt.events.KeyAdapter;
import org.eclipse.swt.events.KeyEvent;
import org.eclipse.swt.events.ModifyEvent;
import org.eclipse.swt.events.ModifyListener;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.graphics.Image;
import org.eclipse.swt.layout.FillLayout;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.DirectoryDialog;
import org.eclipse.swt.widgets.FileDialog;
import org.eclipse.swt.widgets.Group;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.MessageBox;
import org.eclipse.swt.widgets.Text;
import org.eclipse.ui.dialogs.ElementListSelectionDialog;
import org.eclipse.ui.dialogs.ResourceSelectionDialog;
import org.eclipse.ui.model.WorkbenchLabelProvider;

/**
 * RGSS Main Tab
 * 
 * @author Yoshihito Fukuyama
 */
public class RgssMainTab extends AbstractLaunchConfigurationTab {
	private Text projectNameText = null;

	private org.eclipse.swt.widgets.List scriptList = null;

	private Image icon = null;

	private Text rpgvxProjectDirText;

	private Button rpgvxProjectBaseRadioButton;

	private Button rpgvxProjectEtcRadioButton;

	private Button scriptBaseUsedCheck;

	private Button rpgvxProjectBrowseButton;

	private Button rpgvxProjectGameUsedCheckButton;

	private List<String> scriptFilter;

	private Composite projectGroup;

	private Composite rpgvxProjectGroup;

	private Composite scriptGroup;

	private List<String> cutList = new ArrayList<String>();

	private static final String DEFAULT_IMPORT_FILE_NAME = "rgss_list.txt";

	private static final String DEFAULT_EXPORT_FILE_NAME = "rgss_list.txt";

	private static final String IMAGE_TAB_ICON_FILE = "icons/vxicon.gif";

	private static final int BUTTON_WIDTH_HINT = 100;

	private static final String KEY_NAME = "name";

	private static final String KEY_PROJECT_GROUP_LABEL = "project.group.label";

	private static final String KEY_PROJECT_SELECT_TITLE = "project.select.title";

	private static final String KEY_PROJECT_SELECT_MESSAGE = "project.select.message";

	private static final String KEY_PROJECT_BROWSE_BUTTON_LABEL = "project.browse.button.label";

	private static final String KEY_SCRIPT_GROUP_LABEL = "script.group.label";

	private static final String KEY_SCRIPT_FILE_SELECT_TITLE = "script.file.select.title";

	private static final String KEY_SCRIPT_FILE_SELECT_MESSAGE = "script.file.select.message";

	private static final String KEY_SCRIPT_ADD_BUTTON_LABEL = "script.add.button.label";

	private static final String KEY_SCRIPT_REMOVE_BUTTON_LABEL = "script.remove.button.label";

	private static final String KEY_SCRIPT_UP_BUTTON_LABEL = "script.up.button.label";

	private static final String KEY_SCRIPT_DOWN_BUTTON_LABEL = "script.down.button.label";

	private static final String KEY_SCRIPT_BASE_USED_CHECK_LABEL = "script.base.used.check.label";

	private static final String KEY_SCRIPT_IMPORT_BUTTON_LABEL = "script.import.button.label";

	private static final String KEY_SCRIPT_EXPORT_BUTTON_LABEL = "script.export.button.label";

	private static final String KEY_SCRIPT_CUT_BUTTON_LABEL = "script.cut.button.label";

	private static final String KEY_SCRIPT_PASTE_BUTTON_LABEL = "script.paste.button.label";

	private static final String KEY_SCRIPT_EXPORT_OVERWRITE_TITLE = "script.export.overwrite.title";

	private static final String KEY_SCRIPT_EXPORT_OVERWRITE_MESSAGE = "script.export.overwrite.message";

	private static final String KEY_RPGVX_PROJECT_GROUP_LABEL = "rpgvx.project.group.label";

	private static final String KEY_RPGVX_PROJECT_BROWSE_BUTTON_LABEL = "rpgvx.project.browse.button.label";

	private static final String KEY_RPGVX_PROJECT_BASE_RADIO_LABEL = "rpgvx.project.base.radio.label";

	private static final String KEY_RPGVX_PROJECT_ETC_RADIO_LABEL = "rpgvx.project.etc.radio.label";

	private static final String KEY_RPGVX_PROJECT_SELECT_TITLE = "rpgvx.project.select.title";

	private static final String KEY_RPGVX_PROJECT_SELECT_MESSAGE = "rpgvx.project.select.message";

	private static final String KEY_RPGVX_PROJECT_GAME_USED_CHECK_LABEL = "rpgvx.project.game.used.check.label";

	/**
	 * �N���\����RGSS���C���^�u���쐬.
	 * 
	 * @see ILaunchConfigurationTab#createControl(Composite)
	 */
	public void createControl(Composite parent) {
		Composite composite = new Composite(parent, SWT.NONE);
		setControl(composite);
		GridLayout gridLayout = new GridLayout();
		composite.setLayout(gridLayout);
		gridLayout.numColumns = 1;

		// �v���W�F�N�g�O���[�v
		projectGroup = createControlProjectGroup(composite);
		projectGroup.setLayoutData(new GridData(GridData.FILL_HORIZONTAL));

		// RPG�c�N�[��VX�v���W�F�N�g�O���[�v
		rpgvxProjectGroup = createControlRPGProjectGroup(composite);
		rpgvxProjectGroup.setLayoutData(new GridData(GridData.FILL_HORIZONTAL));

		// RGSS�t�@�C���I���O���[�v
		scriptGroup = createControlScriptGroup(composite);
		scriptGroup.setLayoutData(new GridData(GridData.FILL_HORIZONTAL));
	}

	/**
	 * �v���W�F�N�g���̓O���[�v
	 * 
	 * @param parent
	 *            Composite
	 * @return Composite
	 */
	private Composite createControlProjectGroup(Composite parent) {
		Group group = new Group(parent, SWT.NONE);
		group.setText(getResourceString(this, KEY_PROJECT_GROUP_LABEL));

		// Layout
		GridLayout gridLayout = new GridLayout();
		gridLayout.numColumns = 2;
		group.setLayout(gridLayout);

		// Widgets
		projectNameText = new Text(group, SWT.SINGLE | SWT.BORDER);
		projectNameText.setLayoutData(new GridData(GridData.FILL_HORIZONTAL));
		projectNameText.addModifyListener(new ModifyListener() {
			public void modifyText(ModifyEvent e) {
				if (rpgvxProjectBaseRadioButton.getSelection()) {
					rpgvxProjectDirText.setText(getDefaultRpgVxProjectDir());
				}
				updateLaunchConfigurationDialog();
			}
		});

		String label = null;
		Button button = null;

		label = getResourceString(this, KEY_PROJECT_BROWSE_BUTTON_LABEL);
		button = SWTUtil.createButton(group, SWT.NONE, label);
		button.setLayoutData(new GridData());
		((GridData) button.getLayoutData()).widthHint = BUTTON_WIDTH_HINT;
		button.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				handleProjectBrowse();
			}
		});
		return group;
	}

	/**
	 * RPGXP�v���W�F�N�g���̓O���[�v
	 * 
	 * @param parent
	 *            Composite
	 * @return Composite
	 */
	private Composite createControlRPGProjectGroup(Composite parent) {
		Group group = new Group(parent, SWT.NONE);
		group.setText(getResourceString(this, KEY_RPGVX_PROJECT_GROUP_LABEL));

		// Layout
		GridLayout gridLayout = new GridLayout();
		gridLayout.numColumns = 2;
		group.setLayout(gridLayout);

		// Widgets

		String label = null;
		Button button = null;

		label = getResourceString(this, KEY_RPGVX_PROJECT_GAME_USED_CHECK_LABEL);
		button = SWTUtil.createButton(group, SWT.CHECK, label);
		button.setLayoutData(new GridData(GridData.FILL_HORIZONTAL));
		((GridData) button.getLayoutData()).horizontalSpan = 2;
		button.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				updateLaunchConfigurationDialog();
			}
		});
		rpgvxProjectGameUsedCheckButton = button;

		label = getResourceString(this, KEY_RPGVX_PROJECT_BASE_RADIO_LABEL);
		button = SWTUtil.createButton(group, SWT.RADIO, label);
		button.setLayoutData(new GridData(GridData.FILL_HORIZONTAL));
		((GridData) button.getLayoutData()).horizontalSpan = 2;
		button.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				rpgvxProjectDirText.setEnabled(false);
				rpgvxProjectBrowseButton.setEnabled(false);
				rpgvxProjectDirText.setText(getDefaultRpgVxProjectDir());
				updateLaunchConfigurationDialog();
			}
		});
		rpgvxProjectBaseRadioButton = button;

		label = getResourceString(this, KEY_RPGVX_PROJECT_ETC_RADIO_LABEL);
		button = SWTUtil.createButton(group, SWT.RADIO, label);
		button.setLayoutData(new GridData(GridData.FILL_HORIZONTAL));
		((GridData) button.getLayoutData()).horizontalSpan = 2;
		button.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				rpgvxProjectDirText.setEnabled(true);
				rpgvxProjectBrowseButton.setEnabled(true);
				updateLaunchConfigurationDialog();
			}
		});
		rpgvxProjectEtcRadioButton = button;

		rpgvxProjectDirText = new Text(group, SWT.SINGLE | SWT.BORDER);
		rpgvxProjectDirText
				.setLayoutData(new GridData(GridData.FILL_HORIZONTAL));
		rpgvxProjectDirText.addModifyListener(new ModifyListener() {
			public void modifyText(ModifyEvent e) {
				updateLaunchConfigurationDialog();
			}
		});

		label = getResourceString(this, KEY_RPGVX_PROJECT_BROWSE_BUTTON_LABEL);
		button = SWTUtil.createButton(group, SWT.NONE, label);
		button.setLayoutData(new GridData());
		((GridData) button.getLayoutData()).widthHint = BUTTON_WIDTH_HINT;
		button.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				handleRpgProjectBrowse();
			}
		});
		rpgvxProjectBrowseButton = button;
		return group;
	}

	/**
	 * �X�N���v�g���̓O���[�v
	 * 
	 * @param parent
	 *            Composite
	 * @return Composite
	 */
	private Composite createControlScriptGroup(Composite parent) {
		Group group = new Group(parent, SWT.NONE);
		group.setText(getResourceString(this, KEY_SCRIPT_GROUP_LABEL));

		// Layout
		GridLayout gridLayout = new GridLayout(2, false);
		group.setLayout(gridLayout);

		// Widgets
		String label = null;
		Button button = null;

		label = getResourceString(this, KEY_SCRIPT_BASE_USED_CHECK_LABEL);
		button = SWTUtil.createButton(group, SWT.CHECK, label);
		button.setLayoutData(new GridData(GridData.FILL_HORIZONTAL));
		((GridData) button.getLayoutData()).horizontalSpan = gridLayout.numColumns;
		button.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				updateLaunchConfigurationDialog();
			}
		});
		scriptBaseUsedCheck = button;

		scriptList = new org.eclipse.swt.widgets.List(group, SWT.BORDER
				| SWT.MULTI | SWT.V_SCROLL | SWT.H_SCROLL);
		scriptList.setLayoutData(new GridData(GridData.FILL_HORIZONTAL));
		((GridData) scriptList.getLayoutData()).heightHint = 200;
		scriptList.addKeyListener(new KeyAdapter() {
			@Override
			public void keyPressed(KeyEvent e) {
				switch (e.keyCode) {
				case SWT.DEL:
					handleScriptRemove();
					break;
				default:
					break;
				}
			}
		});

		Composite buttons = new Composite(group, SWT.NONE);
		buttons.setLayout(new FillLayout(SWT.VERTICAL));
		buttons.setLayoutData(new GridData(GridData.VERTICAL_ALIGN_BEGINNING));
		((GridData) buttons.getLayoutData()).widthHint = BUTTON_WIDTH_HINT;

		label = getResourceString(this, KEY_SCRIPT_ADD_BUTTON_LABEL);
		button = SWTUtil.createButton(buttons, SWT.NONE, label);
		button.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				handleRgssFileBrowse();
			}
		});
		label = getResourceString(this, KEY_SCRIPT_REMOVE_BUTTON_LABEL);
		button = SWTUtil.createButton(buttons, SWT.NONE, label);
		button.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				handleScriptRemove();
			}
		});
		label = getResourceString(this, KEY_SCRIPT_UP_BUTTON_LABEL);
		button = SWTUtil.createButton(buttons, SWT.NONE, label);
		button.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				if (scriptList.getSelectionIndex() < 1) {
					return;
				}
				int[] index1 = scriptList.getSelectionIndices();
				int[] index2 = new int[index1.length];
				for (int i = 0; i < index1.length; i++) {
					index2[i] = index1[i] - 1;
					String str1 = scriptList.getItem(index1[i]);
					String str2 = scriptList.getItem(index2[i]);
					scriptList.setItem(index1[i], str2);
					scriptList.setItem(index2[i], str1);
				}
				scriptList.setSelection(index2);
				updateLaunchConfigurationDialog();
			}
		});
		label = getResourceString(this, KEY_SCRIPT_DOWN_BUTTON_LABEL);
		button = SWTUtil.createButton(buttons, SWT.NONE, label);
		button.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				int[] index1 = scriptList.getSelectionIndices();
				if (index1[index1.length - 1] >= scriptList.getItemCount() - 1) {
					return;
				}
				int[] index2 = new int[index1.length];
				for (int i = index1.length - 1; i >= 0; i--) {
					index2[i] = index1[i] + 1;
					String str1 = scriptList.getItem(index1[i]);
					String str2 = scriptList.getItem(index2[i]);
					scriptList.setItem(index1[i], str2);
					scriptList.setItem(index2[i], str1);
				}
				scriptList.setSelection(index2);
				updateLaunchConfigurationDialog();
			}
		});

		new Label(buttons, SWT.NONE);

		label = getResourceString(this, KEY_SCRIPT_CUT_BUTTON_LABEL);
		button = SWTUtil.createButton(buttons, SWT.NONE, label);
		button.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				handleScriptCut();
			}
		});

		label = getResourceString(this, KEY_SCRIPT_PASTE_BUTTON_LABEL);
		button = SWTUtil.createButton(buttons, SWT.NONE, label);
		button.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				handleScriptPaste();
			}
		});

		new Label(buttons, SWT.NONE);

		label = getResourceString(this, KEY_SCRIPT_IMPORT_BUTTON_LABEL);
		button = SWTUtil.createButton(buttons, SWT.NONE, label);
		button.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				handleScriptImport();
			}
		});

		label = getResourceString(this, KEY_SCRIPT_EXPORT_BUTTON_LABEL);
		button = SWTUtil.createButton(buttons, SWT.NONE, label);
		button.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				handleScriptExport();
			}
		});

		return group;
	}

	public void setDefaults(ILaunchConfigurationWorkingCopy configuration) {
		configuration
				.setAttribute(ATTR_PROJECT_NAME, DEFAULT_ATTR_PROJECT_NAME);
		configuration.setAttribute(ATTR_RGSS_FILE_LIST,
				DEFAULT_ATTR_RGSS_FILE_LIST);

		String projectDir = PreferenceUtil.getTkoolProjectDir();
		configuration.setAttribute(ATTR_WORKING_DIR, new File(projectDir
				+ DEFAULT_ATTR_PROJECT_NAME).getAbsolutePath());
		configuration.setAttribute(ATTR_SCRIPT_BASE_USED,
				DEFAULT_ATTR_SCRIPT_BASE_USED);
		configuration.setAttribute(ATTR_PROJECT_GAME_USED,
				DEFAULT_ATTR_PROJECT_GAME_USED);
	}

	public void initializeFrom(ILaunchConfiguration configuration) {
		try {
			String projectName = configuration.getAttribute(ATTR_PROJECT_NAME,
					DEFAULT_ATTR_PROJECT_NAME);
			projectNameText.setText(projectName);
			List<?> list = configuration.getAttribute(ATTR_RGSS_FILE_LIST,
					DEFAULT_ATTR_RGSS_FILE_LIST);
			scriptList.removeAll();
			for (Object object : list) {
				scriptList.add(object.toString());
			}
			boolean type = configuration.getAttribute(ATTR_WORKING_DIR_TYPE,
					DEFAULT_ATTR_WORKING_DIR_TYPE);
			String defaultWorkingDir = DEFAULT_WORKING_DIR;
			if (type) {
				defaultWorkingDir = getDefaultRpgVxProjectDir();
			}
			rpgvxProjectBaseRadioButton.setSelection(type);
			rpgvxProjectEtcRadioButton.setSelection(!type);
			rpgvxProjectBrowseButton.setEnabled(!type);
			rpgvxProjectDirText.setEnabled(!type);
			rpgvxProjectDirText.setText(configuration.getAttribute(
					ATTR_WORKING_DIR, defaultWorkingDir));
			scriptBaseUsedCheck.setSelection(configuration.getAttribute(
					ATTR_SCRIPT_BASE_USED, DEFAULT_ATTR_SCRIPT_BASE_USED));
			rpgvxProjectGameUsedCheckButton.setSelection(configuration
					.getAttribute(ATTR_PROJECT_GAME_USED,
							DEFAULT_ATTR_PROJECT_GAME_USED));
		} catch (CoreException ce) {
			projectNameText.setText(DEFAULT_ATTR_PROJECT_NAME);
			scriptList.removeAll();
		}
	}

	public void performApply(ILaunchConfigurationWorkingCopy configuration) {
		configuration
				.setAttribute(ATTR_PROJECT_NAME, projectNameText.getText());
		configuration.setAttribute(ATTR_RGSS_FILE_LIST, Arrays
				.asList(scriptList.getItems()));
		configuration.setAttribute(ATTR_WORKING_DIR_TYPE,
				rpgvxProjectBaseRadioButton.getSelection());
		configuration.setAttribute(ATTR_WORKING_DIR, rpgvxProjectDirText
				.getText());
		configuration.setAttribute(ATTR_SCRIPT_BASE_USED, scriptBaseUsedCheck
				.getSelection());
		configuration.setAttribute(ATTR_PROJECT_GAME_USED,
				rpgvxProjectGameUsedCheckButton.getSelection());
	}

	public String getName() {
		return getResourceString(this, KEY_NAME);
	}

	@Override
	public Image getImage() {
		if (icon == null) {
			icon = getImageDescriptor(IMAGE_TAB_ICON_FILE).createImage();
		}
		return icon;
	}

	@Override
	public void dispose() {
		if (icon != null) {
			icon.dispose();
		}
		super.dispose();
	}

	@Override
	public boolean isValid(ILaunchConfiguration launchConfig) {
		setErrorMessage(null);
		String projectName = projectNameText.getText();
		if (projectName.length() == 0) {
			setErrorMessage("�v���W�F�N�g������͂��Ă��������B");
			this.rpgvxProjectGroup.setEnabled(false);
			this.scriptGroup.setEnabled(false);
			return false;
		}
		IWorkspace workspace = ResourcesPlugin.getWorkspace();
		IProject project = workspace.getRoot().getProject(projectName);
		if (project == null || (!project.exists())) {
			setErrorMessage("�v���W�F�N�g(" + projectName + ")�́A���݂��܂���B");
			this.rpgvxProjectGroup.setEnabled(false);
			this.scriptGroup.setEnabled(false);
			return false;
		}
		this.rpgvxProjectGroup.setEnabled(true);
		String rpgxpProjectDirName = rpgvxProjectDirText.getText();
		if (!ConfigurationUtil.isVarildRpgvxProject(rpgxpProjectDirName)) {
			setErrorMessage("RPG�c�N�[��XP�v���W�F�N�g�́A���݂��܂���B");
			this.scriptGroup.setEnabled(false);
			return false;
		}
		this.scriptGroup.setEnabled(true);
		return true;
	}

	private IProject getSelectedProject() {
		IProject project = null;
		if (projectNameText.getText().length() != 0) {
			IWorkspaceRoot root = ResourcesPlugin.getWorkspace().getRoot();
			project = root.getProject(projectNameText.getText());
			if (!project.exists()) {
				project = null;
			}
		}
		return project;
	}

	/**
	 * �v���W�F�N�g�Q�ƃ{�^���n���h���[
	 */
	private void handleProjectBrowse() {
		String title = getResourceString(this, KEY_PROJECT_SELECT_TITLE);
		String message = getResourceString(this, KEY_PROJECT_SELECT_MESSAGE);
		IWorkspaceRoot root = ResourcesPlugin.getWorkspace().getRoot();
		ElementListSelectionDialog dialog = new ElementListSelectionDialog(
				getShell(), new WorkbenchLabelProvider());
		dialog.setElements(root.getProjects());
		dialog.setTitle(title);
		dialog.setMessage(message);
		IProject project = getSelectedProject();
		if (project != null) {
			dialog.setInitialSelections(new Object[] { project });
		}
		dialog.open();
		if (dialog.getReturnCode() == Window.OK) {
			Object[] results = dialog.getResult();
			if (results.length != 0) {
				project = (IProject) results[0];
				projectNameText.setText(project.getName());
				if (rpgvxProjectBaseRadioButton.getSelection()) {
					rpgvxProjectDirText.setText(getDefaultRpgVxProjectDir());
				}
			}
			updateLaunchConfigurationDialog();
		}
	}

	/**
	 * �X�N���v�g�Q�ƃ{�^���n���h���[
	 */
	private void handleRgssFileBrowse() {
		IProject project = getSelectedProject();
		if (project == null) {
			return;
		}
		String title = getResourceString(this, KEY_SCRIPT_FILE_SELECT_TITLE);
		String message = getResourceString(this, KEY_SCRIPT_FILE_SELECT_MESSAGE);
		ResourceSelectionDialog dialog = null;
		dialog = new ResourceSelectionDialog(getShell(), project, message);
		dialog.setTitle(title);
		List<String> items = Arrays.asList(scriptList.getItems());
		List<IResource> initialList = new ArrayList<IResource>();
		for (String str : items) {
			IResource resource = project.findMember(str);
			if (resource != null && resource.exists()) {
				initialList.add(resource);
			}
		}
		dialog.setInitialElementSelections(initialList);
		dialog.open();
		if (dialog.getReturnCode() == Window.OK) {
			int count = items.size();

			Object[] results = dialog.getResult();
			List<String> addList = new ArrayList<String>();
			for (Object object : results) {
				if (object instanceof IFile) {
					IFile file = (IFile) object;
					if (isValidScript(file)) {
						String str = file.getProjectRelativePath().toString();
						if (!items.contains(str)) {
							addList.add(str);
						}
					}
				}
			}
			Collections.sort(addList);
			for (String str : addList) {
				scriptList.add(str);
			}

			if (count != scriptList.getItemCount()) {
				int size = scriptList.getItemCount() - count;
				int[] t = new int[size];
				for (int i = 0; i < size; i++) {
					t[i] = count + i;
				}
				scriptList.setSelection(t);
				updateLaunchConfigurationDialog();
			}
		}
	}

	/**
	 * �X�N���v�g�폜�n���h���[
	 */
	private void handleScriptRemove() {
		int index = scriptList.getSelectionIndex();
		if (index < 0) {
			return;
		}
		scriptList.remove(scriptList.getSelectionIndices());
		if (scriptList.getItemCount() - 1 < index) {
			index = scriptList.getItemCount() - 1;
		}
		scriptList.setSelection(index);
		updateLaunchConfigurationDialog();
	}

	/**
	 * RPG�c�N�[���̃v���W�F�N�g��I��
	 */
	private void handleRpgProjectBrowse() {
		String dir = rpgvxProjectDirText.getText();
		File testFile = new File(dir);
		while (!testFile.isDirectory()) {
			testFile = testFile.getParentFile();
		}
		if (testFile != null) {
			dir = testFile.getAbsolutePath();
		}
		String title = getResourceString(this, KEY_RPGVX_PROJECT_SELECT_TITLE);
		String message = getResourceString(this,
				KEY_RPGVX_PROJECT_SELECT_MESSAGE);
		DirectoryDialog dialog = new DirectoryDialog(getShell(), SWT.OPEN);
		dialog.setText(title);
		dialog.setMessage(message);
		dialog.setFilterPath(dir);
		dir = dialog.open();
		if (dir != null) {
			rpgvxProjectDirText.setText(dir);
			if (rpgvxProjectBaseRadioButton.getSelection()) {
				rpgvxProjectDirText.setText(getDefaultRpgVxProjectDir());
			}
			updateLaunchConfigurationDialog();
		}
	}

	/**
	 * �X�N���v�g���X�g�C���|�[�g
	 */
	private void handleScriptImport() {
		IProject project = getSelectedProject();
		if (project == null) {
			return;
		}
		FileDialog dialog = new FileDialog(getShell(), SWT.OPEN);
		dialog.setFilterPath(project.getLocation().toOSString());
		dialog.setFileName(DEFAULT_IMPORT_FILE_NAME);
		String importFilename = dialog.open();
		if (importFilename != null) {
			File file = new File(importFilename);
			if (file.exists()) {
				LineNumberReader reader = null;
				try {
					List<String> items = Arrays.asList(scriptList.getItems());
					reader = new LineNumberReader(new FileReader(file));
					while (reader.ready()) {
						String line = reader.readLine();
						if (!items.contains(line.trim())) {
							IFile f = project.getFile(line);
							if (isValidScript(f)) {
								scriptList.add(line);
							}
						}
					}
					if (items.size() != scriptList.getItemCount()) {
						updateLaunchConfigurationDialog();
					}
				} catch (IOException e) {
					RpgvxdtPlugin.getDefault().logError("�C���|�[�g���ɖ�肪�������܂����B", e);
					return;
				} finally {
					if (reader != null) {
						try {
							reader.close();
						} catch (IOException e) {
						}
					}
				}
			}
		}
	}

	/**
	 * �X�N���v�g���X�g�̃G�N�X�|�[�g�n���h��.
	 */
	private void handleScriptExport() {
		FileDialog dialog = new FileDialog(getShell(), SWT.SAVE);
		IProject project = getSelectedProject();
		if (project != null) {
			dialog.setFilterPath(project.getLocation().toOSString());
		}
		dialog.setFileName(DEFAULT_EXPORT_FILE_NAME);

		String exportFilename = dialog.open();
		if (exportFilename != null) {
			File file = new File(exportFilename);
			if (file.exists()) {
				String title = getResourceString(this,
						KEY_SCRIPT_EXPORT_OVERWRITE_TITLE);
				String message = getResourceString(this,
						KEY_SCRIPT_EXPORT_OVERWRITE_MESSAGE);
				MessageBox box = new MessageBox(getShell(), SWT.YES | SWT.NO
						| SWT.ICON_QUESTION);
				box.setText(title);
				box.setMessage(message);
				if (box.open() != SWT.YES) {
					return;
				}
			}
			try {
				PrintWriter writer = new PrintWriter(file);
				for (String str : scriptList.getItems()) {
					writer.println(str);
				}
				writer.close();
			} catch (IOException e) {
				RpgvxdtPlugin.getDefault().logError("�G�N�X�|�[�g���ɖ�肪�������܂����B", e);
				return;
			}
		}
	}

	/**
	 * �X�N���v�g���X�g�̃J�b�g.
	 */
	private void handleScriptCut() {
		int index = scriptList.getSelectionIndex();
		if (index < 0) {
			return;
		}
		cutList = Arrays.asList(scriptList.getSelection());
		for (String string : cutList) {
			scriptList.remove(string);
		}
		System.out.println(index);
		index -= cutList.size() - 1;
		if (scriptList.getItemCount() - 1 < index) {
			index = scriptList.getItemCount() - 1;
		}
		scriptList.setSelection(index);
		updateLaunchConfigurationDialog();
	}

	/**
	 * �X�N���v�g���X�g�̃y�[�X�g.
	 */
	private void handleScriptPaste() {
		int index = scriptList.getSelectionIndex();
		if (index < 0) {
			return;
		}
		for (String string : cutList) {
			scriptList.add(string, scriptList.getSelectionIndex());
		}
		scriptList.setSelection(cutList.toArray(new String[cutList.size()]));
		updateLaunchConfigurationDialog();
	}

	/**
	 * �v���W�F�N�g�x�[�X�f�B���N�g�����擾.
	 * 
	 * @return �x�[�X�f�B���N�g�����i�t���p�X�j
	 */
	private String getDefaultRpgVxProjectDir() {
		String name = projectNameText.getText();
		return PreferenceUtil.getDefaultRpgVxProjectDir(name);
	}

	/**
	 * �X�N���v�g�t�@�C���`�F�b�N.
	 * 
	 * @param scriptFile
	 *            �X�N���v�g�t�@�C��.
	 */
	private boolean isValidScript(IFile scriptFile) {
		if (scriptFile == null) {
			return false;
		}
		if (!scriptFile.exists()) {
			return false;
		}
		List<String> filter = getScriptFilter();
		return filter.contains(scriptFile.getFileExtension());
	}

	/**
	 * �X�N���v�g�t�B���^�[�̎擾.
	 * 
	 * @return �g���q�̃��X�g.
	 */
	private List<String> getScriptFilter() {
		if (scriptFilter == null) {
			scriptFilter = PreferenceUtil.getScriptFilter();
		}
		return scriptFilter;
	}

}
