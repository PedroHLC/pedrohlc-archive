package jp.sf.rgsslib.rpgxpdt.launch;

import static jp.sf.rgsslib.rpgxpdt.RpgxpdtPlugin.getResourceString;
import static jp.sf.rgsslib.rpgxpdt.launch.ConfigurationConstants.GAME_COMMAND_FILE;
import static jp.sf.rgsslib.rpgxpdt.launch.ConfigurationConstants.RPGXP_PROJECT_FILE;

import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;
import java.net.URL;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import jp.sf.rgsslib.rpgxpdt.RpgxpdtPlugin;
import jp.sf.rgsslib.rpgxpdt.preferences.PreferenceUtil;

import org.eclipse.core.resources.IFile;
import org.eclipse.core.resources.IProject;
import org.eclipse.core.resources.IWorkspaceRoot;
import org.eclipse.core.resources.ResourcesPlugin;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.core.runtime.FileLocator;
import org.eclipse.core.runtime.IPath;
import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.core.runtime.Path;
import org.eclipse.debug.core.DebugPlugin;
import org.eclipse.debug.core.ILaunch;
import org.eclipse.debug.core.ILaunchConfiguration;
import org.eclipse.debug.core.model.LaunchConfigurationDelegate;

public class ConfigurationDelegate extends LaunchConfigurationDelegate {

	private static final String KEY_RGSS_CREATE_TASK_NAME = "rgss.create.task.name";

	private static final IPath LAUNCH_SCRIPT = new Path("scripts/launch.rb");

	public void launch(ILaunchConfiguration configuration, String mode,
			ILaunch launch, IProgressMonitor monitor) throws CoreException {
		if (!launchCheck(configuration, mode, launch, monitor)) {
			return;
		}

		launchScript(configuration, mode, launch, monitor);

		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
		}

		launchRpgXp(configuration, mode, launch, monitor);
	}

	/**
	 * ���s���̃`�F�b�N.
	 *
	 * @param configuration
	 * @param mode
	 * @param launch
	 * @param monitor
	 * @return
	 * @throws CoreException
	 */
	private boolean launchCheck(ILaunchConfiguration configuration,
			String mode, ILaunch launch, IProgressMonitor monitor)
			throws CoreException {
		// Ruby �R�}���h
		String ruby = PreferenceUtil.getRubyCommand();
		if (!new File(ruby).exists()) {
			// TODO
			return false;
		}
		// Launch�pRuby�X�N���v�g
		String launchScript = getLaunchScript();
		if (!new File(launchScript).exists()) {
			// TODO
			return false;
		}
		// �v���W�F�N�g
		IProject project = getProject(configuration);
		if (!project.exists()) {
			// TODO
			return false;
		}
		// ��ƃf�B���N�g��
		String workingDirectoryName = getWorkingDirectory(configuration);
		File workingDirectory = new File(workingDirectoryName);
		if (!workingDirectory.exists()) {
			// TODO
			return false;
		}
		// RPGXP�R�}���h
		String rpgxp = PreferenceUtil.getRpgXpCommand();
		if (!new File(rpgxp).exists()) {
			// TODO
			return false;
		}
		String rpgxpProjectFile = getRpgxpProjectFile(configuration);
		if (!new File(rpgxpProjectFile).exists()) {
			// TODO
			return false;
		}
		return true;
	}

	/**
	 * �����`���[�X�N���v�g�̎��s.
	 *
	 * @param configuration
	 * @param mode
	 * @param launch
	 * @param monitor
	 * @throws CoreException
	 */
	private void launchScript(ILaunchConfiguration configuration, String mode,
			ILaunch launch, IProgressMonitor monitor) throws CoreException {
		IProject project = getProject(configuration);
		String ruby = PreferenceUtil.getRubyCommand();
		String launchScript = getLaunchScript();
		String rpgxp = PreferenceUtil.getRpgXpCommand();
		String workingDirectoryName = getWorkingDirectory(configuration);
		File workingDirectory = new File(workingDirectoryName);

		Boolean scriptBaseUsed = getScriptBaseUsed(configuration);

		// Ruby���s
		Process rubyProcess = DebugPlugin.exec(new String[] { ruby,
				launchScript, scriptBaseUsed.toString(), rpgxp,
				project.getLocation().toOSString() }, workingDirectory);
		DebugPlugin.newProcess(launch, rubyProcess, workingDirectoryName);

		// ����
		List<String> scripts = getRgssFileList(configuration);
		monitor.beginTask(getResourceString(this, KEY_RGSS_CREATE_TASK_NAME),
				scripts.size());
		PrintWriter writer = new PrintWriter(rubyProcess.getOutputStream());
		for (String script : scripts) {
			IFile file = project.getFile(script);
			writer.println(file.getLocation().toOSString());
			monitor.worked(1);
		}
		writer.close();
		monitor.done();
	}

	private void launchRpgXp(ILaunchConfiguration configuration, String mode,
			ILaunch launch, IProgressMonitor monitor) throws CoreException {
		String rpgxpProjectFile = getRpgxpProjectFile(configuration);
		String workingDirectoryName = getWorkingDirectory(configuration);
		File workingDirectory = new File(workingDirectoryName);
		String rpgxp = PreferenceUtil.getRpgXpCommand();

		Process rpgxpProcess = null;
		Boolean scriptGameUsed = getGameUsed(configuration);
		if (scriptGameUsed.booleanValue()) {
			// Game���s
			rpgxpProcess = DebugPlugin.exec(new String[] { rpgxpProjectFile,
					mode }, workingDirectory);
		} else {
			// RPGXP���s
			rpgxpProcess = DebugPlugin.exec(new String[] { rpgxp,
					rpgxpProjectFile }, workingDirectory);
		}
		DebugPlugin.newProcess(launch, rpgxpProcess, rpgxpProjectFile);
	}

	private boolean getScriptBaseUsed(ILaunchConfiguration configuration)
			throws CoreException {
		return configuration.getAttribute(
				ConfigurationConstants.ATTR_SCRIPT_BASE_USED,
				ConfigurationConstants.DEFAULT_ATTR_SCRIPT_BASE_USED);
	}

	private boolean getGameUsed(ILaunchConfiguration configuration)
			throws CoreException {
		return configuration.getAttribute(
				ConfigurationConstants.ATTR_PROJECT_GAME_USED,
				ConfigurationConstants.DEFAULT_ATTR_PROJECT_GAME_USED);
	}

	/**
	 * RGSS�t�@�C�����X�g�̎擾
	 *
	 * @param configuration
	 *            ILaunchConfiguration
	 * @return List<String>
	 * @throws CoreException
	 */
	@SuppressWarnings("unchecked")
	private List<String> getRgssFileList(ILaunchConfiguration configuration)
			throws CoreException {
		return configuration.getAttribute(
				ConfigurationConstants.ATTR_RGSS_FILE_LIST,
				ConfigurationConstants.DEFAULT_ATTR_RGSS_FILE_LIST);
	}

	/**
	 * �v���W�F�N�g�̎擾
	 *
	 * @param configuration
	 *            ILaunchConfiguration
	 * @return �v���W�F�N�g
	 * @throws CoreException
	 */
	private IProject getProject(ILaunchConfiguration configuration)
			throws CoreException {
		String projectName = configuration.getAttribute(
				ConfigurationConstants.ATTR_PROJECT_NAME,
				ConfigurationConstants.DEFAULT_ATTR_PROJECT_NAME);
		IWorkspaceRoot root = ResourcesPlugin.getWorkspace().getRoot();
		return root.getProject(projectName);
	}

	/**
	 * ���s�f�B���N�g���̎擾
	 *
	 * @param configuration
	 *            ILaunchConfiguration
	 * @return ���s�f�B���N�g��
	 * @throws CoreException
	 */
	private String getWorkingDirectory(ILaunchConfiguration configuration)
			throws CoreException {
		String workingDirectory = configuration.getAttribute(
				ConfigurationConstants.ATTR_WORKING_DIR,
				ConfigurationConstants.DEFAULT_WORKING_DIR);
		return workingDirectory;
	}

	/**
	 * �����`�X�N���v�g�̎擾
	 *
	 * @return �����`�X�N���v�g
	 */
	private String getLaunchScript() {
		String launchScript = "";
		try {
			RpgxpdtPlugin plugin = RpgxpdtPlugin.getDefault();
			Map<?, ?> override = new HashMap<Object, Object>();
			URL url = FileLocator.find(plugin.getBundle(), LAUNCH_SCRIPT,
					override);
			URL resolve = FileLocator.resolve(url);
			launchScript = new File(resolve.getPath()).getAbsolutePath();
		} catch (IOException e) {
			e.printStackTrace();
		}
		return launchScript;
	}

	/**
	 * �v���W�F�N�g�t�@�C���̎擾. ��ƃf�B���N�g�� �{ Game.exe �� Game.proj
	 *
	 * @param configuration
	 *            ILaunchConfiguration
	 * @return �v���W�F�N�g�t�@�C�����i�t���p�X�j
	 * @throws CoreException
	 */
	private String getRpgxpProjectFile(ILaunchConfiguration configuration)
			throws CoreException {
		Boolean scriptGameUsed = getGameUsed(configuration);
		String workingDirectoryName = getWorkingDirectory(configuration);
		if (scriptGameUsed.booleanValue()) {
			// RPGXP Game �t�@�C��
			return new File(workingDirectoryName + File.separator
					+ GAME_COMMAND_FILE).toString();
		}
		// RPGXP �v���W�F�N�g �t�@�C��
		return new File(workingDirectoryName + File.separator
				+ RPGXP_PROJECT_FILE).toString();
	}
}
