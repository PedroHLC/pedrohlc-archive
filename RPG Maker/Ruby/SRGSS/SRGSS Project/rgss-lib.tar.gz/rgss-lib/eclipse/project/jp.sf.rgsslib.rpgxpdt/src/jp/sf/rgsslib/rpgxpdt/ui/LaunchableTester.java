package jp.sf.rgsslib.rpgxpdt.ui;

import jp.sf.rgsslib.rpgxpdt.launch.ConfigurationUtil;
import jp.sf.rgsslib.rpgxpdt.preferences.PreferenceUtil;

import org.eclipse.core.expressions.PropertyTester;
import org.eclipse.core.resources.IResource;

public class LaunchableTester extends PropertyTester {
	private static final String PROPERTY_LAUNCH_TEST = "launchable";

	public boolean test(Object receiver, String property, Object[] args,
			Object expectedValue) {
		boolean result = false;
		if (PROPERTY_LAUNCH_TEST.equals(property)) {
			IResource resource = (IResource) receiver;
			String name = resource.getProject().getName();
			String dir = PreferenceUtil.getDefaultRpgXpProjectDir(name);
			if (ConfigurationUtil.isVarildRpgxpProject(dir)) {
				result = true;
			}
		}
		return result;
	}

}
