package jp.sf.rgsslib.rpgxpdt;

import java.util.MissingResourceException;
import java.util.ResourceBundle;

import org.eclipse.core.runtime.IStatus;
import org.eclipse.core.runtime.Status;
import org.eclipse.jface.resource.ImageDescriptor;
import org.eclipse.ui.IStartup;
import org.eclipse.ui.plugin.AbstractUIPlugin;
import org.osgi.framework.BundleContext;

/**
 * The main plugin class to be used in the desktop.
 */
public class RpgxpdtPlugin extends AbstractUIPlugin implements IStartup {

	// The shared instance.
	private static RpgxpdtPlugin plugin;

	private ResourceBundle resourceBundle;

	private final static String PLUGIN_ID = RpgxpdtPlugin.class.getPackage()
			.getName();

	/**
	 * The constructor.
	 */
	public RpgxpdtPlugin() {
		plugin = this;
	}

	/**
	 * This method is called upon plug-in activation
	 */
	@Override
	public void start(BundleContext context) throws Exception {
		super.start(context);
	}

	/**
	 * This method is called when the plug-in is stopped
	 */
	@Override
	public void stop(BundleContext context) throws Exception {
		super.stop(context);
		plugin = null;
	}

	/**
	 * Returns the shared instance.
	 */
	public static RpgxpdtPlugin getDefault() {
		return plugin;
	}

	/**
	 * Returns an image descriptor for the image file at the given plug-in
	 * relative path.
	 * 
	 * @param path
	 *            the path
	 * @return the image descriptor
	 */
	public static ImageDescriptor getImageDescriptor(String path) {
		return AbstractUIPlugin.imageDescriptorFromPlugin(RpgxpdtPlugin.class
				.getPackage().getName(), path);
	}

	/**
	 * Returns the string from the plugin's resource bundle, or 'key' if not
	 * found.
	 */
	public static String getResourceString(String key) {
		ResourceBundle bundle = RpgxpdtPlugin.getDefault().getResourceBundle();
		try {
			return (bundle != null) ? bundle.getString(key) : key;
		} catch (MissingResourceException e) {
			return key;
		}
	}

	/**
	 * Returns the plugin's resource bundle,
	 */
	public ResourceBundle getResourceBundle() {
		try {
			if (resourceBundle == null) {
				resourceBundle = ResourceBundle.getBundle(RpgxpdtPlugin.class
						.getName()
						+ "Resource");
			}
		} catch (MissingResourceException e) {
			resourceBundle = null;
		}
		return resourceBundle;
	}

	/**
	 * @param object
	 *            �x�[�X�I�u�W�F�N�g.
	 * @param key
	 *            �L�[.
	 * @return ���\�[�X
	 */
	public static String getResourceString(Object object, String key) {
		return getResourceString(object.getClass().getName() + "." + key);
	}

	/**
	 * �G���[���O.
	 * 
	 * @param message
	 *            ���b�Z�[�W.
	 * @param t
	 *            ��O.or null.
	 */
	public void logError(String message, Throwable t) {
		IStatus status = new Status(IStatus.ERROR, PLUGIN_ID, IStatus.OK,
				message, t);
		getLog().log(status);
	}

	public void earlyStartup() {
	}
}
