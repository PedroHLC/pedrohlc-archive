package jp.sf.rgsslib.rpgvxdt.launch;

import static jp.sf.rgsslib.rpgvxdt.RpgvxdtPlugin.getResourceString;
import static jp.sf.rgsslib.rpgvxdt.launch.ConfigurationConstants.ATTR_PROJECT_GAME_USED;
import static jp.sf.rgsslib.rpgvxdt.launch.ConfigurationConstants.ATTR_PROJECT_NAME;
import static jp.sf.rgsslib.rpgvxdt.launch.ConfigurationConstants.ATTR_RGSS_FILE_LIST;
import static jp.sf.rgsslib.rpgvxdt.launch.ConfigurationConstants.ATTR_SCRIPT_BASE_USED;
import static jp.sf.rgsslib.rpgvxdt.launch.ConfigurationConstants.ATTR_WORKING_DIR;
import static jp.sf.rgsslib.rpgvxdt.launch.ConfigurationConstants.ATTR_WORKING_DIR_TYPE;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

import jp.sf.rgsslib.rpgvxdt.RpgvxdtPlugin;
import jp.sf.rgsslib.rpgvxdt.preferences.PreferenceUtil;

import org.eclipse.core.resources.IContainer;
import org.eclipse.core.resources.IFile;
import org.eclipse.core.resources.IResource;
import org.eclipse.core.resources.IResourceVisitor;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.core.runtime.IPath;
import org.eclipse.debug.core.DebugPlugin;
import org.eclipse.debug.core.ILaunchConfiguration;
import org.eclipse.debug.core.ILaunchConfigurationType;
import org.eclipse.debug.core.ILaunchConfigurationWorkingCopy;
import org.eclipse.debug.core.ILaunchManager;
import org.eclipse.debug.ui.ILaunchShortcut;
import org.eclipse.jface.viewers.ISelection;
import org.eclipse.jface.viewers.IStructuredSelection;
import org.eclipse.ui.IEditorPart;

public class NormalShortcut implements ILaunchShortcut {

	private static final String KEY_LAUNCH_ERROR_MESSAGE = "launch.error.message";

	private List<String> scriptFilter = null;

	public void launch(ISelection selection, String mode) {
		if (selection instanceof IStructuredSelection) {
			searchAndLaunch(((IStructuredSelection) selection).toArray(), mode);
		}
	}

	public void launch(IEditorPart editor, String mode) {
		searchAndLaunch(new Object[] { editor.getEditorInput() }, mode);
	}

	protected ILaunchConfigurationType getConfigurationType() {
		return getLaunchManager().getLaunchConfigurationType(
				ConfigurationConstants.ID_RPGVXDT_TYPE);
	}

	private ILaunchManager getLaunchManager() {
		return DebugPlugin.getDefault().getLaunchManager();
	}

	private List<String> getScriptList(Object[] resources) {
		final List<String> scriptList = new ArrayList<String>();
		for (Object object : resources) {
			System.out.println(object);
			if (object instanceof IFile) {
				IFile file = (IFile) object;
				if (isValidScript(file)) {
					IPath path = file.getProjectRelativePath();
					scriptList.add(path.toString());
				}
			} else if (object instanceof IContainer) {
				IContainer container = (IContainer) object;
				try {
					container.accept(new IResourceVisitor() {
						public boolean visit(IResource resource)
								throws CoreException {
							if (resource instanceof IFile) {
								IFile file = (IFile) resource;
								if (isValidScript(file)) {
									IPath path = file.getProjectRelativePath();
									scriptList.add(path.toString());
								}
							}
							return true;
						}
					});
				} catch (CoreException e) {
					RpgvxdtPlugin.getDefault().logError(
							getResourceString(this, KEY_LAUNCH_ERROR_MESSAGE),
							e);
				}
			}
		}
		return scriptList;
	}

	private void searchAndLaunch(Object[] resource, String mode) {
		if (resource.length == 0) {
			return;
		}
		if (!(resource[0] instanceof IResource)) {
			return;
		}
		try {
			IResource target = (IResource) resource[0];
			String projectDir = PreferenceUtil.getTkoolProjectDir();
			String projectName = target.getProject().getName();
			String workingDir = new File(projectDir + File.separator
					+ projectName).getAbsolutePath();

			List<String> scriptList = getScriptList(resource);

			ILaunchManager mgr = getLaunchManager();
			String prefix = target.getName();
			String name = mgr.generateUniqueLaunchConfigurationNameFrom(prefix);
			ILaunchConfigurationType type = getConfigurationType();
			ILaunchConfigurationWorkingCopy copy = type.newInstance(null, name);

			copy.setAttribute(ATTR_PROJECT_NAME, projectName);
			copy.setAttribute(ATTR_RGSS_FILE_LIST, scriptList);
			copy.setAttribute(ATTR_WORKING_DIR_TYPE, true);
			copy.setAttribute(ATTR_WORKING_DIR, workingDir);
			copy.setAttribute(ATTR_SCRIPT_BASE_USED, true);
			copy.setAttribute(ATTR_PROJECT_GAME_USED, false);

			ILaunchConfiguration configuration = copy.doSave();
			configuration.launch(mode, null);
		} catch (CoreException e) {
			RpgvxdtPlugin.getDefault().logError(
					getResourceString(this, KEY_LAUNCH_ERROR_MESSAGE), e);
		}
	}

	/**
	 * �X�N���v�g�t�@�C���`�F�b�N.
	 * 
	 * @param scriptFile
	 *            �X�N���v�g�t�@�C��.
	 */
	protected boolean isValidScript(IFile scriptFile) {
		if (scriptFile == null) {
			return false;
		}
		if (!scriptFile.exists()) {
			return false;
		}
		List<String> filter = getScriptFilter();
		return filter.contains(scriptFile.getFileExtension());
	}

	/**
	 * �X�N���v�g�t�B���^�[�̎擾.
	 * 
	 * @return �g���q�̃��X�g.
	 */
	protected List<String> getScriptFilter() {
		if (scriptFilter == null) {
			scriptFilter = PreferenceUtil.getScriptFilter();
		}
		return scriptFilter;
	}

}
