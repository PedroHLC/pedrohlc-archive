package jp.sf.rgsslib.rpgxpdt.launch;

import java.util.ArrayList;
import java.util.List;

public class ConfigurationConstants {
	public static final String ID_RPGXPDT_TYPE = "jp.sf.rgsslib.rpgxpdt.launch.ConfigurationType";

	public static final String RPGXP_PROJECT_FILE = "Game.rxproj";

	public static final String GAME_COMMAND_FILE = "Game.exe";

	public static final String ATTR_PROJECT_NAME = "projectName";

	public static final String DEFAULT_ATTR_PROJECT_NAME = "";

	public static final String ATTR_RGSS_FILE_LIST = "scriptList";

	public static final List<String> DEFAULT_ATTR_RGSS_FILE_LIST = new ArrayList<String>();

	public static final String ATTR_WORKING_DIR = "workdingDirectory";

	public static final String DEFAULT_WORKING_DIR = "";

	public static final String ATTR_WORKING_DIR_TYPE = "workdingDirectoryType";

	public static final boolean DEFAULT_ATTR_WORKING_DIR_TYPE = true;

	public static final String ATTR_SCRIPT_BASE_USED = "scriptBaseUsed";

	public static final boolean DEFAULT_ATTR_SCRIPT_BASE_USED = true;

	public static final String ATTR_PROJECT_GAME_USED = "projectFileUsed";

	public static final boolean DEFAULT_ATTR_PROJECT_GAME_USED = false;
}
