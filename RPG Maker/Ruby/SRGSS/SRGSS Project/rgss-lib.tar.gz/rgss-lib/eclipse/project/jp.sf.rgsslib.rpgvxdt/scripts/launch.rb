puts "launch script start..."

# 引数のチェック
if ARGV.size != 3
  puts "\tARGV error (ARGV.size != 3)."
  puts "launch script end."
  exit(1)
end

# ランチャースクリプトの場所
launch_script_base = File.expand_path(File.dirname($0))
$: << launch_script_base

# 利用ライブラリ
require 'nkf'
require 'zlib'
require 'Win32API'

# ベーススクリプトを利用するかどうか
script_base_used = ARGV[0] == "true"

# ベーススクリプトファイル名
rgssfilename = File.dirname(ARGV[1]) + '/System/Data/Scripts.rvdata'

# プロジェクトスクリプトファイル名
project_dir = ARGV[2] + "\\"
target = File.expand_path('Data/Scripts.rvdata')
puts target

# スクリプトリスト
scripts = []

# 挿入位置
insert_index = 0

# ベーススクリプトの読み込み
if script_base_used
  File.open(rgssfilename, "rb") do |f|
    scripts = Marshal.load(f)
  end
  # 挿入位置を検索
  scripts.each_index do |i|
    s = scripts[i]
    if s[1] == "( ここに追加 )"
      insert_index = i
    end
  end
end

# スクリプトセクションデータ作成
def createSectionData(name,data)
  id = name.object_id
  utf_data = NKF.nkf('--utf8',data)
  zlib_data = Zlib::Deflate.deflate(utf_data)
  return [id,name,zlib_data]
end

# スクリプトファイル読み込み
def loadFileData(filename)
  data = ''
  open(filename).each do |line|
    line.sub!(/[ \t\n]*$/,"\r\n")
    data += line
  end
  return data
end

begin
  # 保存用ファイルリスト
  files = []
  # 標準入力から読み込まれるファイル名を読み込む
  while line = STDIN.gets
    filename = line.chop
    puts "\t" + filename
    
    # ファイルの存在チェック
    if FileTest.file?(filename)
      # セクションデータ作成
      name = File.basename(filename)
      data = loadFileData(filename)
      section = createSectionData(name,data)
      # スクリプトに追加
      insert_index += 1
      if script_base_used
        scripts.insert(insert_index,section)
      else
        scripts.push(section)
      end
      # 保存用ファイルリストに追加
      files.push(filename)
    end
  end
  
  # 保存用ファイルリストをセクションデータに追加
  data = ''
  files.each do |filename|
    data += "# #{filename[project_dir.size .. filename.size]}\r\n"
  end
  section = createSectionData('rgss_list',data)
  scripts.push(section)
  
  # スクリプトデータを保存
  File.open(target, "wb") do |f|
    Marshal.dump(scripts, f)
  end
end

puts "launch script end."
