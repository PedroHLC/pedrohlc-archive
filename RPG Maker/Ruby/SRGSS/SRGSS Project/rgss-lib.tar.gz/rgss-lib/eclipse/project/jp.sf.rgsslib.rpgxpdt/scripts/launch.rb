puts "launch script start..."

launch_script_base = File.expand_path(File.dirname($0))
$: << launch_script_base

require 'nkf'
require 'zlib'
require 'Win32API'

script_base_used = ARGV[0] == "true"
rgssfilename = File.dirname(ARGV[1]) + '/System/Data/Scripts.rxdata'
project_dir = ARGV[2] + "\\"
target = File.expand_path('Data/Scripts.rxdata')

puts target

scripts = []
main_script = nil

if script_base_used
  File.open(rgssfilename, "rb") do |f|
    scripts = Marshal.load(f)
  end
  main_script = scripts.pop
end

def createSectionData(name,data)
  id = name.object_id
  utf_data = NKF.nkf('--utf8',data)
  zlib_data = Zlib::Deflate.deflate(utf_data)
  return [id,name,zlib_data]
end

def loadFileData(filename)
  data = ''
  open(filename).each do |line|
    line.sub!(/[ \t\n]*$/,"\r\n")
    data += line
  end
  return data
end

begin
  files = []
  while line = STDIN.gets
    filename = line.chop
    puts "\t" + filename
    # �t�@�C��
    if FileTest.file?(filename)
      name = File.basename(filename)
      data = loadFileData(filename)
      section = createSectionData(name,data)
      scripts.push(section)
      files.push(filename)
    end
  end
  scripts.push main_script if not main_script.nil?
  
  data = ''
  files.each do |filename|
    data += "# #{filename[project_dir.size .. filename.size]}\r\n"
  end
  section = createSectionData('rgss_list',data)
  scripts.push(section)

  File.open(target, "wb") do |f|
    Marshal.dump(scripts, f)
  end
end

puts "launch script end."
