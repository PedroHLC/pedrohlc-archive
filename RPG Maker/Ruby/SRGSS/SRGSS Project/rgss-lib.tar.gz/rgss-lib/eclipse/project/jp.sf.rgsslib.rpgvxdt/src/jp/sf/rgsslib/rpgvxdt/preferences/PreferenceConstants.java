package jp.sf.rgsslib.rpgvxdt.preferences;

/**
 * Constant definitions for plug-in preferences
 */
public class PreferenceConstants {
	public static final String P_RPGVX_COMMAND = "rpgvx";

	public static final String P_TKOOL_PROJECT_DIR = "tkoolProjectDir";

	public static final String P_RUBY_COMMAND = "ruby";

	public static final String P_SCRIPT_FILTER = "scriptFilter";

	static final String[] DEFAULT_RPGVX_COMMANDS = new String[] { "C:/Program Files/Enterbrain/RPGVX/RPGVX.exe" };

	static final String[] DEFAULT_RUBY_COMMANDS = new String[] { "C:/ruby/bin/ruby.exe" };

	public static final String DEFAULT_SCRIPT_FILTER = "rb;rgss;txt;";
}
