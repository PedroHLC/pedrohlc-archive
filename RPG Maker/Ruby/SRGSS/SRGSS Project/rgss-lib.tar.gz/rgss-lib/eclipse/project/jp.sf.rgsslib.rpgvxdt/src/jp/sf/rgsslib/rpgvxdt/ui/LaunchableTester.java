package jp.sf.rgsslib.rpgvxdt.ui;

import jp.sf.rgsslib.rpgvxdt.launch.ConfigurationUtil;
import jp.sf.rgsslib.rpgvxdt.preferences.PreferenceUtil;

import org.eclipse.core.expressions.PropertyTester;
import org.eclipse.core.resources.IResource;

public class LaunchableTester extends PropertyTester {
	private static final String PROPERTY_LAUNCH_TEST = "launchable";

	public boolean test(Object receiver, String property, Object[] args,
			Object expectedValue) {
		boolean result = false;
		if (PROPERTY_LAUNCH_TEST.equals(property)) {
			IResource resource = (IResource) receiver;
			String name = resource.getProject().getName();
			String dir = PreferenceUtil.getDefaultRpgVxProjectDir(name);
			if (ConfigurationUtil.isVarildRpgvxProject(dir)) {
				result = true;
			}
		}
		return result;
	}

}
