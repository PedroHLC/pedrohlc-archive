package jp.sf.rgsslib.rpgxpdt.preferences;

import static jp.sf.rgsslib.rpgxpdt.preferences.PreferenceConstants.DEFAULT_RPGXP_COMMANDS;
import static jp.sf.rgsslib.rpgxpdt.preferences.PreferenceConstants.DEFAULT_RUBY_COMMANDS;
import static jp.sf.rgsslib.rpgxpdt.preferences.PreferenceConstants.DEFAULT_SCRIPT_FILTER;
import static jp.sf.rgsslib.rpgxpdt.preferences.PreferenceConstants.P_RPGXP_COMMAND;
import static jp.sf.rgsslib.rpgxpdt.preferences.PreferenceConstants.P_RUBY_COMMAND;
import static jp.sf.rgsslib.rpgxpdt.preferences.PreferenceConstants.P_SCRIPT_FILTER;
import static jp.sf.rgsslib.rpgxpdt.preferences.PreferenceConstants.P_TKOOL_PROJECT_DIR;

import java.io.File;

import jp.sf.rgsslib.rpgxpdt.RpgxpdtPlugin;

import org.eclipse.core.runtime.preferences.AbstractPreferenceInitializer;
import org.eclipse.jface.preference.IPreferenceStore;

/**
 * Class used to initialize default preference values.
 */
public class PreferenceInitializer extends AbstractPreferenceInitializer {

	/**
	 * @see AbstractPreferenceInitializer#initializeDefaultPreferences()
	 */
	@Override
	public void initializeDefaultPreferences() {
		IPreferenceStore store = RpgxpdtPlugin.getDefault()
				.getPreferenceStore();
		store.setDefault(P_RPGXP_COMMAND,
				getDefaultFile(DEFAULT_RPGXP_COMMANDS));
		store.setDefault(P_TKOOL_PROJECT_DIR, getDefaultTkoolProjectDir());
		store.setDefault(P_RUBY_COMMAND, getDefaultFile(DEFAULT_RUBY_COMMANDS));
		store.setDefault(P_SCRIPT_FILTER, DEFAULT_SCRIPT_FILTER);
	}

	/**
	 * @return �p�X
	 */
	private String getDefaultFile(String[] files) {
		String result = "";
		for (String file : files) {
			File f = new File(file);
			if (f.exists() && f.isFile()) {
				result = file;
				break;
			}
		}
		return result.replace('/', File.separatorChar);
	}

	/**
	 * @return RPG�c�N�[��XP�v���W�F�N�g�f�t�H���g�p�X
	 */
	private String getDefaultTkoolProjectDir() {
		return System.getProperty("user.home", "");
	}
}
