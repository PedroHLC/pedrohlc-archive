package jp.sf.rgsslib.rpgvxdt.preferences;

import static jp.sf.rgsslib.rpgvxdt.RpgvxdtPlugin.getResourceString;
import jp.sf.rgsslib.rpgvxdt.RpgvxdtPlugin;

import org.eclipse.jface.preference.DirectoryFieldEditor;
import org.eclipse.jface.preference.FieldEditor;
import org.eclipse.jface.preference.FieldEditorPreferencePage;
import org.eclipse.jface.preference.FileFieldEditor;
import org.eclipse.jface.preference.StringFieldEditor;
import org.eclipse.ui.IWorkbench;
import org.eclipse.ui.IWorkbenchPreferencePage;

/**
 * This class represents a preference page that is contributed to the
 * Preferences dialog. By subclassing <samp>FieldEditorPreferencePage</samp>,
 * we can use the field support built into JFace that allows us to create a page
 * that is small and knows how to save, restore and apply itself.
 * <p>
 * This page is used to modify preferences only. They are stored in the
 * preference store that belongs to the main plug-in class. That way,
 * preferences can be accessed directly via the preference store.
 */

public class RgssPreferencePage extends FieldEditorPreferencePage implements
		IWorkbenchPreferencePage {

	private static final String KEY_DESCRIPTION = "description";

	private static final String KEY_RPGVX_COMMAND_FIELD_LABEL = "rpgvx.command.field.label";

	private static final String KEY_TKOOL_PROJECT_DIR_FIELD_LABEL = "tkool.project.dir.field.label";

	private static final String KEY_RUBY_COMMAND_FIELD_LABEL = "ruby.command.field.label";

	private static final String KEY_SCRIPT_FILTER_FIELD_LABEL = "script.filter.field.label";

	public RgssPreferencePage() {
		super(GRID);
		setPreferenceStore(RpgvxdtPlugin.getDefault().getPreferenceStore());
		setDescription(getResourceString(this, KEY_DESCRIPTION));
	}

	/**
	 * Creates the field editors. Field editors are abstractions of the common
	 * GUI blocks needed to manipulate various types of preferences. Each field
	 * editor knows how to save and restore itself.
	 */
	@Override
	public void createFieldEditors() {
		String label = null;
		FieldEditor editor = null;

		label = getResourceString(this, KEY_RPGVX_COMMAND_FIELD_LABEL);
		editor = new FileFieldEditor(PreferenceConstants.P_RPGVX_COMMAND,
				label, getFieldEditorParent());
		addField(editor);

		label = getResourceString(this, KEY_TKOOL_PROJECT_DIR_FIELD_LABEL);
		editor = new DirectoryFieldEditor(
				PreferenceConstants.P_TKOOL_PROJECT_DIR, label,
				getFieldEditorParent());
		addField(editor);

		label = getResourceString(this, KEY_RUBY_COMMAND_FIELD_LABEL);
		editor = new FileFieldEditor(PreferenceConstants.P_RUBY_COMMAND, label,
				getFieldEditorParent());
		addField(editor);

		label = getResourceString(this, KEY_SCRIPT_FILTER_FIELD_LABEL);
		editor = new StringFieldEditor(PreferenceConstants.P_SCRIPT_FILTER,
				label, getFieldEditorParent());
		addField(editor);
	}

	/**
	 * @see IWorkbenchPreferencePage#init(org.eclipse.ui.IWorkbench)
	 */
	public void init(IWorkbench workbench) {
	}
}