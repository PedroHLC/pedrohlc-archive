#ifndef __MW_H__
#define __MW_H__

#include <QMainWindow>
#include <QSettings>
#include <QToolBar>
#include <QTextDocument>
#include "aw.h"
#include "sh.h"

class QTextEdit;

class MainWindow : public QMainWindow
{
     Q_OBJECT

public:
     MainWindow(QWidget *parent = 0);
	 QSettings *settings;

public slots:
     void about();
     void newFile();
     void openFile(const QString &path = QString());
	 void saveFile();
	 void saveAsFile();

	 void undo();
	 void redo();

	 void cut();
	 void copy();
	 void paste();

	 void select();

	 void zoom_in();
	 void zoom_out();

	 void show_highlight(bool tf); //true = on, false = off
	 void toggle_cursor_width(bool tf); //true = fat, false = thin

private:
     void setupEditor();
     void setupFileMenu();
	 void setupEditMenu();
	 void setupViewMenu();
     void setupHelpMenu();
	 void setupFileToolBar();

     QTextEdit *editor;
     Highlighter *highlighter;
	 AboutWindow *aw;
	 QToolBar *toolBar, *toolBarEdit, *toolBarView;
	 QTextDocument *doc;
};

#endif
