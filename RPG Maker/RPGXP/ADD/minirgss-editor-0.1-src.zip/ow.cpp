#include <QtGui>
#include <QLabel>
#include "ow.h"

OptionsWindow::OptionsWindow() {
  setFixedSize(400, 400);
  setUp();
  setLayout(grid);
  setWindowTitle("MiniRGSS-Editor Options");
  setWindowIcon(QIcon(":/images/application_form.png"));
}

void OptionsWindow::setUp() {
  QLabel *optLbl = new QLabel(tr("MiniRGSS-Editor Options:"));
  grid = new QGridLayout;
  tab = new QTabWidget;
  saveBtn = new QPushButton("OK");

  gb1 = new QGroupBox(tr("Position Toolbar"));
  gb1->setFlat(true);
  hbl1 = new QVBoxLayout;
  gridToolBar = new QGridLayout;
  QLabel *toolBarLbl2 = new QLabel(tr("Top"));
  toolBarLbl2->setAlignment(Qt::AlignRight);
  QLabel *toolBarLbl3 = new QLabel(tr("Bottom"));
  toolBarScrollBar = new QScrollBar(Qt::Horizontal);
  toolBarScrollBar->setMinimum(0);
  toolBarScrollBar->setMaximum(100);
  toolBarScrollBar->setPageStep(10);
  gridToolBar->addWidget(toolBarLbl2, 0, 0);
  gridToolBar->addWidget(toolBarScrollBar, 0, 1, 0, 10);
  gridToolBar->addWidget(toolBarLbl3, 0, 11);
  hbl1->addLayout(gridToolBar);
  hbl1->addSpacing(300);
  gb1->setLayout(hbl1);

  tab->addTab(gb1, QIcon(":/images/cog.png"), tr("Toolbar"));

  grid->addWidget(optLbl, 0, 0);
  grid->addWidget(tab, 1, 0);
}
