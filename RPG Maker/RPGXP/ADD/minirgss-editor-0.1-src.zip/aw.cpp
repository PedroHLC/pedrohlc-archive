#include <QtGui>
#include "aw.h"

AboutWindow::AboutWindow() {
  setFixedSize(400, 400);
  setUp();
  setWindowTitle("About MiniRGSS-Editor");
  setWindowIcon(QIcon(":/images/page_white_cplusplus.png"));
}

void AboutWindow::paintEvent(QPaintEvent * event) {
  QPainter painter(this);
  QPixmap pixmap(":/images/miniRGSS.png");
  painter.drawPixmap(5, 5, 175, 28, pixmap);
  painter.end();
}

void AboutWindow::setUp() {
	QFile license(":/images/license.txt");
  QString licenseText;
  if (license.exists()) {
    if (license.open(QIODevice::ReadOnly | QIODevice::Text)) {
      licenseText = license.readAll();
    }
  }
  QFile versions(":/images/versions.txt");
  QString versionsText;
  if (versions.exists()) {
    if (versions.open(QIODevice::ReadOnly | QIODevice::Text)) {
       versionsText = versions.readAll();
    }
  }
  vbox = new QVBoxLayout;
  hbox = new QHBoxLayout;
  textAbout = new QTextEdit(
      tr("<p><b>MiniRGSS-Editor</b> is a lightweight RGSS Editor program.<br />" \
         "It is written 100% in <b>C++-Script</b> and uses the <b>Qt 4.3.0</b> framework.<br />" \
         "Released under the <b>GNU General Public License.</b></p>"));
  textAuthors = new QTextEdit(
      tr("<p><b>Paul Mattern</b><br />" \
         "&nbsp;&nbsp;&nbsp;&lt;paul_mattern@yahoo.com&gt;<br />" \
		 "&nbsp;&nbsp;&nbsp;&lt;sourceforge.net/projects/minirgss&gt;<br />" \
         "&nbsp;&nbsp;&nbsp;developer, artwork, translater etc.</p>" \
		 "<p><b>Kevin Couvillion</b><br />" \
		 "&nbsp;&nbsp;&nbsp;&lt;pepsikev2000@yahoo.de&gt;<br />" \
		 "&nbsp;&nbsp;&nbsp;&lt;sourceforge.net/projects/minirgss&gt;<br />" \
		 "&nbsp;&nbsp;&nbsp;beta-tester</p>"));
  textLicense = new QTextEdit();
  textLicense->setPlainText(licenseText);
  textVersions = new QTextEdit();
  textVersions->setPlainText(versionsText);
  textAbout->setReadOnly(true);
  textAuthors->setReadOnly(true);
  textVersions->setReadOnly(true);
  textLicense->setReadOnly(true);
  twidget = new QTabWidget;
  twidget->addTab(textAbout, QIcon(":/images/information.png"), tr("About"));
  twidget->addTab(textAuthors, QIcon(":/images/pencil.png"), tr("Authors"));
  twidget->addTab(textVersions, QIcon(":/images/images.png"), tr("Versions"));
  twidget->addTab(textLicense, QIcon(":/images/page_key.png"), tr("License"));
  aboutQtBtn = new QPushButton(QIcon(":/images/qt_icon.png"), tr("About Qt"));
  aboutQtBtn->setFixedSize(90, 25);
  aboutQtBtn->setWhatsThis(tr("Open a window about the Qt framework."));
  closeBtn = new QPushButton(QIcon(":/images/cross.png"), tr("Close"));
  closeBtn->setFixedSize(90, 25);
  closeBtn->setWhatsThis(tr("Close this window."));
  closeBtn->setDefault(true);
  connect(closeBtn, SIGNAL(clicked()),
          this, SLOT(close()));
  connect(aboutQtBtn, SIGNAL(clicked()),
		  qApp, SLOT(aboutQt()));
  hbox->addSpacing(300);
  hbox->addWidget(aboutQtBtn, Qt::AlignRight);
  hbox->addWidget(closeBtn, Qt::AlignRight);
  vbox->addSpacing(30);
  vbox->addWidget(twidget);
  vbox->addLayout(hbox);
  setLayout(vbox);
}
