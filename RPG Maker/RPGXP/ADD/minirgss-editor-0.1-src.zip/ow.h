#ifndef __OW_H__
#define __OW_H__
#include <QDialog>
#include <QGridLayout>
#include <QVBoxLayout>
#include <QPushButton>
#include <QLabel>
#include <QCheckBox>
#include <QTabWidget>
#include <QScrollBar>
#include <QGroupBox>

class OptionsWindow : public QDialog {
  Q_OBJECT
  public:
    OptionsWindow();
    QGridLayout *grid, *gridToolBar;
	QTabWidget *tab;
	QScrollBar *toolBarScrollBar;
	QGroupBox *gb1;
	QVBoxLayout *hbl1;
	QPushButton *saveBtn, *cancelBtn;

  protected:
    void setUp();
};
#endif
