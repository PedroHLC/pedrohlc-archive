#ifndef __AW_H__
#define __AW_H__
#include <QDialog>
#include <QVBoxLayout>
#include <QHBoxLayout>
#include <QTabWidget>
#include <QTextEdit>
#include <QFile>
#include <QPushButton>

class AboutWindow : public QDialog {
  Q_OBJECT
  public:
    AboutWindow();
    QVBoxLayout *vbox, *vboxl;
    QHBoxLayout *hbox;
    QTabWidget *twidget;
    QTextEdit *textAbout, *textAuthors, *textVersions, *textLicense;
    QPushButton *closeBtn, *aboutQtBtn, *printLicenseBtn;
  protected:
    void paintEvent(QPaintEvent *event);
    void setUp();
};
#endif
