#include <QtGui>

#include "mw.h"

MainWindow::MainWindow(QWidget *parent) : QMainWindow(parent)
{ 
     setupFileMenu();
	 setupEditMenu();
	 setupViewMenu();
     setupHelpMenu();
     setupEditor();
	 setupFileToolBar();

	 settings = new QSettings(QSettings::IniFormat, QSettings::UserScope, "MiniRGSS-Editor", "MiniRGSS-Editor");

     setCentralWidget(editor);
     setWindowTitle(tr("MiniRGSS-Editor"));
	 setWindowIcon(QIcon(":/images/rgss_template_icon.png"));
}

void MainWindow::about()
{
     aw = new AboutWindow;
	 aw->show();
}

void MainWindow::newFile()
{
	if (doc->isModified()) {
		int res = QMessageBox::warning(NULL, tr("Save File?"), tr("The current file has <b>not</b> been saved. "
			"Would you like to save it now?"), QMessageBox::Save | QMessageBox::Discard | QMessageBox::Cancel);
		if (res == QMessageBox::Save) {
			QString fileName = QFileDialog::getSaveFileName(this, tr("Save As"), QDir::homePath(), "RGSS Files (*.rgss *.rgss2 *.txt);;All Files (*.*)");
			if (fileName.isEmpty()) return;
			QFile file(fileName);
			if (file.open(QIODevice::WriteOnly|QIODevice::Text)) {
				file.write(editor->toPlainText().toUtf8());
			}
			editor->clear();
			setWindowTitle(tr("MiniRGSS-Editor"));
			return;
		} else if (res == QMessageBox::Discard) {
			editor->clear();
			setWindowTitle(tr("MiniRGSS-Editor"));
			return;
		}
		return;
	}
	editor->clear();
	setWindowTitle(tr("MiniRGSS-Editor"));
}

void MainWindow::openFile(const QString &path)
{
     QString fileName = path;

     if (fileName.isNull())
         fileName = QFileDialog::getOpenFileName(this,
             tr("Open File"), QDir::homePath(), "RGSS Files (*.rgss *.rgss2 *.txt);;All Files (*.*)");

     if (!fileName.isEmpty()) {
         QFile file(fileName);
         if (file.open(QFile::ReadOnly | QFile::Text))
             editor->setPlainText(file.readAll());
			 setWindowTitle(tr("MiniRGSS-Editor - [%1]").arg(fileName));
     }
}

void MainWindow::saveFile() {
	QString fileName = QFileDialog::getSaveFileName(this, tr("Save As"), QDir::homePath(), "RGSS Files (*.rgss *.rgss2 *.txt);;All Files (*.*)");
	if (fileName.isEmpty()) return;
	QFile file(fileName);
	if (file.open(QIODevice::WriteOnly|QIODevice::Text)) {
		file.write(editor->toPlainText().toUtf8());
	}
	setWindowTitle(tr("MiniRGSS-Editor - [%1]").arg(fileName));
}

void MainWindow::saveAsFile() {
	QString fileName = QFileDialog::getSaveFileName(this, tr("Save As"), QDir::homePath(), "RGSS Files (*.rgss *.rgss2 *.txt);;All Files (*.*)");
	if (fileName.isEmpty()) return;
	QFile file(fileName);
	if (file.open(QIODevice::WriteOnly|QIODevice::Text)) {
		file.write(editor->toPlainText().toUtf8());
	}
	setWindowTitle(tr("MiniRGSS-Editor - [%1]").arg(fileName));
}

void MainWindow::setupEditor()
{
     QFont font;
     font.setFamily("Courier New");
     font.setFixedPitch(true);
     font.setPointSize(10);

	 doc = new QTextDocument;

     editor = new QTextEdit;
	 editor->setDocument(doc);
     editor->setFont(font);
	 editor->setVerticalScrollBarPolicy(Qt::ScrollBarAlwaysOn);
	 editor->setHorizontalScrollBarPolicy(Qt::ScrollBarAlwaysOn);
	 editor->setLineWrapMode(QTextEdit::NoWrap);
	 //highlighter = new Highlighter(editor->document());
}

void MainWindow::setupFileMenu()
{
     QMenu *fileMenu = new QMenu(tr("&File"), this);
     menuBar()->addMenu(fileMenu);

	 fileMenu->addAction(QIcon(":/images/21.png"), tr("&New"), this, SLOT(newFile()),
                         QKeySequence(tr("Ctrl+N", "File|New")));
	 fileMenu->addAction(QIcon(":/images/folder_page.png"), tr("&Open..."), this, SLOT(openFile()),
                         QKeySequence(tr("Ctrl+O", "File|Open")));
	 fileMenu->addAction(QIcon(":/images/46.png"), tr("&Save"), this, SLOT(saveFile()),
                         QKeySequence(tr("Ctrl+S", "File|Exit")));
	 fileMenu->addAction(QIcon(":/images/saveas.png"), tr("Save &As..."), this, SLOT(saveAsFile()));
	 fileMenu->addSeparator();
	 fileMenu->addAction(QIcon(":/images/door_in.png"), tr("E&xit"), qApp, SLOT(quit()),
                         QKeySequence(tr("Alt+F4", "File|Exit")));
}

void MainWindow::setupEditMenu()
{
	QMenu *editMenu = new QMenu(tr("&Edit"), this);
	menuBar()->addMenu(editMenu);

	editMenu->addAction(QIcon(":/images/16.png"), tr("&Undo"), this, SLOT(undo()),
						QKeySequence(tr("Ctrl+Z", "Edit|Undo")));
	editMenu->addAction(QIcon(":/images/15.png"), tr("&Redo"), this, SLOT(redo()),
						QKeySequence(tr("Ctrl+Y", "Edit|Redo")));
	editMenu->addSeparator();
	editMenu->addAction(QIcon(":/images/cut.png"), tr("&Cut"), this, SLOT(cut()),
						QKeySequence(tr("Ctrl+X", "Edit|Cut")));
	editMenu->addAction(QIcon(":/images/copy.png"), tr("Cop&y"), this, SLOT(copy()),
						QKeySequence(tr("Ctrl+C", "Edit|Copy")));
	editMenu->addAction(QIcon(":/images/29.png"), tr("&Paste"), this, SLOT(paste()),
						QKeySequence(tr("Ctrl+V", "Edit|Paste")));
	editMenu->addSeparator();
	editMenu->addAction(QIcon(":/images/textfield_rename.png"), tr("Select &All"), this, SLOT(select()),
						QKeySequence(tr("Ctrl+M", "Edit|Select All")));
}

void MainWindow::setupViewMenu()
{
	QMenu *viewMenu = new QMenu(tr("&View"), this);
	menuBar()->addMenu(viewMenu);

	viewMenu->addAction(QIcon(":/images/magnifier_zoom_in.png"), tr("Zoom &In"), this, SLOT(zoom_in()),
						QKeySequence(tr("Ctrl++", "View|Zoom In")));
	viewMenu->addAction(QIcon(":/images/magnifier_zoom_out.png"), tr("Zoom &Out"), this, SLOT(zoom_out()),
						QKeySequence(tr("Ctrl+-", "View|Zoom Out")));
	viewMenu->addSeparator();
	QAction* hl = new QAction(tr("&Show Highlighting"), this);
	hl->setCheckable(true);
	hl->setShortcut(tr("Ctrl+H"));
	connect(hl, SIGNAL(triggered(bool)), this, SLOT(show_highlight(bool)));
	viewMenu->addAction(hl);
	viewMenu->addSeparator();
	QAction* tw = new QAction(tr("&Thick Cursor"), this);
	tw->setCheckable(true);
	tw->setShortcut(tr("Alt+^"));
	connect(tw, SIGNAL(triggered(bool)), this, SLOT(toggle_cursor_width(bool)));
	viewMenu->addAction(tw);
}

void MainWindow::setupHelpMenu()
{
     QMenu *helpMenu = new QMenu(tr("&Help"), this);
     menuBar()->addMenu(helpMenu);

	 helpMenu->addAction(QIcon(":/images/page_white_cplusplus.png"), tr("&About"), this, SLOT(about()));
}

void MainWindow::setupFileToolBar()
{
	toolBar = addToolBar(tr("File"));
	toolBar->setIconSize(QSize(18, 18));
	toolBar->setMovable(false);
	toolBar->addAction(QIcon(":/images/21.png"), tr("&New"), this, SLOT(newFile()));
	toolBar->addAction(QIcon(":/images/folder_page.png"), tr("&Open"), this, SLOT(openFile()));
	toolBar->addAction(QIcon(":/images/46.png"), tr("&Save"), this, SLOT(saveFile()));

	toolBarEdit = addToolBar(tr("Edit"));
	toolBarEdit->setIconSize(QSize(18, 18));
	toolBarEdit->setMovable(false);
	toolBarEdit->addAction(QIcon(":/images/cut.png"), tr("&Cut"), this, SLOT(cut()));
	toolBarEdit->addAction(QIcon(":/images/copy.png"), tr("Cop&y"), this, SLOT(copy()));
	toolBarEdit->addAction(QIcon(":/images/29.png"), tr("&Paste"), this, SLOT(paste()));
	toolBarEdit->addSeparator();
	toolBarEdit->addAction(QIcon(":/images/16.png"), tr("&Undo"), this, SLOT(undo()));
	toolBarEdit->addAction(QIcon(":/images/15.png"), tr("&Redo"), this, SLOT(redo()));

	toolBarView = addToolBar(tr("View"));
	toolBarView->setIconSize(QSize(18, 18));
	toolBarView->setMovable(false);
	toolBarView->addAction(QIcon(":/images/magnifier_zoom_in.png"), tr("Zoom &In"), this, SLOT(zoom_in()));
	toolBarView->addAction(QIcon(":/images/magnifier_zoom_out.png"), tr("Zoom &Out"), this, SLOT(zoom_out()));
}

void MainWindow::undo()
{
	editor->undo();
}

void MainWindow::redo()
{
	editor->redo();
}

void MainWindow::cut()
{
	editor->cut();
}

void MainWindow::copy()
{
	editor->copy();
}

void MainWindow::paste()
{
	editor->paste();
}

void MainWindow::zoom_in()
{
	editor->zoomIn(5);
}

void MainWindow::zoom_out()
{
	editor->zoomOut(5);
}

void MainWindow::show_highlight(bool tf)
{
	if (tf)
	{
		highlighter = new Highlighter(editor->document());
	}
	else
	{
		highlighter->~Highlighter();
	}
}

void MainWindow::select()
{
	editor->selectAll();
}

void MainWindow::toggle_cursor_width(bool tf)
{
	if (tf)
	{
		editor->setCursorWidth(9);
	}
	else
	{
		editor->setCursorWidth(1);
	}
}
