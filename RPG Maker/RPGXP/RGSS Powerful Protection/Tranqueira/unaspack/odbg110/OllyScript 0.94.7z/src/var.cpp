#include "StdAfx.h"
#include "var.h"

var::var()
{
	vt = EMP;
}

var::var(const var& rhs)
{
	vt = rhs.vt;
	dw = rhs.dw;
	str = rhs.str;
}

var::var(string& rhs)
{
	vt = STR;
	dw = 0;
	str = rhs;
}

var::var(DWORD rhs)
{
	vt = DW;
	dw = rhs;
	str = "";
}

var::var(int rhs)
{
	vt = DW;
	dw = (DWORD)rhs;
	str = "";
}

var& var::operator=(const var& rhs)
{
	vt = rhs.vt;
	dw = rhs.dw;
	str = rhs.str;
	return *this;
}

var& var::operator=(const string& rhs)
{
	vt = STR;
	dw = 0;
	str = rhs;
	return *this;
}

var& var::operator=(const DWORD& rhs)
{
	vt = DW;
	dw = rhs;
	str = "";
	return *this;
}

var& var::operator=(const int& rhs)
{
	vt = DW;
	dw = (DWORD)rhs;
	str = "";
	return *this;
}

var& var::operator+=(const var& rhs)
{
	if(vt == rhs.vt)
	{
		if(vt == DW)
			dw += rhs.dw;
		if(vt == STR)
			str += rhs.str;
	}
	return *this;
}

var& var::operator+=(const string& rhs)
{
	if(vt == STR)
		str += rhs;
	return *this;
}

var& var::operator+=(const DWORD& rhs)
{
	if(vt == DW)
		dw += rhs;
	return *this;
}

var& var::operator+=(const int& rhs)
{
	if(vt == DW)
		dw += (DWORD)rhs;
	return *this;
}

int var::compare(const var& rhs) const
{
	// less than zero this < rhs
	// zero this == rhs 
	// greater than zero this > rhs 
	if(vt != rhs.vt || vt == EMP || rhs.vt == EMP)
		return 0;

	if(vt == STR)
        return str.compare(rhs.str);

	if(vt == DW)
	{
		if(dw < rhs.dw) return -1;
		if(dw == rhs.dw) return 0;
		if(dw > rhs.dw) return 1;
	}
	return 0;
}

int var::compare(const string& rhs) const
{
	var tmp;
	tmp.vt = STR;
	tmp.str = rhs;
    return compare(tmp);
}

int var::compare(const DWORD& rhs) const
{
	var tmp(rhs);
	return compare(tmp);
}

int var::compare(const int& rhs) const
{
	var tmp(rhs);
	return compare(tmp);
}