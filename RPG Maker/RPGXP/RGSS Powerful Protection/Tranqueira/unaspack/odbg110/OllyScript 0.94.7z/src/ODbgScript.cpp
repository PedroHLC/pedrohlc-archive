// ODbgScript.cpp : Defines the entry point for the DLL application.
//
#define STRICT

#include "stdafx.h"

// Temp storage
char buff[4096] = {0};

// OllyLang object
OllyLang* ollylang;

// Script state
int script_state = SS_NONE;

// Entry point into a plugin DLL. Many system calls require DLL instance
// which is passed to DllEntryPoint() as one of parameters. Remember it.
BOOL APIENTRY DllMain( HANDLE hModule, 
                       DWORD  ul_reason_for_call, 
                       LPVOID lpReserved
					 )
{
    switch (ul_reason_for_call)
	{
		case DLL_PROCESS_ATTACH:
			hinst = (HINSTANCE)hModule;        // Mark plugin instance
		case DLL_THREAD_ATTACH:
		case DLL_THREAD_DETACH:
		case DLL_PROCESS_DETACH:
			break;
    }

	#ifdef _DEBUG
		RedirectIOToConsole();
	#endif

    return TRUE;
}

// Report plugin name and return version of plugin interface.
extc int _export cdecl ODBG_Plugindata(char shortname[32]) 
{
	strcpy(shortname,"OllyScript");
	return PLUGIN_VERSION;
}

// OllyDbg calls this obligatory function once during startup. I place all
// one-time initializations here. Parameter features is reserved for future
// extentions, do not use it.
extc int _export cdecl ODBG_Plugininit(int ollydbgversion, HWND hw, ulong *features) 
{
	if(ollydbgversion < PLUGIN_VERSION)
		return -1;

	// Keep handle of main OllyDbg window. This handle is necessary, for example,
	// to display message box.
	hwmain = hw;

	// Report plugin in the log window.
	Addtolist(0, 0, "OllyScript v%i.%i",VERSIONHI,VERSIONLO);
	Addtolist(0, -1,"  See OllyScript.txt for credits and contacts");
	ollylang = new OllyLang();
	return 0;
}

// This function is called each time OllyDbg passes main Windows loop. When
// debugged application stops, bring command line window in foreground.
extc void _export cdecl ODBG_Pluginmainloop(DEBUG_EVENT *debugevent) 
{
	t_status status;
	status = Getstatus();
	script_state = ollylang->GetState();
	
	// Check for breakpoint jumps
	if(script_state == SS_RUNNING && debugevent && debugevent->dwDebugEventCode == EXCEPTION_DEBUG_EVENT)
	{
		EXCEPTION_DEBUG_INFO edi = debugevent->u.Exception;
		if(edi.ExceptionRecord.ExceptionCode == EXCEPTION_BREAKPOINT)
			ollylang->OnBreakpoint();
		else if(edi.ExceptionRecord.ExceptionCode != EXCEPTION_SINGLE_STEP)
			ollylang->OnException(edi.ExceptionRecord.ExceptionCode);
		else
			
			if(script_state == SS_RUNNING)
			{
				t_thread* t;
				t = Findthread(Getcputhreadid());
				CONTEXT context; 
				context.ContextFlags = CONTEXT_DEBUG_REGISTERS;
				GetThreadContext(t->thread, &context);

				if(t->reg.ip == context.Dr0 || t->reg.ip == context.Dr1 || t->reg.ip == context.Dr2 || t->reg.ip == context.Dr3)
					ollylang->OnBreakpoint();
			}
	}

	if(status == STAT_STOPPED && (script_state == SS_RUNNING || script_state == SS_LOADED))
	{
		try
		{
			ollylang->Step(0);
			script_state = ollylang->GetState();
		}
		catch( ... )
		{
			delete ollylang;
			MessageBox(hwmain, "An error occured in the plugin!\nSee OllyScript.txt file for contacts addresses", "OllyScript", MB_OK | MB_ICONERROR | MB_TOPMOST);
		}
	}
}

// Function adds items to main OllyDbg menu (origin=PM_MAIN).
extc int _export cdecl ODBG_Pluginmenu(int origin, char data[4096], void *item) 
{
	if (origin != PM_MAIN)
		return 0;                          // No pop-up menus in OllyDbg's windows

	ZeroMemory(buff, sizeof(buff));
	strcpy(buff, "Run &script{0 Load...|");
	
	//MRU Menu content, actions are 21..25
	mruGetMenu(hinst,&buff[strlen(buff)]);
	strcpy(&buff[strlen(buff)],

		"}|"
		"1 Abort,"
		"2 Pause,"
		"3 Resume,"
		"4 Step |"
		"10 &About"
//		"11 TEST,"
//		"12 TEST2"
		);

	strcpy(data,buff);
	return 1;
}

extc int _export cdecl ExecuteScript(const char* const filename)
{
	ollylang->LoadScript((LPSTR)filename);
	ollylang->Step(0);
	return 0;
}

extc int _export cdecl ODBG_Pausedex(int reasonex, int dummy, t_reg* reg, DEBUG_EVENT* debugevent)
{
	EXCEPTION_DEBUG_INFO edi;
	if(debugevent)
		edi = debugevent->u.Exception;
	script_state = ollylang->GetState();

	// cout << hex << reasonex << endl;

	// Handle events
	if(script_state == SS_RUNNING)
	{
		switch(reasonex) 
		{
		case PP_INT3BREAK:
		case PP_HWBREAK:
		case PP_MEMBREAK:
			ollylang->OnBreakpoint();
			break;
		case PP_EXCEPTION:
		case PP_ACCESS:
		case PP_GUARDED:
		case PP_SINGLESTEP | PP_BYPROGRAM:
			ollylang->OnException(edi.ExceptionRecord.ExceptionCode);
			break;
		}
	}
	// Step script
//	if(script_state == SS_RUNNING || script_state == SS_LOADED)
//	{
//		try
//		{
//			Broadcast(WM_USER_CHALL, 0, 0);
//			ollylang->Step(0);
//			script_state = ollylang->GetState();
//		}
//		catch( ... )
//		{
//			delete ollylang;
//			MessageBox(hwmain, "An error occured in the plugin!\nPlease contact SHaG.", "OllyScript", MB_OK | MB_ICONERROR | MB_TOPMOST);
//		}
//	}
	return 0;
}

// Receives commands from main menu.
extc void _export cdecl ODBG_Pluginaction(int origin, int action, void *item) 
{
  char s[256];
  if (origin != PM_MAIN)
    return;
  switch (action) 
  {
	case 0: // Run script
		OPENFILENAME ofn;       // common dialog box structure
		char szFile[260];       // buffer for file name

		// Initialize OPENFILENAME
		ZeroMemory(&ofn, sizeof(ofn));
		ofn.lStructSize = sizeof(ofn);
		ofn.hwndOwner = hwmain;
		ofn.lpstrFile = szFile;
		//
		// Set lpstrFile[0] to '\0' so that GetOpenFileName does not 
		// use the contents of szFile to initialize itself.
		//
		ofn.lpstrFile[0] = '\0';
		ofn.nMaxFile = sizeof(szFile);
		ofn.lpstrFilter = "Olly Scripts\0*.osc;*.txt\0All\0*.*\0";
		ofn.nFilterIndex = 1;
		ofn.lpstrFileTitle = NULL;
		ofn.nMaxFileTitle = 0;
		Pluginreadstringfromini(hinst, "ScriptDir", buff, 0);
		ofn.lpstrInitialDir = buff;
		ofn.lpstrTitle = "Run Olly Script";
		ofn.Flags = OFN_PATHMUSTEXIST | OFN_FILEMUSTEXIST;

		// Display the Open dialog box. 
		if (GetOpenFileName(&ofn)==TRUE)
		{
			// Load script
			ollylang->LoadScript(ofn.lpstrFile);
			// Save script directory
			ZeroMemory(&buff, sizeof(buff));
			strncpy(buff, ofn.lpstrFile, ofn.nFileOffset);
			Pluginwritestringtoini(hinst, "ScriptDir", buff);

			mruAddFile(hinst, ofn.lpstrFile);

			// Start script
			ollylang->Step(0);
		}
		break;

	case 1: // Abort
		ollylang->Reset();
		MessageBox(hwmain,"Script aborted!","OllyScript",MB_OK|MB_ICONEXCLAMATION);
		break;

	case 2: // Pause
		ollylang->Pause();
		break;

	case 3: // Resume
		ollylang->Resume();
		break;

	case 4: // Step
		ollylang->Step(1);
		script_state = ollylang->GetState();
		break;

    case 10:
		sprintf(s,"OllyScript plugin v%i.%i\nSee OllyScript.txt for credits and contacts\nCompiled %s %s",
			VERSIONHI,VERSIONLO, __DATE__, __TIME__);
		MessageBox(hwmain,s,"ODbgScript",MB_OK|MB_ICONINFORMATION);
		break;
	case 21: // MRU List
	case 22:
	case 23:
	case 24:
	case 25:
		{
			action-=20; 
			char key[5]="MRU ";
			key[3]=action+0x30;
						
			ZeroMemory(&buff, sizeof(buff));
			Pluginreadstringfromini(hinst,key,buff,0);

			// Load script
			ollylang->LoadScript(buff);

			mruAddFile(hinst, buff);

			// Save script directory
			char* buf2;
			GetFullPathName(buff,sizeof(buff),buff,&buf2); *buf2=0;			
			Pluginwritestringtoini(hinst, "ScriptDir", buff);

			// Start script
			ollylang->Step(0);

			break;
		}
	case 11:
		{
//			string x = "Hej";
//			string y = ToLower(x);
//			__asm nop;
		}
	case 12:
		{
//			Broadcast(WM_USER_CHALL, 0, 0);
		}
//			t_thread* thr = Findthread(Getcputhreadid());
//			byte buffer[4];
//			ulong fs = thr->reg.limit[2]; // BUG IN ODBG!!!
//			fs += 0x30;
//			Readmemory(buffer, fs, 4, MM_RESTORE);
//			fs = *((ulong*)buffer);
//			fs += 2;
//			buffer[0] = 0;
//			Writememory(buffer, fs, 1, MM_RESTORE);
//			cout << endl;
		
//			ulong addr = t->reg.s[SEG_FS];
//			Readmemory(buffer, addr, 4, MM_RESTORE);
//			cout << hex << &buffer;

			/*
			HMODULE hMod = GetModuleHandle("OllyScript.dll");
			if(hMod) // Check that the other plugin is present and loaded
			{
				// Get address of exported function
				int (*pFunc)(char*) = (int (*)(char*)) GetProcAddress(hMod, "ExecuteScript");
				if(pFunc) // Check that the other plugin exports the correct function
					pFunc("xxx"); // Execute exported function
			}

			cout << hex << hMod << endl;*/
			//403008 401035
			/*DWORD pid = Plugingetvalue(VAL_PROCESSID);
			DebugSetProcessKillOnExit(FALSE);
			DebugActiveProcessStop(pid);
			break;*/
			//t_module* mod = Findmodule(0x401000);
			//cout << hex << mod->codebase;
			
			//cout << hex << mod->codebase;



			/*char cmd[MAXCMDSIZE] = {0};
		//Readmemory(cmd, 0x401030, 1, 0);

		t_memory* tmem = Findmemory(0x412fc0);
		ulong addr = 0x412fc0;

		do 
		{
			addr = Disassembleforward(0, tmem->base, tmem->size, addr, 1, 0); 
			Readcommand(addr, cmd);
		} while(cmd[0] != 0x61);

		Manualbreakpoint(addr, VK_F2, 0, 0, FIXEDFONT);
		Sendshortcut(PM_MAIN, 0, WM_KEYDOWN, 0, 0, VK_F9);

		//Disasm((uchar*)cmd, sizeof(cmd), 0x412fc0, 0, &d, DISASM_CODE, 0);
		//ulong x = 
		t_disasm d;
		DWORD r = cmd[0] << (8 * 3);// + cmd[1] << (8 * 2);// + cmd[2] << 8 + cmd[3];
		r += cmd[1] << (8 * 2);
		r += cmd[2] << 8;
		r += cmd[3];
		cerr << cmd << endl;
		*/
		break;

    default: 
		break;
  }
}

extc void _export cdecl ODBG_Pluginreset()
{
	ollylang->Reset();
}


// OllyDbg calls this optional function when user wants to terminate OllyDbg.
extc int _export cdecl ODBG_Pluginclose() 
{
	delete ollylang;
	return 0;
}

// OllyDbg calls this optional function once on exit. At this moment, all
// windows created by plugin are already destroyed (and received WM_DESTROY
// messages). Function must free all internally allocated resources, like
// window classes, files, memory and so on.
extc void _export cdecl ODBG_Plugindestroy()
{
	Unregisterpluginclass(cmdlinewinclass);
}

// This is an example of an exported variable
// ODBGSCRIPT_API int nODbgScript=0;

// This is an example of an exported function.
// ODBGSCRIPT_API int fnODbgScript(void)
// {
// 	return 42;
// }

// This is the constructor of a class that has been exported.
// see ODbgScript.h for the class definition
// CODbgScript::CODbgScript()
// { 
// 	return; 
// }

