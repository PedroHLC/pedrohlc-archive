#pragma once

#include "OllyLang.h"

using namespace std;

enum vtype { EMP, DW, STR };

class var
{
public:
	DWORD dw;
	string str;
	vtype vt;

	var();
	var(const var& rhs); 
	var(string& rhs); 
	var(DWORD rhs); 
	var(int rhs); 

	// less than zero this < rhs
	// zero this == rhs 
	// greater than zero this > rhs 
	int compare(const var& rhs) const; 
	int compare(const string& rhs) const; 
	int compare(const DWORD& rhs) const; 
	int compare(const int& rhs) const; 

	var& operator=(const var& rhs);
	var& operator=(const string& rhs);
	var& operator=(const DWORD& rhs);
	var& operator=(const int& rhs);

	var& operator+=(const var& rhs);
	var& operator+=(const string& rhs);
	var& operator+=(const DWORD& rhs);
	var& operator+=(const int& rhs);

};
