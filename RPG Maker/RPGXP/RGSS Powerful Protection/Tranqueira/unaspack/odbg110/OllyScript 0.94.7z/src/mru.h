void mruAddFile(HINSTANCE h, char* szFilePath);
int  mruGetMenu(HINSTANCE h, char* buf);
