#Configura��o
module Settings
  SERVER_HOST = "127.0.0.1"# Endere�o host ou Ip
  SERVER_PORT = 3309 # Id da porta(aconcelhado >= 1000)
  SERVER_PASS = 'pedrohlc'
  
  PRINT_PACKETS = false # Loga os pacontes na tela
  WAIT_TO_EXIT = true # Espera o usuario pressionar ENTER para sair
  
  DB_HOST = "localhost" # Endere�o host ou IP
  DB_USER = "root" # Usuario
  DB_PASS = "123456" # Senha
  DB_NAME = "phlcnetplay" # Nome da database
end